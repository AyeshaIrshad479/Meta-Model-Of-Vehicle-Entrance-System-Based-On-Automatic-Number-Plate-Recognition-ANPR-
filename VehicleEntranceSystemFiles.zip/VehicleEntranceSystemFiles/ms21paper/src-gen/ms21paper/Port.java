/**
 */
package ms21paper;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.Port#getPin <em>Pin</em>}</li>
 *   <li>{@link ms21paper.Port#getType <em>Type</em>}</li>
 *   <li>{@link ms21paper.Port#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getPort()
 * @model abstract="true"
 * @generated
 */
public interface Port extends EObject {
	/**
	 * Returns the value of the '<em><b>Pin</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pin</em>' attribute.
	 * @see #setPin(String)
	 * @see ms21paper.Ms21paperPackage#getPort_Pin()
	 * @model default=""
	 * @generated
	 */
	String getPin();

	/**
	 * Sets the value of the '{@link ms21paper.Port#getPin <em>Pin</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pin</em>' attribute.
	 * @see #getPin()
	 * @generated
	 */
	void setPin(String value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The default value is <code>"Digital"</code>.
	 * The literals are from the enumeration {@link ms21paper.TypePort}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see ms21paper.TypePort
	 * @see #setType(TypePort)
	 * @see ms21paper.Ms21paperPackage#getPort_Type()
	 * @model default="Digital"
	 * @generated
	 */
	TypePort getType();

	/**
	 * Sets the value of the '{@link ms21paper.Port#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see ms21paper.TypePort
	 * @see #getType()
	 * @generated
	 */
	void setType(TypePort value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see ms21paper.Ms21paperPackage#getPort_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link ms21paper.Port#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // Port
