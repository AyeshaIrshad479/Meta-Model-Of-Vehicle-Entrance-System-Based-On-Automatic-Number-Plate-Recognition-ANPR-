/**
 */
package ms21paper;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Region Of Interest</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.RegionOfInterest#getCharactersegmentation <em>Charactersegmentation</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getRegionOfInterest()
 * @model
 * @generated
 */
public interface RegionOfInterest extends DIP {
	/**
	 * Returns the value of the '<em><b>Charactersegmentation</b></em>' reference list.
	 * The list contents are of type {@link ms21paper.CharacterSegmentation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Charactersegmentation</em>' reference list.
	 * @see ms21paper.Ms21paperPackage#getRegionOfInterest_Charactersegmentation()
	 * @model
	 * @generated
	 */
	EList<CharacterSegmentation> getCharactersegmentation();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void edge();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void bwlabel();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void regionprops();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void imdialate();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void imerode();

} // RegionOfInterest
