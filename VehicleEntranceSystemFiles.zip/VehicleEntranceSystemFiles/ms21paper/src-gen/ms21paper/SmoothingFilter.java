/**
 */
package ms21paper;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Smoothing Filter</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ms21paper.Ms21paperPackage#getSmoothingFilter()
 * @model
 * @generated
 */
public interface SmoothingFilter extends Filtering {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Average();
} // SmoothingFilter
