/**
 */
package ms21paper;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Vehicle</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.Vehicle#getMotionsensor <em>Motionsensor</em>}</li>
 *   <li>{@link ms21paper.Vehicle#getName <em>Name</em>}</li>
 *   <li>{@link ms21paper.Vehicle#getVnumber <em>Vnumber</em>}</li>
 *   <li>{@link ms21paper.Vehicle#getOwnerID <em>Owner ID</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getVehicle()
 * @model
 * @generated
 */
public interface Vehicle extends EObject {
	/**
	 * Returns the value of the '<em><b>Motionsensor</b></em>' reference list.
	 * The list contents are of type {@link ms21paper.Sensor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Motionsensor</em>' reference list.
	 * @see ms21paper.Ms21paperPackage#getVehicle_Motionsensor()
	 * @model upper="3"
	 * @generated
	 */
	EList<Sensor> getMotionsensor();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see ms21paper.Ms21paperPackage#getVehicle_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link ms21paper.Vehicle#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Vnumber</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vnumber</em>' attribute.
	 * @see #setVnumber(String)
	 * @see ms21paper.Ms21paperPackage#getVehicle_Vnumber()
	 * @model
	 * @generated
	 */
	String getVnumber();

	/**
	 * Sets the value of the '{@link ms21paper.Vehicle#getVnumber <em>Vnumber</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vnumber</em>' attribute.
	 * @see #getVnumber()
	 * @generated
	 */
	void setVnumber(String value);

	/**
	 * Returns the value of the '<em><b>Owner ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owner ID</em>' attribute.
	 * @see #setOwnerID(String)
	 * @see ms21paper.Ms21paperPackage#getVehicle_OwnerID()
	 * @model
	 * @generated
	 */
	String getOwnerID();

	/**
	 * Sets the value of the '{@link ms21paper.Vehicle#getOwnerID <em>Owner ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Owner ID</em>' attribute.
	 * @see #getOwnerID()
	 * @generated
	 */
	void setOwnerID(String value);

} // Vehicle
