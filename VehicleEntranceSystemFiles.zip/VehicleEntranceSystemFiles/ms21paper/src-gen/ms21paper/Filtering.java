/**
 */
package ms21paper;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Filtering</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.Filtering#getMasksize <em>Masksize</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getFiltering()
 * @model abstract="true"
 * @generated
 */
public interface Filtering extends Preprocessing {

	/**
	 * Returns the value of the '<em><b>Masksize</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Masksize</em>' attribute.
	 * @see #setMasksize(float)
	 * @see ms21paper.Ms21paperPackage#getFiltering_Masksize()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.Float"
	 * @generated
	 */
	float getMasksize();

	/**
	 * Sets the value of the '{@link ms21paper.Filtering#getMasksize <em>Masksize</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Masksize</em>' attribute.
	 * @see #getMasksize()
	 * @generated
	 */
	void setMasksize(float value);
} // Filtering
