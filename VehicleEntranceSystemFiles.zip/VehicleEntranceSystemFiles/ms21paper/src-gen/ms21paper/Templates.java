/**
 */
package ms21paper;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Templates</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.Templates#getCharacterrecognition <em>Characterrecognition</em>}</li>
 *   <li>{@link ms21paper.Templates#getBinaryimage <em>Binaryimage</em>}</li>
 *   <li>{@link ms21paper.Templates#getImextn <em>Imextn</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getTemplates()
 * @model
 * @generated
 */
public interface Templates extends DIP {
	/**
	 * Returns the value of the '<em><b>Characterrecognition</b></em>' reference list.
	 * The list contents are of type {@link ms21paper.CharacterRecognition}.
	 * It is bidirectional and its opposite is '{@link ms21paper.CharacterRecognition#getTemplates <em>Templates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Characterrecognition</em>' reference list.
	 * @see ms21paper.Ms21paperPackage#getTemplates_Characterrecognition()
	 * @see ms21paper.CharacterRecognition#getTemplates
	 * @model opposite="templates"
	 * @generated
	 */
	EList<CharacterRecognition> getCharacterrecognition();

	/**
	 * Returns the value of the '<em><b>Binaryimage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Binaryimage</em>' attribute.
	 * @see #setBinaryimage(String)
	 * @see ms21paper.Ms21paperPackage#getTemplates_Binaryimage()
	 * @model
	 * @generated
	 */
	String getBinaryimage();

	/**
	 * Sets the value of the '{@link ms21paper.Templates#getBinaryimage <em>Binaryimage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Binaryimage</em>' attribute.
	 * @see #getBinaryimage()
	 * @generated
	 */
	void setBinaryimage(String value);

	/**
	 * Returns the value of the '<em><b>Imextn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Imextn</em>' attribute.
	 * @see #setImextn(String)
	 * @see ms21paper.Ms21paperPackage#getTemplates_Imextn()
	 * @model
	 * @generated
	 */
	String getImextn();

	/**
	 * Sets the value of the '{@link ms21paper.Templates#getImextn <em>Imextn</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Imextn</em>' attribute.
	 * @see #getImextn()
	 * @generated
	 */
	void setImextn(String value);

} // Templates
