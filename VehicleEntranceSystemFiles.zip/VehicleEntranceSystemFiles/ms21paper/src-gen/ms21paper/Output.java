/**
 */
package ms21paper;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.Output#isMotorStatus <em>Motor Status</em>}</li>
 *   <li>{@link ms21paper.Output#getControlgate <em>Controlgate</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getOutput()
 * @model
 * @generated
 */
public interface Output extends Port {
	/**
	 * Returns the value of the '<em><b>Motor Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Motor Status</em>' attribute.
	 * @see #setMotorStatus(boolean)
	 * @see ms21paper.Ms21paperPackage#getOutput_MotorStatus()
	 * @model
	 * @generated
	 */
	boolean isMotorStatus();

	/**
	 * Sets the value of the '{@link ms21paper.Output#isMotorStatus <em>Motor Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Motor Status</em>' attribute.
	 * @see #isMotorStatus()
	 * @generated
	 */
	void setMotorStatus(boolean value);

	/**
	 * Returns the value of the '<em><b>Controlgate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Controlgate</em>' reference.
	 * @see #setControlgate(ControlGate)
	 * @see ms21paper.Ms21paperPackage#getOutput_Controlgate()
	 * @model
	 * @generated
	 */
	ControlGate getControlgate();

	/**
	 * Sets the value of the '{@link ms21paper.Output#getControlgate <em>Controlgate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Controlgate</em>' reference.
	 * @see #getControlgate()
	 * @generated
	 */
	void setControlgate(ControlGate value);

} // Output
