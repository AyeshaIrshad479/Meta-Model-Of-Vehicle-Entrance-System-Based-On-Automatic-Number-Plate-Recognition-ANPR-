/**
 */
package ms21paper;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Control Gate</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.ControlGate#getName <em>Name</em>}</li>
 *   <li>{@link ms21paper.ControlGate#isMotorStatus <em>Motor Status</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getControlGate()
 * @model
 * @generated
 */
public interface ControlGate extends EObject {

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see ms21paper.Ms21paperPackage#getControlGate_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link ms21paper.ControlGate#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Motor Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Motor Status</em>' attribute.
	 * @see #setMotorStatus(boolean)
	 * @see ms21paper.Ms21paperPackage#getControlGate_MotorStatus()
	 * @model
	 * @generated
	 */
	boolean isMotorStatus();

	/**
	 * Sets the value of the '{@link ms21paper.ControlGate#isMotorStatus <em>Motor Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Motor Status</em>' attribute.
	 * @see #isMotorStatus()
	 * @generated
	 */
	void setMotorStatus(boolean value);
} // ControlGate
