/**
 */
package ms21paper;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PC</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.PC#getName <em>Name</em>}</li>
 *   <li>{@link ms21paper.PC#getVnumber <em>Vnumber</em>}</li>
 *   <li>{@link ms21paper.PC#getDataacquisition <em>Dataacquisition</em>}</li>
 *   <li>{@link ms21paper.PC#getRecords <em>Records</em>}</li>
 *   <li>{@link ms21paper.PC#getDip <em>Dip</em>}</li>
 *   <li>{@link ms21paper.PC#getVehiclelocation <em>Vehiclelocation</em>}</li>
 *   <li>{@link ms21paper.PC#getVehicleRecord <em>Vehicle Record</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getPC()
 * @model
 * @generated
 */
public interface PC extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see ms21paper.Ms21paperPackage#getPC_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link ms21paper.PC#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Vnumber</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vnumber</em>' attribute.
	 * @see #setVnumber(String)
	 * @see ms21paper.Ms21paperPackage#getPC_Vnumber()
	 * @model
	 * @generated
	 */
	String getVnumber();

	/**
	 * Sets the value of the '{@link ms21paper.PC#getVnumber <em>Vnumber</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vnumber</em>' attribute.
	 * @see #getVnumber()
	 * @generated
	 */
	void setVnumber(String value);

	/**
	 * Returns the value of the '<em><b>Dataacquisition</b></em>' reference list.
	 * The list contents are of type {@link ms21paper.DataAcquisition}.
	 * It is bidirectional and its opposite is '{@link ms21paper.DataAcquisition#getPc <em>Pc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dataacquisition</em>' reference list.
	 * @see ms21paper.Ms21paperPackage#getPC_Dataacquisition()
	 * @see ms21paper.DataAcquisition#getPc
	 * @model opposite="pc"
	 * @generated
	 */
	EList<DataAcquisition> getDataacquisition();

	/**
	 * Returns the value of the '<em><b>Records</b></em>' reference list.
	 * The list contents are of type {@link ms21paper.Records}.
	 * It is bidirectional and its opposite is '{@link ms21paper.Records#getPc <em>Pc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Records</em>' reference list.
	 * @see ms21paper.Ms21paperPackage#getPC_Records()
	 * @see ms21paper.Records#getPc
	 * @model opposite="pc"
	 * @generated
	 */
	EList<Records> getRecords();

	/**
	 * Returns the value of the '<em><b>Dip</b></em>' reference list.
	 * The list contents are of type {@link ms21paper.DIP}.
	 * It is bidirectional and its opposite is '{@link ms21paper.DIP#getPc <em>Pc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dip</em>' reference list.
	 * @see ms21paper.Ms21paperPackage#getPC_Dip()
	 * @see ms21paper.DIP#getPc
	 * @model opposite="pc" upper="2"
	 * @generated
	 */
	EList<DIP> getDip();

	/**
	 * Returns the value of the '<em><b>Vehiclelocation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vehiclelocation</em>' reference.
	 * @see #setVehiclelocation(VehicleLocation)
	 * @see ms21paper.Ms21paperPackage#getPC_Vehiclelocation()
	 * @model
	 * @generated
	 */
	VehicleLocation getVehiclelocation();

	/**
	 * Sets the value of the '{@link ms21paper.PC#getVehiclelocation <em>Vehiclelocation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vehiclelocation</em>' reference.
	 * @see #getVehiclelocation()
	 * @generated
	 */
	void setVehiclelocation(VehicleLocation value);

	/**
	 * Returns the value of the '<em><b>Vehicle Record</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vehicle Record</em>' attribute.
	 * @see #setVehicleRecord(String)
	 * @see ms21paper.Ms21paperPackage#getPC_VehicleRecord()
	 * @model
	 * @generated
	 */
	String getVehicleRecord();

	/**
	 * Sets the value of the '{@link ms21paper.PC#getVehicleRecord <em>Vehicle Record</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vehicle Record</em>' attribute.
	 * @see #getVehicleRecord()
	 * @generated
	 */
	void setVehicleRecord(String value);

} // PC
