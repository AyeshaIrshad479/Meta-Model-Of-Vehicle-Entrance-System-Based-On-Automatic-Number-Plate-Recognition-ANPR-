/**
 */
package ms21paper;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sharpening</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ms21paper.Ms21paperPackage#getSharpening()
 * @model
 * @generated
 */
public interface Sharpening extends Filtering {
} // Sharpening
