/**
 */
package ms21paper;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Entrance System</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.EntranceSystem#getVehicle <em>Vehicle</em>}</li>
 *   <li>{@link ms21paper.EntranceSystem#getMotionsensor <em>Motionsensor</em>}</li>
 *   <li>{@link ms21paper.EntranceSystem#getDataacquisition <em>Dataacquisition</em>}</li>
 *   <li>{@link ms21paper.EntranceSystem#getDip <em>Dip</em>}</li>
 *   <li>{@link ms21paper.EntranceSystem#getRecords <em>Records</em>}</li>
 *   <li>{@link ms21paper.EntranceSystem#getVehiclelocation <em>Vehiclelocation</em>}</li>
 *   <li>{@link ms21paper.EntranceSystem#getControlgate <em>Controlgate</em>}</li>
 *   <li>{@link ms21paper.EntranceSystem#getPc <em>Pc</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getEntranceSystem()
 * @model
 * @generated
 */
public interface EntranceSystem extends EObject {
	/**
	 * Returns the value of the '<em><b>Vehicle</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vehicle</em>' containment reference.
	 * @see #setVehicle(Vehicle)
	 * @see ms21paper.Ms21paperPackage#getEntranceSystem_Vehicle()
	 * @model containment="true"
	 * @generated
	 */
	Vehicle getVehicle();

	/**
	 * Sets the value of the '{@link ms21paper.EntranceSystem#getVehicle <em>Vehicle</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vehicle</em>' containment reference.
	 * @see #getVehicle()
	 * @generated
	 */
	void setVehicle(Vehicle value);

	/**
	 * Returns the value of the '<em><b>Motionsensor</b></em>' containment reference list.
	 * The list contents are of type {@link ms21paper.Sensor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Motionsensor</em>' containment reference list.
	 * @see ms21paper.Ms21paperPackage#getEntranceSystem_Motionsensor()
	 * @model containment="true"
	 * @generated
	 */
	EList<Sensor> getMotionsensor();

	/**
	 * Returns the value of the '<em><b>Dataacquisition</b></em>' containment reference list.
	 * The list contents are of type {@link ms21paper.DataAcquisition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dataacquisition</em>' containment reference list.
	 * @see ms21paper.Ms21paperPackage#getEntranceSystem_Dataacquisition()
	 * @model containment="true"
	 * @generated
	 */
	EList<DataAcquisition> getDataacquisition();

	/**
	 * Returns the value of the '<em><b>Dip</b></em>' containment reference list.
	 * The list contents are of type {@link ms21paper.DIP}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dip</em>' containment reference list.
	 * @see ms21paper.Ms21paperPackage#getEntranceSystem_Dip()
	 * @model containment="true"
	 * @generated
	 */
	EList<DIP> getDip();

	/**
	 * Returns the value of the '<em><b>Records</b></em>' containment reference list.
	 * The list contents are of type {@link ms21paper.Records}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Records</em>' containment reference list.
	 * @see ms21paper.Ms21paperPackage#getEntranceSystem_Records()
	 * @model containment="true"
	 * @generated
	 */
	EList<Records> getRecords();

	/**
	 * Returns the value of the '<em><b>Vehiclelocation</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vehiclelocation</em>' containment reference.
	 * @see #setVehiclelocation(VehicleLocation)
	 * @see ms21paper.Ms21paperPackage#getEntranceSystem_Vehiclelocation()
	 * @model containment="true"
	 * @generated
	 */
	VehicleLocation getVehiclelocation();

	/**
	 * Sets the value of the '{@link ms21paper.EntranceSystem#getVehiclelocation <em>Vehiclelocation</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vehiclelocation</em>' containment reference.
	 * @see #getVehiclelocation()
	 * @generated
	 */
	void setVehiclelocation(VehicleLocation value);

	/**
	 * Returns the value of the '<em><b>Controlgate</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Controlgate</em>' containment reference.
	 * @see #setControlgate(ControlGate)
	 * @see ms21paper.Ms21paperPackage#getEntranceSystem_Controlgate()
	 * @model containment="true"
	 * @generated
	 */
	ControlGate getControlgate();

	/**
	 * Sets the value of the '{@link ms21paper.EntranceSystem#getControlgate <em>Controlgate</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Controlgate</em>' containment reference.
	 * @see #getControlgate()
	 * @generated
	 */
	void setControlgate(ControlGate value);

	/**
	 * Returns the value of the '<em><b>Pc</b></em>' containment reference list.
	 * The list contents are of type {@link ms21paper.PC}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pc</em>' containment reference list.
	 * @see ms21paper.Ms21paperPackage#getEntranceSystem_Pc()
	 * @model containment="true"
	 * @generated
	 */
	EList<PC> getPc();

} // EntranceSystem
