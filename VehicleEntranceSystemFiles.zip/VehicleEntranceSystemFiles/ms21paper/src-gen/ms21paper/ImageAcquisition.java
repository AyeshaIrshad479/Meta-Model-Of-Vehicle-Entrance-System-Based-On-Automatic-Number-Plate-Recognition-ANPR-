/**
 */
package ms21paper;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Image Acquisition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.ImageAcquisition#getPreprocessing <em>Preprocessing</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getImageAcquisition()
 * @model
 * @generated
 */
public interface ImageAcquisition extends DIP {

	/**
	 * Returns the value of the '<em><b>Preprocessing</b></em>' reference list.
	 * The list contents are of type {@link ms21paper.Preprocessing}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Preprocessing</em>' reference list.
	 * @see ms21paper.Ms21paperPackage#getImageAcquisition_Preprocessing()
	 * @model
	 * @generated
	 */
	EList<Preprocessing> getPreprocessing();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void ImRead();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Preview();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Snapshot();

} // ImageAcquisition
