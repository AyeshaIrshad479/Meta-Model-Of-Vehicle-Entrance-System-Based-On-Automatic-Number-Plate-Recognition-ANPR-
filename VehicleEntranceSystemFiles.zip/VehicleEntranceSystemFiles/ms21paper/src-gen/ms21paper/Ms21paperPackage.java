/**
 */
package ms21paper;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see ms21paper.Ms21paperFactory
 * @model kind="package"
 * @generated
 */
public interface Ms21paperPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "ms21paper";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/ms21paper";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "ms21paper";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Ms21paperPackage eINSTANCE = ms21paper.impl.Ms21paperPackageImpl.init();

	/**
	 * The meta object id for the '{@link ms21paper.impl.VehicleImpl <em>Vehicle</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.VehicleImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getVehicle()
	 * @generated
	 */
	int VEHICLE = 0;

	/**
	 * The feature id for the '<em><b>Motionsensor</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE__MOTIONSENSOR = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE__NAME = 1;

	/**
	 * The feature id for the '<em><b>Vnumber</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE__VNUMBER = 2;

	/**
	 * The feature id for the '<em><b>Owner ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE__OWNER_ID = 3;

	/**
	 * The number of structural features of the '<em>Vehicle</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Vehicle</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.SensorImpl <em>Sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.SensorImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getSensor()
	 * @generated
	 */
	int SENSOR = 1;

	/**
	 * The feature id for the '<em><b>Dataacquisition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__DATAACQUISITION = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__NAME = 1;

	/**
	 * The feature id for the '<em><b>Sensor Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__SENSOR_DATA = 2;

	/**
	 * The number of structural features of the '<em>Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.MotionSensorImpl <em>Motion Sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.MotionSensorImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getMotionSensor()
	 * @generated
	 */
	int MOTION_SENSOR = 18;

	/**
	 * The meta object id for the '{@link ms21paper.impl.IRSsensorImpl <em>IR Ssensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.IRSsensorImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getIRSsensor()
	 * @generated
	 */
	int IR_SSENSOR = 19;

	/**
	 * The meta object id for the '{@link ms21paper.impl.DataAcquisitionImpl <em>Data Acquisition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.DataAcquisitionImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getDataAcquisition()
	 * @generated
	 */
	int DATA_ACQUISITION = 2;

	/**
	 * The feature id for the '<em><b>Controlgate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_ACQUISITION__CONTROLGATE = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_ACQUISITION__TYPE = 1;

	/**
	 * The feature id for the '<em><b>Pc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_ACQUISITION__PC = 2;

	/**
	 * The feature id for the '<em><b>Sensor Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_ACQUISITION__SENSOR_DATA = 3;

	/**
	 * The feature id for the '<em><b>Motor Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_ACQUISITION__MOTOR_STATUS = 4;

	/**
	 * The feature id for the '<em><b>Port</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_ACQUISITION__PORT = 5;

	/**
	 * The number of structural features of the '<em>Data Acquisition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_ACQUISITION_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Data Acquisition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_ACQUISITION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.DIPImpl <em>DIP</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.DIPImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getDIP()
	 * @generated
	 */
	int DIP = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIP__NAME = 0;

	/**
	 * The feature id for the '<em><b>Vehicle Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIP__VEHICLE_NUMBER = 1;

	/**
	 * The feature id for the '<em><b>Pc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIP__PC = 2;

	/**
	 * The feature id for the '<em><b>Comparison Result</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIP__COMPARISON_RESULT = 3;

	/**
	 * The number of structural features of the '<em>DIP</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIP_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>DIP</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIP_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.RecordsImpl <em>Records</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.RecordsImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getRecords()
	 * @generated
	 */
	int RECORDS = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECORDS__NAME = 0;

	/**
	 * The feature id for the '<em><b>Vnumber</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECORDS__VNUMBER = 1;

	/**
	 * The feature id for the '<em><b>Pc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECORDS__PC = 2;

	/**
	 * The feature id for the '<em><b>VOwner ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECORDS__VOWNER_ID = 3;

	/**
	 * The number of structural features of the '<em>Records</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECORDS_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Records</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECORDS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.ControlGateImpl <em>Control Gate</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.ControlGateImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getControlGate()
	 * @generated
	 */
	int CONTROL_GATE = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_GATE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Motor Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_GATE__MOTOR_STATUS = 1;

	/**
	 * The number of structural features of the '<em>Control Gate</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_GATE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Control Gate</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_GATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.EntranceSystemImpl <em>Entrance System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.EntranceSystemImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getEntranceSystem()
	 * @generated
	 */
	int ENTRANCE_SYSTEM = 6;

	/**
	 * The feature id for the '<em><b>Vehicle</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRANCE_SYSTEM__VEHICLE = 0;

	/**
	 * The feature id for the '<em><b>Motionsensor</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRANCE_SYSTEM__MOTIONSENSOR = 1;

	/**
	 * The feature id for the '<em><b>Dataacquisition</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRANCE_SYSTEM__DATAACQUISITION = 2;

	/**
	 * The feature id for the '<em><b>Dip</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRANCE_SYSTEM__DIP = 3;

	/**
	 * The feature id for the '<em><b>Records</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRANCE_SYSTEM__RECORDS = 4;

	/**
	 * The feature id for the '<em><b>Vehiclelocation</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRANCE_SYSTEM__VEHICLELOCATION = 5;

	/**
	 * The feature id for the '<em><b>Controlgate</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRANCE_SYSTEM__CONTROLGATE = 6;

	/**
	 * The feature id for the '<em><b>Pc</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRANCE_SYSTEM__PC = 7;

	/**
	 * The number of structural features of the '<em>Entrance System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRANCE_SYSTEM_FEATURE_COUNT = 8;

	/**
	 * The number of operations of the '<em>Entrance System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRANCE_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.VehicleLocationImpl <em>Vehicle Location</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.VehicleLocationImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getVehicleLocation()
	 * @generated
	 */
	int VEHICLE_LOCATION = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_LOCATION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_LOCATION__LOCATION = 1;

	/**
	 * The number of structural features of the '<em>Vehicle Location</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_LOCATION_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Vehicle Location</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_LOCATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.CameraImpl <em>Camera</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.CameraImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getCamera()
	 * @generated
	 */
	int CAMERA = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__NAME = DIP__NAME;

	/**
	 * The feature id for the '<em><b>Vehicle Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__VEHICLE_NUMBER = DIP__VEHICLE_NUMBER;

	/**
	 * The feature id for the '<em><b>Pc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__PC = DIP__PC;

	/**
	 * The feature id for the '<em><b>Comparison Result</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__COMPARISON_RESULT = DIP__COMPARISON_RESULT;

	/**
	 * The feature id for the '<em><b>Image</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__IMAGE = DIP_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Camera</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_FEATURE_COUNT = DIP_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Camera</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_OPERATION_COUNT = DIP_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.ImageImpl <em>Image</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.ImageImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getImage()
	 * @generated
	 */
	int IMAGE = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__NAME = DIP__NAME;

	/**
	 * The feature id for the '<em><b>Vehicle Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__VEHICLE_NUMBER = DIP__VEHICLE_NUMBER;

	/**
	 * The feature id for the '<em><b>Pc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__PC = DIP__PC;

	/**
	 * The feature id for the '<em><b>Comparison Result</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__COMPARISON_RESULT = DIP__COMPARISON_RESULT;

	/**
	 * The feature id for the '<em><b>Imageacquisition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__IMAGEACQUISITION = DIP_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Extn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__EXTN = DIP_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Image</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_FEATURE_COUNT = DIP_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Image</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_OPERATION_COUNT = DIP_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.ImageAcquisitionImpl <em>Image Acquisition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.ImageAcquisitionImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getImageAcquisition()
	 * @generated
	 */
	int IMAGE_ACQUISITION = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_ACQUISITION__NAME = DIP__NAME;

	/**
	 * The feature id for the '<em><b>Vehicle Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_ACQUISITION__VEHICLE_NUMBER = DIP__VEHICLE_NUMBER;

	/**
	 * The feature id for the '<em><b>Pc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_ACQUISITION__PC = DIP__PC;

	/**
	 * The feature id for the '<em><b>Comparison Result</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_ACQUISITION__COMPARISON_RESULT = DIP__COMPARISON_RESULT;

	/**
	 * The feature id for the '<em><b>Preprocessing</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_ACQUISITION__PREPROCESSING = DIP_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Image Acquisition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_ACQUISITION_FEATURE_COUNT = DIP_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Im Read</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_ACQUISITION___IM_READ = DIP_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Preview</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_ACQUISITION___PREVIEW = DIP_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Snapshot</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_ACQUISITION___SNAPSHOT = DIP_OPERATION_COUNT + 2;

	/**
	 * The number of operations of the '<em>Image Acquisition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_ACQUISITION_OPERATION_COUNT = DIP_OPERATION_COUNT + 3;

	/**
	 * The meta object id for the '{@link ms21paper.impl.PreprocessingImpl <em>Preprocessing</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.PreprocessingImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getPreprocessing()
	 * @generated
	 */
	int PREPROCESSING = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPROCESSING__NAME = DIP__NAME;

	/**
	 * The feature id for the '<em><b>Vehicle Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPROCESSING__VEHICLE_NUMBER = DIP__VEHICLE_NUMBER;

	/**
	 * The feature id for the '<em><b>Pc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPROCESSING__PC = DIP__PC;

	/**
	 * The feature id for the '<em><b>Comparison Result</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPROCESSING__COMPARISON_RESULT = DIP__COMPARISON_RESULT;

	/**
	 * The feature id for the '<em><b>Regionofinterest</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPROCESSING__REGIONOFINTEREST = DIP_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Preprocessing</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPROCESSING_FEATURE_COUNT = DIP_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Resize</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPROCESSING___RESIZE = DIP_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Rgb2gray</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPROCESSING___RGB2GRAY = DIP_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Im Show</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPROCESSING___IM_SHOW = DIP_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Im Binrize</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPROCESSING___IM_BINRIZE = DIP_OPERATION_COUNT + 3;

	/**
	 * The operation id for the '<em>Histeq</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPROCESSING___HISTEQ = DIP_OPERATION_COUNT + 4;

	/**
	 * The number of operations of the '<em>Preprocessing</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREPROCESSING_OPERATION_COUNT = DIP_OPERATION_COUNT + 5;

	/**
	 * The meta object id for the '{@link ms21paper.impl.CharacterRecognitionImpl <em>Character Recognition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.CharacterRecognitionImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getCharacterRecognition()
	 * @generated
	 */
	int CHARACTER_RECOGNITION = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_RECOGNITION__NAME = DIP__NAME;

	/**
	 * The feature id for the '<em><b>Vehicle Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_RECOGNITION__VEHICLE_NUMBER = DIP__VEHICLE_NUMBER;

	/**
	 * The feature id for the '<em><b>Pc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_RECOGNITION__PC = DIP__PC;

	/**
	 * The feature id for the '<em><b>Comparison Result</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_RECOGNITION__COMPARISON_RESULT = DIP__COMPARISON_RESULT;

	/**
	 * The feature id for the '<em><b>Templates</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_RECOGNITION__TEMPLATES = DIP_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Character Recognition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_RECOGNITION_FEATURE_COUNT = DIP_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Imread</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_RECOGNITION___IMREAD = DIP_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Find Correlation</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_RECOGNITION___FIND_CORRELATION = DIP_OPERATION_COUNT + 1;

	/**
	 * The number of operations of the '<em>Character Recognition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_RECOGNITION_OPERATION_COUNT = DIP_OPERATION_COUNT + 2;

	/**
	 * The meta object id for the '{@link ms21paper.impl.TemplatesImpl <em>Templates</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.TemplatesImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getTemplates()
	 * @generated
	 */
	int TEMPLATES = 13;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPLATES__NAME = DIP__NAME;

	/**
	 * The feature id for the '<em><b>Vehicle Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPLATES__VEHICLE_NUMBER = DIP__VEHICLE_NUMBER;

	/**
	 * The feature id for the '<em><b>Pc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPLATES__PC = DIP__PC;

	/**
	 * The feature id for the '<em><b>Comparison Result</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPLATES__COMPARISON_RESULT = DIP__COMPARISON_RESULT;

	/**
	 * The feature id for the '<em><b>Characterrecognition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPLATES__CHARACTERRECOGNITION = DIP_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Binaryimage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPLATES__BINARYIMAGE = DIP_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Imextn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPLATES__IMEXTN = DIP_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Templates</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPLATES_FEATURE_COUNT = DIP_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Templates</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPLATES_OPERATION_COUNT = DIP_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.RegionOfInterestImpl <em>Region Of Interest</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.RegionOfInterestImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getRegionOfInterest()
	 * @generated
	 */
	int REGION_OF_INTEREST = 14;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGION_OF_INTEREST__NAME = DIP__NAME;

	/**
	 * The feature id for the '<em><b>Vehicle Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGION_OF_INTEREST__VEHICLE_NUMBER = DIP__VEHICLE_NUMBER;

	/**
	 * The feature id for the '<em><b>Pc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGION_OF_INTEREST__PC = DIP__PC;

	/**
	 * The feature id for the '<em><b>Comparison Result</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGION_OF_INTEREST__COMPARISON_RESULT = DIP__COMPARISON_RESULT;

	/**
	 * The feature id for the '<em><b>Charactersegmentation</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGION_OF_INTEREST__CHARACTERSEGMENTATION = DIP_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Region Of Interest</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGION_OF_INTEREST_FEATURE_COUNT = DIP_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Edge</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGION_OF_INTEREST___EDGE = DIP_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Bwlabel</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGION_OF_INTEREST___BWLABEL = DIP_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Regionprops</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGION_OF_INTEREST___REGIONPROPS = DIP_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Imdialate</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGION_OF_INTEREST___IMDIALATE = DIP_OPERATION_COUNT + 3;

	/**
	 * The operation id for the '<em>Imerode</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGION_OF_INTEREST___IMERODE = DIP_OPERATION_COUNT + 4;

	/**
	 * The number of operations of the '<em>Region Of Interest</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REGION_OF_INTEREST_OPERATION_COUNT = DIP_OPERATION_COUNT + 5;

	/**
	 * The meta object id for the '{@link ms21paper.impl.FilteringImpl <em>Filtering</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.FilteringImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getFiltering()
	 * @generated
	 */
	int FILTERING = 29;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERING__NAME = PREPROCESSING__NAME;

	/**
	 * The feature id for the '<em><b>Vehicle Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERING__VEHICLE_NUMBER = PREPROCESSING__VEHICLE_NUMBER;

	/**
	 * The feature id for the '<em><b>Pc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERING__PC = PREPROCESSING__PC;

	/**
	 * The feature id for the '<em><b>Comparison Result</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERING__COMPARISON_RESULT = PREPROCESSING__COMPARISON_RESULT;

	/**
	 * The feature id for the '<em><b>Regionofinterest</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERING__REGIONOFINTEREST = PREPROCESSING__REGIONOFINTEREST;

	/**
	 * The feature id for the '<em><b>Masksize</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERING__MASKSIZE = PREPROCESSING_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Filtering</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERING_FEATURE_COUNT = PREPROCESSING_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Resize</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERING___RESIZE = PREPROCESSING___RESIZE;

	/**
	 * The operation id for the '<em>Rgb2gray</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERING___RGB2GRAY = PREPROCESSING___RGB2GRAY;

	/**
	 * The operation id for the '<em>Im Show</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERING___IM_SHOW = PREPROCESSING___IM_SHOW;

	/**
	 * The operation id for the '<em>Im Binrize</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERING___IM_BINRIZE = PREPROCESSING___IM_BINRIZE;

	/**
	 * The operation id for the '<em>Histeq</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERING___HISTEQ = PREPROCESSING___HISTEQ;

	/**
	 * The number of operations of the '<em>Filtering</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERING_OPERATION_COUNT = PREPROCESSING_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.SmoothingFilterImpl <em>Smoothing Filter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.SmoothingFilterImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getSmoothingFilter()
	 * @generated
	 */
	int SMOOTHING_FILTER = 15;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMOOTHING_FILTER__NAME = FILTERING__NAME;

	/**
	 * The feature id for the '<em><b>Vehicle Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMOOTHING_FILTER__VEHICLE_NUMBER = FILTERING__VEHICLE_NUMBER;

	/**
	 * The feature id for the '<em><b>Pc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMOOTHING_FILTER__PC = FILTERING__PC;

	/**
	 * The feature id for the '<em><b>Comparison Result</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMOOTHING_FILTER__COMPARISON_RESULT = FILTERING__COMPARISON_RESULT;

	/**
	 * The feature id for the '<em><b>Regionofinterest</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMOOTHING_FILTER__REGIONOFINTEREST = FILTERING__REGIONOFINTEREST;

	/**
	 * The feature id for the '<em><b>Masksize</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMOOTHING_FILTER__MASKSIZE = FILTERING__MASKSIZE;

	/**
	 * The number of structural features of the '<em>Smoothing Filter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMOOTHING_FILTER_FEATURE_COUNT = FILTERING_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Resize</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMOOTHING_FILTER___RESIZE = FILTERING___RESIZE;

	/**
	 * The operation id for the '<em>Rgb2gray</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMOOTHING_FILTER___RGB2GRAY = FILTERING___RGB2GRAY;

	/**
	 * The operation id for the '<em>Im Show</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMOOTHING_FILTER___IM_SHOW = FILTERING___IM_SHOW;

	/**
	 * The operation id for the '<em>Im Binrize</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMOOTHING_FILTER___IM_BINRIZE = FILTERING___IM_BINRIZE;

	/**
	 * The operation id for the '<em>Histeq</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMOOTHING_FILTER___HISTEQ = FILTERING___HISTEQ;

	/**
	 * The operation id for the '<em>Average</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMOOTHING_FILTER___AVERAGE = FILTERING_OPERATION_COUNT + 0;

	/**
	 * The number of operations of the '<em>Smoothing Filter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMOOTHING_FILTER_OPERATION_COUNT = FILTERING_OPERATION_COUNT + 1;

	/**
	 * The meta object id for the '{@link ms21paper.impl.SharpeningImpl <em>Sharpening</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.SharpeningImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getSharpening()
	 * @generated
	 */
	int SHARPENING = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARPENING__NAME = FILTERING__NAME;

	/**
	 * The feature id for the '<em><b>Vehicle Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARPENING__VEHICLE_NUMBER = FILTERING__VEHICLE_NUMBER;

	/**
	 * The feature id for the '<em><b>Pc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARPENING__PC = FILTERING__PC;

	/**
	 * The feature id for the '<em><b>Comparison Result</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARPENING__COMPARISON_RESULT = FILTERING__COMPARISON_RESULT;

	/**
	 * The feature id for the '<em><b>Regionofinterest</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARPENING__REGIONOFINTEREST = FILTERING__REGIONOFINTEREST;

	/**
	 * The feature id for the '<em><b>Masksize</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARPENING__MASKSIZE = FILTERING__MASKSIZE;

	/**
	 * The number of structural features of the '<em>Sharpening</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARPENING_FEATURE_COUNT = FILTERING_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Resize</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARPENING___RESIZE = FILTERING___RESIZE;

	/**
	 * The operation id for the '<em>Rgb2gray</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARPENING___RGB2GRAY = FILTERING___RGB2GRAY;

	/**
	 * The operation id for the '<em>Im Show</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARPENING___IM_SHOW = FILTERING___IM_SHOW;

	/**
	 * The operation id for the '<em>Im Binrize</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARPENING___IM_BINRIZE = FILTERING___IM_BINRIZE;

	/**
	 * The operation id for the '<em>Histeq</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARPENING___HISTEQ = FILTERING___HISTEQ;

	/**
	 * The number of operations of the '<em>Sharpening</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHARPENING_OPERATION_COUNT = FILTERING_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.CharacterSegmentationImpl <em>Character Segmentation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.CharacterSegmentationImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getCharacterSegmentation()
	 * @generated
	 */
	int CHARACTER_SEGMENTATION = 17;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_SEGMENTATION__NAME = DIP__NAME;

	/**
	 * The feature id for the '<em><b>Vehicle Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_SEGMENTATION__VEHICLE_NUMBER = DIP__VEHICLE_NUMBER;

	/**
	 * The feature id for the '<em><b>Pc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_SEGMENTATION__PC = DIP__PC;

	/**
	 * The feature id for the '<em><b>Comparison Result</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_SEGMENTATION__COMPARISON_RESULT = DIP__COMPARISON_RESULT;

	/**
	 * The feature id for the '<em><b>Characterrecognition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_SEGMENTATION__CHARACTERRECOGNITION = DIP_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Character Segmentation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_SEGMENTATION_FEATURE_COUNT = DIP_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Edgedetection</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_SEGMENTATION___EDGEDETECTION = DIP_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Bwareaopen</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_SEGMENTATION___BWAREAOPEN = DIP_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Imcrop</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_SEGMENTATION___IMCROP = DIP_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Imresize</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_SEGMENTATION___IMRESIZE = DIP_OPERATION_COUNT + 3;

	/**
	 * The number of operations of the '<em>Character Segmentation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARACTER_SEGMENTATION_OPERATION_COUNT = DIP_OPERATION_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Dataacquisition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTION_SENSOR__DATAACQUISITION = SENSOR__DATAACQUISITION;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTION_SENSOR__NAME = SENSOR__NAME;

	/**
	 * The feature id for the '<em><b>Sensor Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTION_SENSOR__SENSOR_DATA = SENSOR__SENSOR_DATA;

	/**
	 * The number of structural features of the '<em>Motion Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTION_SENSOR_FEATURE_COUNT = SENSOR_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Motion Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTION_SENSOR_OPERATION_COUNT = SENSOR_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Dataacquisition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IR_SSENSOR__DATAACQUISITION = SENSOR__DATAACQUISITION;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IR_SSENSOR__NAME = SENSOR__NAME;

	/**
	 * The feature id for the '<em><b>Sensor Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IR_SSENSOR__SENSOR_DATA = SENSOR__SENSOR_DATA;

	/**
	 * The number of structural features of the '<em>IR Ssensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IR_SSENSOR_FEATURE_COUNT = SENSOR_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>IR Ssensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IR_SSENSOR_OPERATION_COUNT = SENSOR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.PCImpl <em>PC</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.PCImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getPC()
	 * @generated
	 */
	int PC = 20;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PC__NAME = 0;

	/**
	 * The feature id for the '<em><b>Vnumber</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PC__VNUMBER = 1;

	/**
	 * The feature id for the '<em><b>Dataacquisition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PC__DATAACQUISITION = 2;

	/**
	 * The feature id for the '<em><b>Records</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PC__RECORDS = 3;

	/**
	 * The feature id for the '<em><b>Dip</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PC__DIP = 4;

	/**
	 * The feature id for the '<em><b>Vehiclelocation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PC__VEHICLELOCATION = 5;

	/**
	 * The feature id for the '<em><b>Vehicle Record</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PC__VEHICLE_RECORD = 6;

	/**
	 * The number of structural features of the '<em>PC</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PC_FEATURE_COUNT = 7;

	/**
	 * The number of operations of the '<em>PC</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PC_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.SurvilanceAndTrackingSytemsImpl <em>Survilance And Tracking Sytems</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.SurvilanceAndTrackingSytemsImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getSurvilanceAndTrackingSytems()
	 * @generated
	 */
	int SURVILANCE_AND_TRACKING_SYTEMS = 21;

	/**
	 * The feature id for the '<em><b>Entrancesystem</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SURVILANCE_AND_TRACKING_SYTEMS__ENTRANCESYSTEM = 0;

	/**
	 * The number of structural features of the '<em>Survilance And Tracking Sytems</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SURVILANCE_AND_TRACKING_SYTEMS_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Survilance And Tracking Sytems</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SURVILANCE_AND_TRACKING_SYTEMS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.ToolCollectionSystemImpl <em>Tool Collection System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.ToolCollectionSystemImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getToolCollectionSystem()
	 * @generated
	 */
	int TOOL_COLLECTION_SYSTEM = 22;

	/**
	 * The feature id for the '<em><b>Entrancesystem</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOOL_COLLECTION_SYSTEM__ENTRANCESYSTEM = 0;

	/**
	 * The number of structural features of the '<em>Tool Collection System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOOL_COLLECTION_SYSTEM_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Tool Collection System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOOL_COLLECTION_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.SecuritySystemsImpl <em>Security Systems</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.SecuritySystemsImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getSecuritySystems()
	 * @generated
	 */
	int SECURITY_SYSTEMS = 23;

	/**
	 * The feature id for the '<em><b>Entrancesystem</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECURITY_SYSTEMS__ENTRANCESYSTEM = 0;

	/**
	 * The number of structural features of the '<em>Security Systems</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECURITY_SYSTEMS_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Security Systems</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECURITY_SYSTEMS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.ParkingSystemsImpl <em>Parking Systems</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.ParkingSystemsImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getParkingSystems()
	 * @generated
	 */
	int PARKING_SYSTEMS = 24;

	/**
	 * The feature id for the '<em><b>Entrancesystem</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING_SYSTEMS__ENTRANCESYSTEM = 0;

	/**
	 * The number of structural features of the '<em>Parking Systems</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING_SYSTEMS_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Parking Systems</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING_SYSTEMS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.GeographicalMapsImpl <em>Geographical Maps</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.GeographicalMapsImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getGeographicalMaps()
	 * @generated
	 */
	int GEOGRAPHICAL_MAPS = 25;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEOGRAPHICAL_MAPS__NAME = 0;

	/**
	 * The feature id for the '<em><b>Vehiclelocation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEOGRAPHICAL_MAPS__VEHICLELOCATION = 1;

	/**
	 * The number of structural features of the '<em>Geographical Maps</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEOGRAPHICAL_MAPS_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Geographical Maps</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEOGRAPHICAL_MAPS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.PortImpl <em>Port</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.PortImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getPort()
	 * @generated
	 */
	int PORT = 26;

	/**
	 * The feature id for the '<em><b>Pin</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__PIN = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__TYPE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__NAME = 2;

	/**
	 * The number of structural features of the '<em>Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.InputImpl <em>Input</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.InputImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getInput()
	 * @generated
	 */
	int INPUT = 27;

	/**
	 * The feature id for the '<em><b>Pin</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT__PIN = PORT__PIN;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT__TYPE = PORT__TYPE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT__NAME = PORT__NAME;

	/**
	 * The feature id for the '<em><b>Sdata</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT__SDATA = PORT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Motionsensor</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT__MOTIONSENSOR = PORT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Input</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_FEATURE_COUNT = PORT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Input</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_OPERATION_COUNT = PORT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ms21paper.impl.OutputImpl <em>Output</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.impl.OutputImpl
	 * @see ms21paper.impl.Ms21paperPackageImpl#getOutput()
	 * @generated
	 */
	int OUTPUT = 28;

	/**
	 * The feature id for the '<em><b>Pin</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__PIN = PORT__PIN;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__TYPE = PORT__TYPE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__NAME = PORT__NAME;

	/**
	 * The feature id for the '<em><b>Motor Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__MOTOR_STATUS = PORT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Controlgate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__CONTROLGATE = PORT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Output</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_FEATURE_COUNT = PORT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Output</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_OPERATION_COUNT = PORT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link ms21paper.TypeController <em>Type Controller</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.TypeController
	 * @see ms21paper.impl.Ms21paperPackageImpl#getTypeController()
	 * @generated
	 */
	int TYPE_CONTROLLER = 30;

	/**
	 * The meta object id for the '{@link ms21paper.TypePort <em>Type Port</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ms21paper.TypePort
	 * @see ms21paper.impl.Ms21paperPackageImpl#getTypePort()
	 * @generated
	 */
	int TYPE_PORT = 31;

	/**
	 * Returns the meta object for class '{@link ms21paper.Vehicle <em>Vehicle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Vehicle</em>'.
	 * @see ms21paper.Vehicle
	 * @generated
	 */
	EClass getVehicle();

	/**
	 * Returns the meta object for the reference list '{@link ms21paper.Vehicle#getMotionsensor <em>Motionsensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Motionsensor</em>'.
	 * @see ms21paper.Vehicle#getMotionsensor()
	 * @see #getVehicle()
	 * @generated
	 */
	EReference getVehicle_Motionsensor();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Vehicle#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ms21paper.Vehicle#getName()
	 * @see #getVehicle()
	 * @generated
	 */
	EAttribute getVehicle_Name();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Vehicle#getVnumber <em>Vnumber</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Vnumber</em>'.
	 * @see ms21paper.Vehicle#getVnumber()
	 * @see #getVehicle()
	 * @generated
	 */
	EAttribute getVehicle_Vnumber();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Vehicle#getOwnerID <em>Owner ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Owner ID</em>'.
	 * @see ms21paper.Vehicle#getOwnerID()
	 * @see #getVehicle()
	 * @generated
	 */
	EAttribute getVehicle_OwnerID();

	/**
	 * Returns the meta object for class '{@link ms21paper.Sensor <em>Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sensor</em>'.
	 * @see ms21paper.Sensor
	 * @generated
	 */
	EClass getSensor();

	/**
	 * Returns the meta object for the reference list '{@link ms21paper.Sensor#getDataacquisition <em>Dataacquisition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Dataacquisition</em>'.
	 * @see ms21paper.Sensor#getDataacquisition()
	 * @see #getSensor()
	 * @generated
	 */
	EReference getSensor_Dataacquisition();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Sensor#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ms21paper.Sensor#getName()
	 * @see #getSensor()
	 * @generated
	 */
	EAttribute getSensor_Name();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Sensor#isSensorData <em>Sensor Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sensor Data</em>'.
	 * @see ms21paper.Sensor#isSensorData()
	 * @see #getSensor()
	 * @generated
	 */
	EAttribute getSensor_SensorData();

	/**
	 * Returns the meta object for class '{@link ms21paper.MotionSensor <em>Motion Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Motion Sensor</em>'.
	 * @see ms21paper.MotionSensor
	 * @generated
	 */
	EClass getMotionSensor();

	/**
	 * Returns the meta object for class '{@link ms21paper.IRSsensor <em>IR Ssensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>IR Ssensor</em>'.
	 * @see ms21paper.IRSsensor
	 * @generated
	 */
	EClass getIRSsensor();

	/**
	 * Returns the meta object for class '{@link ms21paper.PC <em>PC</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>PC</em>'.
	 * @see ms21paper.PC
	 * @generated
	 */
	EClass getPC();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.PC#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ms21paper.PC#getName()
	 * @see #getPC()
	 * @generated
	 */
	EAttribute getPC_Name();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.PC#getVnumber <em>Vnumber</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Vnumber</em>'.
	 * @see ms21paper.PC#getVnumber()
	 * @see #getPC()
	 * @generated
	 */
	EAttribute getPC_Vnumber();

	/**
	 * Returns the meta object for the reference list '{@link ms21paper.PC#getDataacquisition <em>Dataacquisition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Dataacquisition</em>'.
	 * @see ms21paper.PC#getDataacquisition()
	 * @see #getPC()
	 * @generated
	 */
	EReference getPC_Dataacquisition();

	/**
	 * Returns the meta object for the reference list '{@link ms21paper.PC#getRecords <em>Records</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Records</em>'.
	 * @see ms21paper.PC#getRecords()
	 * @see #getPC()
	 * @generated
	 */
	EReference getPC_Records();

	/**
	 * Returns the meta object for the reference list '{@link ms21paper.PC#getDip <em>Dip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Dip</em>'.
	 * @see ms21paper.PC#getDip()
	 * @see #getPC()
	 * @generated
	 */
	EReference getPC_Dip();

	/**
	 * Returns the meta object for the reference '{@link ms21paper.PC#getVehiclelocation <em>Vehiclelocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Vehiclelocation</em>'.
	 * @see ms21paper.PC#getVehiclelocation()
	 * @see #getPC()
	 * @generated
	 */
	EReference getPC_Vehiclelocation();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.PC#getVehicleRecord <em>Vehicle Record</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Vehicle Record</em>'.
	 * @see ms21paper.PC#getVehicleRecord()
	 * @see #getPC()
	 * @generated
	 */
	EAttribute getPC_VehicleRecord();

	/**
	 * Returns the meta object for class '{@link ms21paper.SurvilanceAndTrackingSytems <em>Survilance And Tracking Sytems</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Survilance And Tracking Sytems</em>'.
	 * @see ms21paper.SurvilanceAndTrackingSytems
	 * @generated
	 */
	EClass getSurvilanceAndTrackingSytems();

	/**
	 * Returns the meta object for the containment reference '{@link ms21paper.SurvilanceAndTrackingSytems#getEntrancesystem <em>Entrancesystem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Entrancesystem</em>'.
	 * @see ms21paper.SurvilanceAndTrackingSytems#getEntrancesystem()
	 * @see #getSurvilanceAndTrackingSytems()
	 * @generated
	 */
	EReference getSurvilanceAndTrackingSytems_Entrancesystem();

	/**
	 * Returns the meta object for class '{@link ms21paper.ToolCollectionSystem <em>Tool Collection System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tool Collection System</em>'.
	 * @see ms21paper.ToolCollectionSystem
	 * @generated
	 */
	EClass getToolCollectionSystem();

	/**
	 * Returns the meta object for the containment reference '{@link ms21paper.ToolCollectionSystem#getEntrancesystem <em>Entrancesystem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Entrancesystem</em>'.
	 * @see ms21paper.ToolCollectionSystem#getEntrancesystem()
	 * @see #getToolCollectionSystem()
	 * @generated
	 */
	EReference getToolCollectionSystem_Entrancesystem();

	/**
	 * Returns the meta object for class '{@link ms21paper.SecuritySystems <em>Security Systems</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Security Systems</em>'.
	 * @see ms21paper.SecuritySystems
	 * @generated
	 */
	EClass getSecuritySystems();

	/**
	 * Returns the meta object for the containment reference '{@link ms21paper.SecuritySystems#getEntrancesystem <em>Entrancesystem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Entrancesystem</em>'.
	 * @see ms21paper.SecuritySystems#getEntrancesystem()
	 * @see #getSecuritySystems()
	 * @generated
	 */
	EReference getSecuritySystems_Entrancesystem();

	/**
	 * Returns the meta object for class '{@link ms21paper.ParkingSystems <em>Parking Systems</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Parking Systems</em>'.
	 * @see ms21paper.ParkingSystems
	 * @generated
	 */
	EClass getParkingSystems();

	/**
	 * Returns the meta object for the containment reference '{@link ms21paper.ParkingSystems#getEntrancesystem <em>Entrancesystem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Entrancesystem</em>'.
	 * @see ms21paper.ParkingSystems#getEntrancesystem()
	 * @see #getParkingSystems()
	 * @generated
	 */
	EReference getParkingSystems_Entrancesystem();

	/**
	 * Returns the meta object for class '{@link ms21paper.GeographicalMaps <em>Geographical Maps</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Geographical Maps</em>'.
	 * @see ms21paper.GeographicalMaps
	 * @generated
	 */
	EClass getGeographicalMaps();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.GeographicalMaps#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ms21paper.GeographicalMaps#getName()
	 * @see #getGeographicalMaps()
	 * @generated
	 */
	EAttribute getGeographicalMaps_Name();

	/**
	 * Returns the meta object for the reference '{@link ms21paper.GeographicalMaps#getVehiclelocation <em>Vehiclelocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Vehiclelocation</em>'.
	 * @see ms21paper.GeographicalMaps#getVehiclelocation()
	 * @see #getGeographicalMaps()
	 * @generated
	 */
	EReference getGeographicalMaps_Vehiclelocation();

	/**
	 * Returns the meta object for class '{@link ms21paper.Port <em>Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Port</em>'.
	 * @see ms21paper.Port
	 * @generated
	 */
	EClass getPort();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Port#getPin <em>Pin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Pin</em>'.
	 * @see ms21paper.Port#getPin()
	 * @see #getPort()
	 * @generated
	 */
	EAttribute getPort_Pin();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Port#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see ms21paper.Port#getType()
	 * @see #getPort()
	 * @generated
	 */
	EAttribute getPort_Type();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Port#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ms21paper.Port#getName()
	 * @see #getPort()
	 * @generated
	 */
	EAttribute getPort_Name();

	/**
	 * Returns the meta object for class '{@link ms21paper.Input <em>Input</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Input</em>'.
	 * @see ms21paper.Input
	 * @generated
	 */
	EClass getInput();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Input#isSdata <em>Sdata</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sdata</em>'.
	 * @see ms21paper.Input#isSdata()
	 * @see #getInput()
	 * @generated
	 */
	EAttribute getInput_Sdata();

	/**
	 * Returns the meta object for the reference list '{@link ms21paper.Input#getMotionsensor <em>Motionsensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Motionsensor</em>'.
	 * @see ms21paper.Input#getMotionsensor()
	 * @see #getInput()
	 * @generated
	 */
	EReference getInput_Motionsensor();

	/**
	 * Returns the meta object for class '{@link ms21paper.Output <em>Output</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Output</em>'.
	 * @see ms21paper.Output
	 * @generated
	 */
	EClass getOutput();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Output#isMotorStatus <em>Motor Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Motor Status</em>'.
	 * @see ms21paper.Output#isMotorStatus()
	 * @see #getOutput()
	 * @generated
	 */
	EAttribute getOutput_MotorStatus();

	/**
	 * Returns the meta object for the reference '{@link ms21paper.Output#getControlgate <em>Controlgate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Controlgate</em>'.
	 * @see ms21paper.Output#getControlgate()
	 * @see #getOutput()
	 * @generated
	 */
	EReference getOutput_Controlgate();

	/**
	 * Returns the meta object for class '{@link ms21paper.Filtering <em>Filtering</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Filtering</em>'.
	 * @see ms21paper.Filtering
	 * @generated
	 */
	EClass getFiltering();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Filtering#getMasksize <em>Masksize</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Masksize</em>'.
	 * @see ms21paper.Filtering#getMasksize()
	 * @see #getFiltering()
	 * @generated
	 */
	EAttribute getFiltering_Masksize();

	/**
	 * Returns the meta object for enum '{@link ms21paper.TypeController <em>Type Controller</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Type Controller</em>'.
	 * @see ms21paper.TypeController
	 * @generated
	 */
	EEnum getTypeController();

	/**
	 * Returns the meta object for enum '{@link ms21paper.TypePort <em>Type Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Type Port</em>'.
	 * @see ms21paper.TypePort
	 * @generated
	 */
	EEnum getTypePort();

	/**
	 * Returns the meta object for class '{@link ms21paper.DataAcquisition <em>Data Acquisition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Data Acquisition</em>'.
	 * @see ms21paper.DataAcquisition
	 * @generated
	 */
	EClass getDataAcquisition();

	/**
	 * Returns the meta object for the reference '{@link ms21paper.DataAcquisition#getControlgate <em>Controlgate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Controlgate</em>'.
	 * @see ms21paper.DataAcquisition#getControlgate()
	 * @see #getDataAcquisition()
	 * @generated
	 */
	EReference getDataAcquisition_Controlgate();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.DataAcquisition#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see ms21paper.DataAcquisition#getType()
	 * @see #getDataAcquisition()
	 * @generated
	 */
	EAttribute getDataAcquisition_Type();

	/**
	 * Returns the meta object for the reference '{@link ms21paper.DataAcquisition#getPc <em>Pc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Pc</em>'.
	 * @see ms21paper.DataAcquisition#getPc()
	 * @see #getDataAcquisition()
	 * @generated
	 */
	EReference getDataAcquisition_Pc();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.DataAcquisition#getSensorData <em>Sensor Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sensor Data</em>'.
	 * @see ms21paper.DataAcquisition#getSensorData()
	 * @see #getDataAcquisition()
	 * @generated
	 */
	EAttribute getDataAcquisition_SensorData();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.DataAcquisition#isMotorStatus <em>Motor Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Motor Status</em>'.
	 * @see ms21paper.DataAcquisition#isMotorStatus()
	 * @see #getDataAcquisition()
	 * @generated
	 */
	EAttribute getDataAcquisition_MotorStatus();

	/**
	 * Returns the meta object for the containment reference list '{@link ms21paper.DataAcquisition#getPort <em>Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Port</em>'.
	 * @see ms21paper.DataAcquisition#getPort()
	 * @see #getDataAcquisition()
	 * @generated
	 */
	EReference getDataAcquisition_Port();

	/**
	 * Returns the meta object for class '{@link ms21paper.DIP <em>DIP</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>DIP</em>'.
	 * @see ms21paper.DIP
	 * @generated
	 */
	EClass getDIP();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.DIP#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ms21paper.DIP#getName()
	 * @see #getDIP()
	 * @generated
	 */
	EAttribute getDIP_Name();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.DIP#getVehicleNumber <em>Vehicle Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Vehicle Number</em>'.
	 * @see ms21paper.DIP#getVehicleNumber()
	 * @see #getDIP()
	 * @generated
	 */
	EAttribute getDIP_VehicleNumber();

	/**
	 * Returns the meta object for the reference '{@link ms21paper.DIP#getPc <em>Pc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Pc</em>'.
	 * @see ms21paper.DIP#getPc()
	 * @see #getDIP()
	 * @generated
	 */
	EReference getDIP_Pc();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.DIP#isComparisonResult <em>Comparison Result</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Comparison Result</em>'.
	 * @see ms21paper.DIP#isComparisonResult()
	 * @see #getDIP()
	 * @generated
	 */
	EAttribute getDIP_ComparisonResult();

	/**
	 * Returns the meta object for class '{@link ms21paper.Records <em>Records</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Records</em>'.
	 * @see ms21paper.Records
	 * @generated
	 */
	EClass getRecords();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Records#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ms21paper.Records#getName()
	 * @see #getRecords()
	 * @generated
	 */
	EAttribute getRecords_Name();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Records#getVnumber <em>Vnumber</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Vnumber</em>'.
	 * @see ms21paper.Records#getVnumber()
	 * @see #getRecords()
	 * @generated
	 */
	EAttribute getRecords_Vnumber();

	/**
	 * Returns the meta object for the reference '{@link ms21paper.Records#getPc <em>Pc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Pc</em>'.
	 * @see ms21paper.Records#getPc()
	 * @see #getRecords()
	 * @generated
	 */
	EReference getRecords_Pc();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Records#getVOwnerID <em>VOwner ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>VOwner ID</em>'.
	 * @see ms21paper.Records#getVOwnerID()
	 * @see #getRecords()
	 * @generated
	 */
	EAttribute getRecords_VOwnerID();

	/**
	 * Returns the meta object for class '{@link ms21paper.ControlGate <em>Control Gate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Control Gate</em>'.
	 * @see ms21paper.ControlGate
	 * @generated
	 */
	EClass getControlGate();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.ControlGate#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ms21paper.ControlGate#getName()
	 * @see #getControlGate()
	 * @generated
	 */
	EAttribute getControlGate_Name();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.ControlGate#isMotorStatus <em>Motor Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Motor Status</em>'.
	 * @see ms21paper.ControlGate#isMotorStatus()
	 * @see #getControlGate()
	 * @generated
	 */
	EAttribute getControlGate_MotorStatus();

	/**
	 * Returns the meta object for class '{@link ms21paper.EntranceSystem <em>Entrance System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Entrance System</em>'.
	 * @see ms21paper.EntranceSystem
	 * @generated
	 */
	EClass getEntranceSystem();

	/**
	 * Returns the meta object for the containment reference '{@link ms21paper.EntranceSystem#getVehicle <em>Vehicle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Vehicle</em>'.
	 * @see ms21paper.EntranceSystem#getVehicle()
	 * @see #getEntranceSystem()
	 * @generated
	 */
	EReference getEntranceSystem_Vehicle();

	/**
	 * Returns the meta object for the containment reference list '{@link ms21paper.EntranceSystem#getMotionsensor <em>Motionsensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Motionsensor</em>'.
	 * @see ms21paper.EntranceSystem#getMotionsensor()
	 * @see #getEntranceSystem()
	 * @generated
	 */
	EReference getEntranceSystem_Motionsensor();

	/**
	 * Returns the meta object for the containment reference list '{@link ms21paper.EntranceSystem#getDataacquisition <em>Dataacquisition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dataacquisition</em>'.
	 * @see ms21paper.EntranceSystem#getDataacquisition()
	 * @see #getEntranceSystem()
	 * @generated
	 */
	EReference getEntranceSystem_Dataacquisition();

	/**
	 * Returns the meta object for the containment reference list '{@link ms21paper.EntranceSystem#getDip <em>Dip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dip</em>'.
	 * @see ms21paper.EntranceSystem#getDip()
	 * @see #getEntranceSystem()
	 * @generated
	 */
	EReference getEntranceSystem_Dip();

	/**
	 * Returns the meta object for the containment reference list '{@link ms21paper.EntranceSystem#getRecords <em>Records</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Records</em>'.
	 * @see ms21paper.EntranceSystem#getRecords()
	 * @see #getEntranceSystem()
	 * @generated
	 */
	EReference getEntranceSystem_Records();

	/**
	 * Returns the meta object for the containment reference '{@link ms21paper.EntranceSystem#getVehiclelocation <em>Vehiclelocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Vehiclelocation</em>'.
	 * @see ms21paper.EntranceSystem#getVehiclelocation()
	 * @see #getEntranceSystem()
	 * @generated
	 */
	EReference getEntranceSystem_Vehiclelocation();

	/**
	 * Returns the meta object for the containment reference '{@link ms21paper.EntranceSystem#getControlgate <em>Controlgate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Controlgate</em>'.
	 * @see ms21paper.EntranceSystem#getControlgate()
	 * @see #getEntranceSystem()
	 * @generated
	 */
	EReference getEntranceSystem_Controlgate();

	/**
	 * Returns the meta object for the containment reference list '{@link ms21paper.EntranceSystem#getPc <em>Pc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Pc</em>'.
	 * @see ms21paper.EntranceSystem#getPc()
	 * @see #getEntranceSystem()
	 * @generated
	 */
	EReference getEntranceSystem_Pc();

	/**
	 * Returns the meta object for class '{@link ms21paper.VehicleLocation <em>Vehicle Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Vehicle Location</em>'.
	 * @see ms21paper.VehicleLocation
	 * @generated
	 */
	EClass getVehicleLocation();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.VehicleLocation#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ms21paper.VehicleLocation#getName()
	 * @see #getVehicleLocation()
	 * @generated
	 */
	EAttribute getVehicleLocation_Name();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.VehicleLocation#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Location</em>'.
	 * @see ms21paper.VehicleLocation#getLocation()
	 * @see #getVehicleLocation()
	 * @generated
	 */
	EAttribute getVehicleLocation_Location();

	/**
	 * Returns the meta object for class '{@link ms21paper.Camera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Camera</em>'.
	 * @see ms21paper.Camera
	 * @generated
	 */
	EClass getCamera();

	/**
	 * Returns the meta object for the reference list '{@link ms21paper.Camera#getImage <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Image</em>'.
	 * @see ms21paper.Camera#getImage()
	 * @see #getCamera()
	 * @generated
	 */
	EReference getCamera_Image();

	/**
	 * Returns the meta object for class '{@link ms21paper.Image <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Image</em>'.
	 * @see ms21paper.Image
	 * @generated
	 */
	EClass getImage();

	/**
	 * Returns the meta object for the reference list '{@link ms21paper.Image#getImageacquisition <em>Imageacquisition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Imageacquisition</em>'.
	 * @see ms21paper.Image#getImageacquisition()
	 * @see #getImage()
	 * @generated
	 */
	EReference getImage_Imageacquisition();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Image#getExtn <em>Extn</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Extn</em>'.
	 * @see ms21paper.Image#getExtn()
	 * @see #getImage()
	 * @generated
	 */
	EAttribute getImage_Extn();

	/**
	 * Returns the meta object for class '{@link ms21paper.ImageAcquisition <em>Image Acquisition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Image Acquisition</em>'.
	 * @see ms21paper.ImageAcquisition
	 * @generated
	 */
	EClass getImageAcquisition();

	/**
	 * Returns the meta object for the reference list '{@link ms21paper.ImageAcquisition#getPreprocessing <em>Preprocessing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Preprocessing</em>'.
	 * @see ms21paper.ImageAcquisition#getPreprocessing()
	 * @see #getImageAcquisition()
	 * @generated
	 */
	EReference getImageAcquisition_Preprocessing();

	/**
	 * Returns the meta object for the '{@link ms21paper.ImageAcquisition#ImRead() <em>Im Read</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Im Read</em>' operation.
	 * @see ms21paper.ImageAcquisition#ImRead()
	 * @generated
	 */
	EOperation getImageAcquisition__ImRead();

	/**
	 * Returns the meta object for the '{@link ms21paper.ImageAcquisition#Preview() <em>Preview</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Preview</em>' operation.
	 * @see ms21paper.ImageAcquisition#Preview()
	 * @generated
	 */
	EOperation getImageAcquisition__Preview();

	/**
	 * Returns the meta object for the '{@link ms21paper.ImageAcquisition#Snapshot() <em>Snapshot</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Snapshot</em>' operation.
	 * @see ms21paper.ImageAcquisition#Snapshot()
	 * @generated
	 */
	EOperation getImageAcquisition__Snapshot();

	/**
	 * Returns the meta object for class '{@link ms21paper.Preprocessing <em>Preprocessing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Preprocessing</em>'.
	 * @see ms21paper.Preprocessing
	 * @generated
	 */
	EClass getPreprocessing();

	/**
	 * Returns the meta object for the reference list '{@link ms21paper.Preprocessing#getRegionofinterest <em>Regionofinterest</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Regionofinterest</em>'.
	 * @see ms21paper.Preprocessing#getRegionofinterest()
	 * @see #getPreprocessing()
	 * @generated
	 */
	EReference getPreprocessing_Regionofinterest();

	/**
	 * Returns the meta object for the '{@link ms21paper.Preprocessing#Resize() <em>Resize</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Resize</em>' operation.
	 * @see ms21paper.Preprocessing#Resize()
	 * @generated
	 */
	EOperation getPreprocessing__Resize();

	/**
	 * Returns the meta object for the '{@link ms21paper.Preprocessing#rgb2gray() <em>Rgb2gray</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Rgb2gray</em>' operation.
	 * @see ms21paper.Preprocessing#rgb2gray()
	 * @generated
	 */
	EOperation getPreprocessing__Rgb2gray();

	/**
	 * Returns the meta object for the '{@link ms21paper.Preprocessing#ImShow() <em>Im Show</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Im Show</em>' operation.
	 * @see ms21paper.Preprocessing#ImShow()
	 * @generated
	 */
	EOperation getPreprocessing__ImShow();

	/**
	 * Returns the meta object for the '{@link ms21paper.Preprocessing#ImBinrize() <em>Im Binrize</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Im Binrize</em>' operation.
	 * @see ms21paper.Preprocessing#ImBinrize()
	 * @generated
	 */
	EOperation getPreprocessing__ImBinrize();

	/**
	 * Returns the meta object for the '{@link ms21paper.Preprocessing#histeq() <em>Histeq</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Histeq</em>' operation.
	 * @see ms21paper.Preprocessing#histeq()
	 * @generated
	 */
	EOperation getPreprocessing__Histeq();

	/**
	 * Returns the meta object for class '{@link ms21paper.CharacterRecognition <em>Character Recognition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Character Recognition</em>'.
	 * @see ms21paper.CharacterRecognition
	 * @generated
	 */
	EClass getCharacterRecognition();

	/**
	 * Returns the meta object for the reference list '{@link ms21paper.CharacterRecognition#getTemplates <em>Templates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Templates</em>'.
	 * @see ms21paper.CharacterRecognition#getTemplates()
	 * @see #getCharacterRecognition()
	 * @generated
	 */
	EReference getCharacterRecognition_Templates();

	/**
	 * Returns the meta object for the '{@link ms21paper.CharacterRecognition#imread() <em>Imread</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Imread</em>' operation.
	 * @see ms21paper.CharacterRecognition#imread()
	 * @generated
	 */
	EOperation getCharacterRecognition__Imread();

	/**
	 * Returns the meta object for the '{@link ms21paper.CharacterRecognition#FindCorrelation() <em>Find Correlation</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Find Correlation</em>' operation.
	 * @see ms21paper.CharacterRecognition#FindCorrelation()
	 * @generated
	 */
	EOperation getCharacterRecognition__FindCorrelation();

	/**
	 * Returns the meta object for class '{@link ms21paper.Templates <em>Templates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Templates</em>'.
	 * @see ms21paper.Templates
	 * @generated
	 */
	EClass getTemplates();

	/**
	 * Returns the meta object for the reference list '{@link ms21paper.Templates#getCharacterrecognition <em>Characterrecognition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Characterrecognition</em>'.
	 * @see ms21paper.Templates#getCharacterrecognition()
	 * @see #getTemplates()
	 * @generated
	 */
	EReference getTemplates_Characterrecognition();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Templates#getBinaryimage <em>Binaryimage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Binaryimage</em>'.
	 * @see ms21paper.Templates#getBinaryimage()
	 * @see #getTemplates()
	 * @generated
	 */
	EAttribute getTemplates_Binaryimage();

	/**
	 * Returns the meta object for the attribute '{@link ms21paper.Templates#getImextn <em>Imextn</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Imextn</em>'.
	 * @see ms21paper.Templates#getImextn()
	 * @see #getTemplates()
	 * @generated
	 */
	EAttribute getTemplates_Imextn();

	/**
	 * Returns the meta object for class '{@link ms21paper.RegionOfInterest <em>Region Of Interest</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Region Of Interest</em>'.
	 * @see ms21paper.RegionOfInterest
	 * @generated
	 */
	EClass getRegionOfInterest();

	/**
	 * Returns the meta object for the reference list '{@link ms21paper.RegionOfInterest#getCharactersegmentation <em>Charactersegmentation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Charactersegmentation</em>'.
	 * @see ms21paper.RegionOfInterest#getCharactersegmentation()
	 * @see #getRegionOfInterest()
	 * @generated
	 */
	EReference getRegionOfInterest_Charactersegmentation();

	/**
	 * Returns the meta object for the '{@link ms21paper.RegionOfInterest#edge() <em>Edge</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Edge</em>' operation.
	 * @see ms21paper.RegionOfInterest#edge()
	 * @generated
	 */
	EOperation getRegionOfInterest__Edge();

	/**
	 * Returns the meta object for the '{@link ms21paper.RegionOfInterest#bwlabel() <em>Bwlabel</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Bwlabel</em>' operation.
	 * @see ms21paper.RegionOfInterest#bwlabel()
	 * @generated
	 */
	EOperation getRegionOfInterest__Bwlabel();

	/**
	 * Returns the meta object for the '{@link ms21paper.RegionOfInterest#regionprops() <em>Regionprops</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Regionprops</em>' operation.
	 * @see ms21paper.RegionOfInterest#regionprops()
	 * @generated
	 */
	EOperation getRegionOfInterest__Regionprops();

	/**
	 * Returns the meta object for the '{@link ms21paper.RegionOfInterest#imdialate() <em>Imdialate</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Imdialate</em>' operation.
	 * @see ms21paper.RegionOfInterest#imdialate()
	 * @generated
	 */
	EOperation getRegionOfInterest__Imdialate();

	/**
	 * Returns the meta object for the '{@link ms21paper.RegionOfInterest#imerode() <em>Imerode</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Imerode</em>' operation.
	 * @see ms21paper.RegionOfInterest#imerode()
	 * @generated
	 */
	EOperation getRegionOfInterest__Imerode();

	/**
	 * Returns the meta object for class '{@link ms21paper.SmoothingFilter <em>Smoothing Filter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Smoothing Filter</em>'.
	 * @see ms21paper.SmoothingFilter
	 * @generated
	 */
	EClass getSmoothingFilter();

	/**
	 * Returns the meta object for the '{@link ms21paper.SmoothingFilter#Average() <em>Average</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Average</em>' operation.
	 * @see ms21paper.SmoothingFilter#Average()
	 * @generated
	 */
	EOperation getSmoothingFilter__Average();

	/**
	 * Returns the meta object for class '{@link ms21paper.Sharpening <em>Sharpening</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sharpening</em>'.
	 * @see ms21paper.Sharpening
	 * @generated
	 */
	EClass getSharpening();

	/**
	 * Returns the meta object for class '{@link ms21paper.CharacterSegmentation <em>Character Segmentation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Character Segmentation</em>'.
	 * @see ms21paper.CharacterSegmentation
	 * @generated
	 */
	EClass getCharacterSegmentation();

	/**
	 * Returns the meta object for the reference list '{@link ms21paper.CharacterSegmentation#getCharacterrecognition <em>Characterrecognition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Characterrecognition</em>'.
	 * @see ms21paper.CharacterSegmentation#getCharacterrecognition()
	 * @see #getCharacterSegmentation()
	 * @generated
	 */
	EReference getCharacterSegmentation_Characterrecognition();

	/**
	 * Returns the meta object for the '{@link ms21paper.CharacterSegmentation#edgedetection() <em>Edgedetection</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Edgedetection</em>' operation.
	 * @see ms21paper.CharacterSegmentation#edgedetection()
	 * @generated
	 */
	EOperation getCharacterSegmentation__Edgedetection();

	/**
	 * Returns the meta object for the '{@link ms21paper.CharacterSegmentation#bwareaopen() <em>Bwareaopen</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Bwareaopen</em>' operation.
	 * @see ms21paper.CharacterSegmentation#bwareaopen()
	 * @generated
	 */
	EOperation getCharacterSegmentation__Bwareaopen();

	/**
	 * Returns the meta object for the '{@link ms21paper.CharacterSegmentation#imcrop() <em>Imcrop</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Imcrop</em>' operation.
	 * @see ms21paper.CharacterSegmentation#imcrop()
	 * @generated
	 */
	EOperation getCharacterSegmentation__Imcrop();

	/**
	 * Returns the meta object for the '{@link ms21paper.CharacterSegmentation#imresize() <em>Imresize</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Imresize</em>' operation.
	 * @see ms21paper.CharacterSegmentation#imresize()
	 * @generated
	 */
	EOperation getCharacterSegmentation__Imresize();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	Ms21paperFactory getMs21paperFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link ms21paper.impl.VehicleImpl <em>Vehicle</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.VehicleImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getVehicle()
		 * @generated
		 */
		EClass VEHICLE = eINSTANCE.getVehicle();

		/**
		 * The meta object literal for the '<em><b>Motionsensor</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VEHICLE__MOTIONSENSOR = eINSTANCE.getVehicle_Motionsensor();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VEHICLE__NAME = eINSTANCE.getVehicle_Name();

		/**
		 * The meta object literal for the '<em><b>Vnumber</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VEHICLE__VNUMBER = eINSTANCE.getVehicle_Vnumber();

		/**
		 * The meta object literal for the '<em><b>Owner ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VEHICLE__OWNER_ID = eINSTANCE.getVehicle_OwnerID();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.SensorImpl <em>Sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.SensorImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getSensor()
		 * @generated
		 */
		EClass SENSOR = eINSTANCE.getSensor();

		/**
		 * The meta object literal for the '<em><b>Dataacquisition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SENSOR__DATAACQUISITION = eINSTANCE.getSensor_Dataacquisition();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENSOR__NAME = eINSTANCE.getSensor_Name();

		/**
		 * The meta object literal for the '<em><b>Sensor Data</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENSOR__SENSOR_DATA = eINSTANCE.getSensor_SensorData();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.MotionSensorImpl <em>Motion Sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.MotionSensorImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getMotionSensor()
		 * @generated
		 */
		EClass MOTION_SENSOR = eINSTANCE.getMotionSensor();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.IRSsensorImpl <em>IR Ssensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.IRSsensorImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getIRSsensor()
		 * @generated
		 */
		EClass IR_SSENSOR = eINSTANCE.getIRSsensor();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.PCImpl <em>PC</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.PCImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getPC()
		 * @generated
		 */
		EClass PC = eINSTANCE.getPC();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PC__NAME = eINSTANCE.getPC_Name();

		/**
		 * The meta object literal for the '<em><b>Vnumber</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PC__VNUMBER = eINSTANCE.getPC_Vnumber();

		/**
		 * The meta object literal for the '<em><b>Dataacquisition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PC__DATAACQUISITION = eINSTANCE.getPC_Dataacquisition();

		/**
		 * The meta object literal for the '<em><b>Records</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PC__RECORDS = eINSTANCE.getPC_Records();

		/**
		 * The meta object literal for the '<em><b>Dip</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PC__DIP = eINSTANCE.getPC_Dip();

		/**
		 * The meta object literal for the '<em><b>Vehiclelocation</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PC__VEHICLELOCATION = eINSTANCE.getPC_Vehiclelocation();

		/**
		 * The meta object literal for the '<em><b>Vehicle Record</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PC__VEHICLE_RECORD = eINSTANCE.getPC_VehicleRecord();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.SurvilanceAndTrackingSytemsImpl <em>Survilance And Tracking Sytems</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.SurvilanceAndTrackingSytemsImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getSurvilanceAndTrackingSytems()
		 * @generated
		 */
		EClass SURVILANCE_AND_TRACKING_SYTEMS = eINSTANCE.getSurvilanceAndTrackingSytems();

		/**
		 * The meta object literal for the '<em><b>Entrancesystem</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SURVILANCE_AND_TRACKING_SYTEMS__ENTRANCESYSTEM = eINSTANCE
				.getSurvilanceAndTrackingSytems_Entrancesystem();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.ToolCollectionSystemImpl <em>Tool Collection System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.ToolCollectionSystemImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getToolCollectionSystem()
		 * @generated
		 */
		EClass TOOL_COLLECTION_SYSTEM = eINSTANCE.getToolCollectionSystem();

		/**
		 * The meta object literal for the '<em><b>Entrancesystem</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TOOL_COLLECTION_SYSTEM__ENTRANCESYSTEM = eINSTANCE.getToolCollectionSystem_Entrancesystem();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.SecuritySystemsImpl <em>Security Systems</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.SecuritySystemsImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getSecuritySystems()
		 * @generated
		 */
		EClass SECURITY_SYSTEMS = eINSTANCE.getSecuritySystems();

		/**
		 * The meta object literal for the '<em><b>Entrancesystem</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SECURITY_SYSTEMS__ENTRANCESYSTEM = eINSTANCE.getSecuritySystems_Entrancesystem();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.ParkingSystemsImpl <em>Parking Systems</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.ParkingSystemsImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getParkingSystems()
		 * @generated
		 */
		EClass PARKING_SYSTEMS = eINSTANCE.getParkingSystems();

		/**
		 * The meta object literal for the '<em><b>Entrancesystem</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PARKING_SYSTEMS__ENTRANCESYSTEM = eINSTANCE.getParkingSystems_Entrancesystem();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.GeographicalMapsImpl <em>Geographical Maps</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.GeographicalMapsImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getGeographicalMaps()
		 * @generated
		 */
		EClass GEOGRAPHICAL_MAPS = eINSTANCE.getGeographicalMaps();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GEOGRAPHICAL_MAPS__NAME = eINSTANCE.getGeographicalMaps_Name();

		/**
		 * The meta object literal for the '<em><b>Vehiclelocation</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GEOGRAPHICAL_MAPS__VEHICLELOCATION = eINSTANCE.getGeographicalMaps_Vehiclelocation();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.PortImpl <em>Port</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.PortImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getPort()
		 * @generated
		 */
		EClass PORT = eINSTANCE.getPort();

		/**
		 * The meta object literal for the '<em><b>Pin</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORT__PIN = eINSTANCE.getPort_Pin();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORT__TYPE = eINSTANCE.getPort_Type();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORT__NAME = eINSTANCE.getPort_Name();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.InputImpl <em>Input</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.InputImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getInput()
		 * @generated
		 */
		EClass INPUT = eINSTANCE.getInput();

		/**
		 * The meta object literal for the '<em><b>Sdata</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT__SDATA = eINSTANCE.getInput_Sdata();

		/**
		 * The meta object literal for the '<em><b>Motionsensor</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INPUT__MOTIONSENSOR = eINSTANCE.getInput_Motionsensor();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.OutputImpl <em>Output</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.OutputImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getOutput()
		 * @generated
		 */
		EClass OUTPUT = eINSTANCE.getOutput();

		/**
		 * The meta object literal for the '<em><b>Motor Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OUTPUT__MOTOR_STATUS = eINSTANCE.getOutput_MotorStatus();

		/**
		 * The meta object literal for the '<em><b>Controlgate</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OUTPUT__CONTROLGATE = eINSTANCE.getOutput_Controlgate();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.FilteringImpl <em>Filtering</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.FilteringImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getFiltering()
		 * @generated
		 */
		EClass FILTERING = eINSTANCE.getFiltering();

		/**
		 * The meta object literal for the '<em><b>Masksize</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FILTERING__MASKSIZE = eINSTANCE.getFiltering_Masksize();

		/**
		 * The meta object literal for the '{@link ms21paper.TypeController <em>Type Controller</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.TypeController
		 * @see ms21paper.impl.Ms21paperPackageImpl#getTypeController()
		 * @generated
		 */
		EEnum TYPE_CONTROLLER = eINSTANCE.getTypeController();

		/**
		 * The meta object literal for the '{@link ms21paper.TypePort <em>Type Port</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.TypePort
		 * @see ms21paper.impl.Ms21paperPackageImpl#getTypePort()
		 * @generated
		 */
		EEnum TYPE_PORT = eINSTANCE.getTypePort();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.DataAcquisitionImpl <em>Data Acquisition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.DataAcquisitionImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getDataAcquisition()
		 * @generated
		 */
		EClass DATA_ACQUISITION = eINSTANCE.getDataAcquisition();

		/**
		 * The meta object literal for the '<em><b>Controlgate</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DATA_ACQUISITION__CONTROLGATE = eINSTANCE.getDataAcquisition_Controlgate();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DATA_ACQUISITION__TYPE = eINSTANCE.getDataAcquisition_Type();

		/**
		 * The meta object literal for the '<em><b>Pc</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DATA_ACQUISITION__PC = eINSTANCE.getDataAcquisition_Pc();

		/**
		 * The meta object literal for the '<em><b>Sensor Data</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DATA_ACQUISITION__SENSOR_DATA = eINSTANCE.getDataAcquisition_SensorData();

		/**
		 * The meta object literal for the '<em><b>Motor Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DATA_ACQUISITION__MOTOR_STATUS = eINSTANCE.getDataAcquisition_MotorStatus();

		/**
		 * The meta object literal for the '<em><b>Port</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DATA_ACQUISITION__PORT = eINSTANCE.getDataAcquisition_Port();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.DIPImpl <em>DIP</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.DIPImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getDIP()
		 * @generated
		 */
		EClass DIP = eINSTANCE.getDIP();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIP__NAME = eINSTANCE.getDIP_Name();

		/**
		 * The meta object literal for the '<em><b>Vehicle Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIP__VEHICLE_NUMBER = eINSTANCE.getDIP_VehicleNumber();

		/**
		 * The meta object literal for the '<em><b>Pc</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIP__PC = eINSTANCE.getDIP_Pc();

		/**
		 * The meta object literal for the '<em><b>Comparison Result</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIP__COMPARISON_RESULT = eINSTANCE.getDIP_ComparisonResult();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.RecordsImpl <em>Records</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.RecordsImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getRecords()
		 * @generated
		 */
		EClass RECORDS = eINSTANCE.getRecords();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RECORDS__NAME = eINSTANCE.getRecords_Name();

		/**
		 * The meta object literal for the '<em><b>Vnumber</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RECORDS__VNUMBER = eINSTANCE.getRecords_Vnumber();

		/**
		 * The meta object literal for the '<em><b>Pc</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RECORDS__PC = eINSTANCE.getRecords_Pc();

		/**
		 * The meta object literal for the '<em><b>VOwner ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RECORDS__VOWNER_ID = eINSTANCE.getRecords_VOwnerID();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.ControlGateImpl <em>Control Gate</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.ControlGateImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getControlGate()
		 * @generated
		 */
		EClass CONTROL_GATE = eINSTANCE.getControlGate();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_GATE__NAME = eINSTANCE.getControlGate_Name();

		/**
		 * The meta object literal for the '<em><b>Motor Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_GATE__MOTOR_STATUS = eINSTANCE.getControlGate_MotorStatus();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.EntranceSystemImpl <em>Entrance System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.EntranceSystemImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getEntranceSystem()
		 * @generated
		 */
		EClass ENTRANCE_SYSTEM = eINSTANCE.getEntranceSystem();

		/**
		 * The meta object literal for the '<em><b>Vehicle</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTRANCE_SYSTEM__VEHICLE = eINSTANCE.getEntranceSystem_Vehicle();

		/**
		 * The meta object literal for the '<em><b>Motionsensor</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTRANCE_SYSTEM__MOTIONSENSOR = eINSTANCE.getEntranceSystem_Motionsensor();

		/**
		 * The meta object literal for the '<em><b>Dataacquisition</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTRANCE_SYSTEM__DATAACQUISITION = eINSTANCE.getEntranceSystem_Dataacquisition();

		/**
		 * The meta object literal for the '<em><b>Dip</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTRANCE_SYSTEM__DIP = eINSTANCE.getEntranceSystem_Dip();

		/**
		 * The meta object literal for the '<em><b>Records</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTRANCE_SYSTEM__RECORDS = eINSTANCE.getEntranceSystem_Records();

		/**
		 * The meta object literal for the '<em><b>Vehiclelocation</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTRANCE_SYSTEM__VEHICLELOCATION = eINSTANCE.getEntranceSystem_Vehiclelocation();

		/**
		 * The meta object literal for the '<em><b>Controlgate</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTRANCE_SYSTEM__CONTROLGATE = eINSTANCE.getEntranceSystem_Controlgate();

		/**
		 * The meta object literal for the '<em><b>Pc</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTRANCE_SYSTEM__PC = eINSTANCE.getEntranceSystem_Pc();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.VehicleLocationImpl <em>Vehicle Location</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.VehicleLocationImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getVehicleLocation()
		 * @generated
		 */
		EClass VEHICLE_LOCATION = eINSTANCE.getVehicleLocation();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VEHICLE_LOCATION__NAME = eINSTANCE.getVehicleLocation_Name();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VEHICLE_LOCATION__LOCATION = eINSTANCE.getVehicleLocation_Location();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.CameraImpl <em>Camera</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.CameraImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getCamera()
		 * @generated
		 */
		EClass CAMERA = eINSTANCE.getCamera();

		/**
		 * The meta object literal for the '<em><b>Image</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CAMERA__IMAGE = eINSTANCE.getCamera_Image();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.ImageImpl <em>Image</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.ImageImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getImage()
		 * @generated
		 */
		EClass IMAGE = eINSTANCE.getImage();

		/**
		 * The meta object literal for the '<em><b>Imageacquisition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IMAGE__IMAGEACQUISITION = eINSTANCE.getImage_Imageacquisition();

		/**
		 * The meta object literal for the '<em><b>Extn</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IMAGE__EXTN = eINSTANCE.getImage_Extn();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.ImageAcquisitionImpl <em>Image Acquisition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.ImageAcquisitionImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getImageAcquisition()
		 * @generated
		 */
		EClass IMAGE_ACQUISITION = eINSTANCE.getImageAcquisition();

		/**
		 * The meta object literal for the '<em><b>Preprocessing</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IMAGE_ACQUISITION__PREPROCESSING = eINSTANCE.getImageAcquisition_Preprocessing();

		/**
		 * The meta object literal for the '<em><b>Im Read</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation IMAGE_ACQUISITION___IM_READ = eINSTANCE.getImageAcquisition__ImRead();

		/**
		 * The meta object literal for the '<em><b>Preview</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation IMAGE_ACQUISITION___PREVIEW = eINSTANCE.getImageAcquisition__Preview();

		/**
		 * The meta object literal for the '<em><b>Snapshot</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation IMAGE_ACQUISITION___SNAPSHOT = eINSTANCE.getImageAcquisition__Snapshot();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.PreprocessingImpl <em>Preprocessing</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.PreprocessingImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getPreprocessing()
		 * @generated
		 */
		EClass PREPROCESSING = eINSTANCE.getPreprocessing();

		/**
		 * The meta object literal for the '<em><b>Regionofinterest</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PREPROCESSING__REGIONOFINTEREST = eINSTANCE.getPreprocessing_Regionofinterest();

		/**
		 * The meta object literal for the '<em><b>Resize</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PREPROCESSING___RESIZE = eINSTANCE.getPreprocessing__Resize();

		/**
		 * The meta object literal for the '<em><b>Rgb2gray</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PREPROCESSING___RGB2GRAY = eINSTANCE.getPreprocessing__Rgb2gray();

		/**
		 * The meta object literal for the '<em><b>Im Show</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PREPROCESSING___IM_SHOW = eINSTANCE.getPreprocessing__ImShow();

		/**
		 * The meta object literal for the '<em><b>Im Binrize</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PREPROCESSING___IM_BINRIZE = eINSTANCE.getPreprocessing__ImBinrize();

		/**
		 * The meta object literal for the '<em><b>Histeq</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PREPROCESSING___HISTEQ = eINSTANCE.getPreprocessing__Histeq();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.CharacterRecognitionImpl <em>Character Recognition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.CharacterRecognitionImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getCharacterRecognition()
		 * @generated
		 */
		EClass CHARACTER_RECOGNITION = eINSTANCE.getCharacterRecognition();

		/**
		 * The meta object literal for the '<em><b>Templates</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CHARACTER_RECOGNITION__TEMPLATES = eINSTANCE.getCharacterRecognition_Templates();

		/**
		 * The meta object literal for the '<em><b>Imread</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CHARACTER_RECOGNITION___IMREAD = eINSTANCE.getCharacterRecognition__Imread();

		/**
		 * The meta object literal for the '<em><b>Find Correlation</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CHARACTER_RECOGNITION___FIND_CORRELATION = eINSTANCE.getCharacterRecognition__FindCorrelation();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.TemplatesImpl <em>Templates</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.TemplatesImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getTemplates()
		 * @generated
		 */
		EClass TEMPLATES = eINSTANCE.getTemplates();

		/**
		 * The meta object literal for the '<em><b>Characterrecognition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEMPLATES__CHARACTERRECOGNITION = eINSTANCE.getTemplates_Characterrecognition();

		/**
		 * The meta object literal for the '<em><b>Binaryimage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEMPLATES__BINARYIMAGE = eINSTANCE.getTemplates_Binaryimage();

		/**
		 * The meta object literal for the '<em><b>Imextn</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEMPLATES__IMEXTN = eINSTANCE.getTemplates_Imextn();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.RegionOfInterestImpl <em>Region Of Interest</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.RegionOfInterestImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getRegionOfInterest()
		 * @generated
		 */
		EClass REGION_OF_INTEREST = eINSTANCE.getRegionOfInterest();

		/**
		 * The meta object literal for the '<em><b>Charactersegmentation</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REGION_OF_INTEREST__CHARACTERSEGMENTATION = eINSTANCE.getRegionOfInterest_Charactersegmentation();

		/**
		 * The meta object literal for the '<em><b>Edge</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation REGION_OF_INTEREST___EDGE = eINSTANCE.getRegionOfInterest__Edge();

		/**
		 * The meta object literal for the '<em><b>Bwlabel</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation REGION_OF_INTEREST___BWLABEL = eINSTANCE.getRegionOfInterest__Bwlabel();

		/**
		 * The meta object literal for the '<em><b>Regionprops</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation REGION_OF_INTEREST___REGIONPROPS = eINSTANCE.getRegionOfInterest__Regionprops();

		/**
		 * The meta object literal for the '<em><b>Imdialate</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation REGION_OF_INTEREST___IMDIALATE = eINSTANCE.getRegionOfInterest__Imdialate();

		/**
		 * The meta object literal for the '<em><b>Imerode</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation REGION_OF_INTEREST___IMERODE = eINSTANCE.getRegionOfInterest__Imerode();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.SmoothingFilterImpl <em>Smoothing Filter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.SmoothingFilterImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getSmoothingFilter()
		 * @generated
		 */
		EClass SMOOTHING_FILTER = eINSTANCE.getSmoothingFilter();

		/**
		 * The meta object literal for the '<em><b>Average</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SMOOTHING_FILTER___AVERAGE = eINSTANCE.getSmoothingFilter__Average();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.SharpeningImpl <em>Sharpening</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.SharpeningImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getSharpening()
		 * @generated
		 */
		EClass SHARPENING = eINSTANCE.getSharpening();

		/**
		 * The meta object literal for the '{@link ms21paper.impl.CharacterSegmentationImpl <em>Character Segmentation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ms21paper.impl.CharacterSegmentationImpl
		 * @see ms21paper.impl.Ms21paperPackageImpl#getCharacterSegmentation()
		 * @generated
		 */
		EClass CHARACTER_SEGMENTATION = eINSTANCE.getCharacterSegmentation();

		/**
		 * The meta object literal for the '<em><b>Characterrecognition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CHARACTER_SEGMENTATION__CHARACTERRECOGNITION = eINSTANCE
				.getCharacterSegmentation_Characterrecognition();

		/**
		 * The meta object literal for the '<em><b>Edgedetection</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CHARACTER_SEGMENTATION___EDGEDETECTION = eINSTANCE.getCharacterSegmentation__Edgedetection();

		/**
		 * The meta object literal for the '<em><b>Bwareaopen</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CHARACTER_SEGMENTATION___BWAREAOPEN = eINSTANCE.getCharacterSegmentation__Bwareaopen();

		/**
		 * The meta object literal for the '<em><b>Imcrop</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CHARACTER_SEGMENTATION___IMCROP = eINSTANCE.getCharacterSegmentation__Imcrop();

		/**
		 * The meta object literal for the '<em><b>Imresize</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CHARACTER_SEGMENTATION___IMRESIZE = eINSTANCE.getCharacterSegmentation__Imresize();

	}

} //Ms21paperPackage
