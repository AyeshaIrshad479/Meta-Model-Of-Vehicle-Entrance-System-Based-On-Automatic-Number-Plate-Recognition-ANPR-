/**
 */
package ms21paper;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Camera</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.Camera#getImage <em>Image</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getCamera()
 * @model
 * @generated
 */
public interface Camera extends DIP {
	/**
	 * Returns the value of the '<em><b>Image</b></em>' reference list.
	 * The list contents are of type {@link ms21paper.Image}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Image</em>' reference list.
	 * @see ms21paper.Ms21paperPackage#getCamera_Image()
	 * @model
	 * @generated
	 */
	EList<Image> getImage();

} // Camera
