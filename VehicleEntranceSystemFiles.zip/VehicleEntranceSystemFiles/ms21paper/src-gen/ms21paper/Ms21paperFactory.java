/**
 */
package ms21paper;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see ms21paper.Ms21paperPackage
 * @generated
 */
public interface Ms21paperFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Ms21paperFactory eINSTANCE = ms21paper.impl.Ms21paperFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Vehicle</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Vehicle</em>'.
	 * @generated
	 */
	Vehicle createVehicle();

	/**
	 * Returns a new object of class '<em>Motion Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Motion Sensor</em>'.
	 * @generated
	 */
	MotionSensor createMotionSensor();

	/**
	 * Returns a new object of class '<em>IR Ssensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>IR Ssensor</em>'.
	 * @generated
	 */
	IRSsensor createIRSsensor();

	/**
	 * Returns a new object of class '<em>PC</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>PC</em>'.
	 * @generated
	 */
	PC createPC();

	/**
	 * Returns a new object of class '<em>Survilance And Tracking Sytems</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Survilance And Tracking Sytems</em>'.
	 * @generated
	 */
	SurvilanceAndTrackingSytems createSurvilanceAndTrackingSytems();

	/**
	 * Returns a new object of class '<em>Tool Collection System</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tool Collection System</em>'.
	 * @generated
	 */
	ToolCollectionSystem createToolCollectionSystem();

	/**
	 * Returns a new object of class '<em>Security Systems</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Security Systems</em>'.
	 * @generated
	 */
	SecuritySystems createSecuritySystems();

	/**
	 * Returns a new object of class '<em>Parking Systems</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Parking Systems</em>'.
	 * @generated
	 */
	ParkingSystems createParkingSystems();

	/**
	 * Returns a new object of class '<em>Geographical Maps</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Geographical Maps</em>'.
	 * @generated
	 */
	GeographicalMaps createGeographicalMaps();

	/**
	 * Returns a new object of class '<em>Input</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Input</em>'.
	 * @generated
	 */
	Input createInput();

	/**
	 * Returns a new object of class '<em>Output</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Output</em>'.
	 * @generated
	 */
	Output createOutput();

	/**
	 * Returns a new object of class '<em>Data Acquisition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Data Acquisition</em>'.
	 * @generated
	 */
	DataAcquisition createDataAcquisition();

	/**
	 * Returns a new object of class '<em>Records</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Records</em>'.
	 * @generated
	 */
	Records createRecords();

	/**
	 * Returns a new object of class '<em>Control Gate</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Control Gate</em>'.
	 * @generated
	 */
	ControlGate createControlGate();

	/**
	 * Returns a new object of class '<em>Entrance System</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Entrance System</em>'.
	 * @generated
	 */
	EntranceSystem createEntranceSystem();

	/**
	 * Returns a new object of class '<em>Vehicle Location</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Vehicle Location</em>'.
	 * @generated
	 */
	VehicleLocation createVehicleLocation();

	/**
	 * Returns a new object of class '<em>Camera</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Camera</em>'.
	 * @generated
	 */
	Camera createCamera();

	/**
	 * Returns a new object of class '<em>Image</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Image</em>'.
	 * @generated
	 */
	Image createImage();

	/**
	 * Returns a new object of class '<em>Image Acquisition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Image Acquisition</em>'.
	 * @generated
	 */
	ImageAcquisition createImageAcquisition();

	/**
	 * Returns a new object of class '<em>Preprocessing</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Preprocessing</em>'.
	 * @generated
	 */
	Preprocessing createPreprocessing();

	/**
	 * Returns a new object of class '<em>Character Recognition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Character Recognition</em>'.
	 * @generated
	 */
	CharacterRecognition createCharacterRecognition();

	/**
	 * Returns a new object of class '<em>Templates</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Templates</em>'.
	 * @generated
	 */
	Templates createTemplates();

	/**
	 * Returns a new object of class '<em>Region Of Interest</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Region Of Interest</em>'.
	 * @generated
	 */
	RegionOfInterest createRegionOfInterest();

	/**
	 * Returns a new object of class '<em>Smoothing Filter</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Smoothing Filter</em>'.
	 * @generated
	 */
	SmoothingFilter createSmoothingFilter();

	/**
	 * Returns a new object of class '<em>Sharpening</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sharpening</em>'.
	 * @generated
	 */
	Sharpening createSharpening();

	/**
	 * Returns a new object of class '<em>Character Segmentation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Character Segmentation</em>'.
	 * @generated
	 */
	CharacterSegmentation createCharacterSegmentation();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	Ms21paperPackage getMs21paperPackage();

} //Ms21paperFactory
