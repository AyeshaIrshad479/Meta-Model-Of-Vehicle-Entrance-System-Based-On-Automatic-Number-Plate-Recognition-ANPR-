/**
 */
package ms21paper;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Records</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.Records#getName <em>Name</em>}</li>
 *   <li>{@link ms21paper.Records#getVnumber <em>Vnumber</em>}</li>
 *   <li>{@link ms21paper.Records#getPc <em>Pc</em>}</li>
 *   <li>{@link ms21paper.Records#getVOwnerID <em>VOwner ID</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getRecords()
 * @model
 * @generated
 */
public interface Records extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see ms21paper.Ms21paperPackage#getRecords_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link ms21paper.Records#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Vnumber</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vnumber</em>' attribute.
	 * @see #setVnumber(String)
	 * @see ms21paper.Ms21paperPackage#getRecords_Vnumber()
	 * @model
	 * @generated
	 */
	String getVnumber();

	/**
	 * Sets the value of the '{@link ms21paper.Records#getVnumber <em>Vnumber</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vnumber</em>' attribute.
	 * @see #getVnumber()
	 * @generated
	 */
	void setVnumber(String value);

	/**
	 * Returns the value of the '<em><b>Pc</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link ms21paper.PC#getRecords <em>Records</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pc</em>' reference.
	 * @see #setPc(PC)
	 * @see ms21paper.Ms21paperPackage#getRecords_Pc()
	 * @see ms21paper.PC#getRecords
	 * @model opposite="records"
	 * @generated
	 */
	PC getPc();

	/**
	 * Sets the value of the '{@link ms21paper.Records#getPc <em>Pc</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pc</em>' reference.
	 * @see #getPc()
	 * @generated
	 */
	void setPc(PC value);

	/**
	 * Returns the value of the '<em><b>VOwner ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>VOwner ID</em>' attribute.
	 * @see #setVOwnerID(short)
	 * @see ms21paper.Ms21paperPackage#getRecords_VOwnerID()
	 * @model
	 * @generated
	 */
	short getVOwnerID();

	/**
	 * Sets the value of the '{@link ms21paper.Records#getVOwnerID <em>VOwner ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>VOwner ID</em>' attribute.
	 * @see #getVOwnerID()
	 * @generated
	 */
	void setVOwnerID(short value);

} // Records
