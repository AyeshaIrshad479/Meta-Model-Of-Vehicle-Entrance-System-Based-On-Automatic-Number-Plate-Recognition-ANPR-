/**
 */
package ms21paper;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Image</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.Image#getImageacquisition <em>Imageacquisition</em>}</li>
 *   <li>{@link ms21paper.Image#getExtn <em>Extn</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getImage()
 * @model
 * @generated
 */
public interface Image extends DIP {
	/**
	 * Returns the value of the '<em><b>Imageacquisition</b></em>' reference list.
	 * The list contents are of type {@link ms21paper.ImageAcquisition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Imageacquisition</em>' reference list.
	 * @see ms21paper.Ms21paperPackage#getImage_Imageacquisition()
	 * @model
	 * @generated
	 */
	EList<ImageAcquisition> getImageacquisition();

	/**
	 * Returns the value of the '<em><b>Extn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Extn</em>' attribute.
	 * @see #setExtn(String)
	 * @see ms21paper.Ms21paperPackage#getImage_Extn()
	 * @model
	 * @generated
	 */
	String getExtn();

	/**
	 * Sets the value of the '{@link ms21paper.Image#getExtn <em>Extn</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Extn</em>' attribute.
	 * @see #getExtn()
	 * @generated
	 */
	void setExtn(String value);

} // Image
