/**
 */
package ms21paper;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>DIP</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.DIP#getName <em>Name</em>}</li>
 *   <li>{@link ms21paper.DIP#getVehicleNumber <em>Vehicle Number</em>}</li>
 *   <li>{@link ms21paper.DIP#getPc <em>Pc</em>}</li>
 *   <li>{@link ms21paper.DIP#isComparisonResult <em>Comparison Result</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getDIP()
 * @model abstract="true"
 * @generated
 */
public interface DIP extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see ms21paper.Ms21paperPackage#getDIP_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link ms21paper.DIP#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Vehicle Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vehicle Number</em>' attribute.
	 * @see #setVehicleNumber(String)
	 * @see ms21paper.Ms21paperPackage#getDIP_VehicleNumber()
	 * @model
	 * @generated
	 */
	String getVehicleNumber();

	/**
	 * Sets the value of the '{@link ms21paper.DIP#getVehicleNumber <em>Vehicle Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vehicle Number</em>' attribute.
	 * @see #getVehicleNumber()
	 * @generated
	 */
	void setVehicleNumber(String value);

	/**
	 * Returns the value of the '<em><b>Pc</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link ms21paper.PC#getDip <em>Dip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pc</em>' reference.
	 * @see #setPc(PC)
	 * @see ms21paper.Ms21paperPackage#getDIP_Pc()
	 * @see ms21paper.PC#getDip
	 * @model opposite="dip"
	 * @generated
	 */
	PC getPc();

	/**
	 * Sets the value of the '{@link ms21paper.DIP#getPc <em>Pc</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pc</em>' reference.
	 * @see #getPc()
	 * @generated
	 */
	void setPc(PC value);

	/**
	 * Returns the value of the '<em><b>Comparison Result</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Comparison Result</em>' attribute.
	 * @see #setComparisonResult(boolean)
	 * @see ms21paper.Ms21paperPackage#getDIP_ComparisonResult()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.Boolean"
	 * @generated
	 */
	boolean isComparisonResult();

	/**
	 * Sets the value of the '{@link ms21paper.DIP#isComparisonResult <em>Comparison Result</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Comparison Result</em>' attribute.
	 * @see #isComparisonResult()
	 * @generated
	 */
	void setComparisonResult(boolean value);

} // DIP
