/**
 */
package ms21paper;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Character Segmentation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.CharacterSegmentation#getCharacterrecognition <em>Characterrecognition</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getCharacterSegmentation()
 * @model
 * @generated
 */
public interface CharacterSegmentation extends DIP {
	/**
	 * Returns the value of the '<em><b>Characterrecognition</b></em>' reference list.
	 * The list contents are of type {@link ms21paper.CharacterRecognition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Characterrecognition</em>' reference list.
	 * @see ms21paper.Ms21paperPackage#getCharacterSegmentation_Characterrecognition()
	 * @model
	 * @generated
	 */
	EList<CharacterRecognition> getCharacterrecognition();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void edgedetection();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void bwareaopen();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void imcrop();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void imresize();

} // CharacterSegmentation
