/**
 */
package ms21paper.util;

import ms21paper.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see ms21paper.Ms21paperPackage
 * @generated
 */
public class Ms21paperSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static Ms21paperPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ms21paperSwitch() {
		if (modelPackage == null) {
			modelPackage = Ms21paperPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case Ms21paperPackage.VEHICLE: {
			Vehicle vehicle = (Vehicle) theEObject;
			T result = caseVehicle(vehicle);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.SENSOR: {
			Sensor sensor = (Sensor) theEObject;
			T result = caseSensor(sensor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.DATA_ACQUISITION: {
			DataAcquisition dataAcquisition = (DataAcquisition) theEObject;
			T result = caseDataAcquisition(dataAcquisition);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.DIP: {
			DIP dip = (DIP) theEObject;
			T result = caseDIP(dip);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.RECORDS: {
			Records records = (Records) theEObject;
			T result = caseRecords(records);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.CONTROL_GATE: {
			ControlGate controlGate = (ControlGate) theEObject;
			T result = caseControlGate(controlGate);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.ENTRANCE_SYSTEM: {
			EntranceSystem entranceSystem = (EntranceSystem) theEObject;
			T result = caseEntranceSystem(entranceSystem);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.VEHICLE_LOCATION: {
			VehicleLocation vehicleLocation = (VehicleLocation) theEObject;
			T result = caseVehicleLocation(vehicleLocation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.CAMERA: {
			Camera camera = (Camera) theEObject;
			T result = caseCamera(camera);
			if (result == null)
				result = caseDIP(camera);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.IMAGE: {
			Image image = (Image) theEObject;
			T result = caseImage(image);
			if (result == null)
				result = caseDIP(image);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.IMAGE_ACQUISITION: {
			ImageAcquisition imageAcquisition = (ImageAcquisition) theEObject;
			T result = caseImageAcquisition(imageAcquisition);
			if (result == null)
				result = caseDIP(imageAcquisition);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.PREPROCESSING: {
			Preprocessing preprocessing = (Preprocessing) theEObject;
			T result = casePreprocessing(preprocessing);
			if (result == null)
				result = caseDIP(preprocessing);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.CHARACTER_RECOGNITION: {
			CharacterRecognition characterRecognition = (CharacterRecognition) theEObject;
			T result = caseCharacterRecognition(characterRecognition);
			if (result == null)
				result = caseDIP(characterRecognition);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.TEMPLATES: {
			Templates templates = (Templates) theEObject;
			T result = caseTemplates(templates);
			if (result == null)
				result = caseDIP(templates);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.REGION_OF_INTEREST: {
			RegionOfInterest regionOfInterest = (RegionOfInterest) theEObject;
			T result = caseRegionOfInterest(regionOfInterest);
			if (result == null)
				result = caseDIP(regionOfInterest);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.SMOOTHING_FILTER: {
			SmoothingFilter smoothingFilter = (SmoothingFilter) theEObject;
			T result = caseSmoothingFilter(smoothingFilter);
			if (result == null)
				result = caseFiltering(smoothingFilter);
			if (result == null)
				result = casePreprocessing(smoothingFilter);
			if (result == null)
				result = caseDIP(smoothingFilter);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.SHARPENING: {
			Sharpening sharpening = (Sharpening) theEObject;
			T result = caseSharpening(sharpening);
			if (result == null)
				result = caseFiltering(sharpening);
			if (result == null)
				result = casePreprocessing(sharpening);
			if (result == null)
				result = caseDIP(sharpening);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.CHARACTER_SEGMENTATION: {
			CharacterSegmentation characterSegmentation = (CharacterSegmentation) theEObject;
			T result = caseCharacterSegmentation(characterSegmentation);
			if (result == null)
				result = caseDIP(characterSegmentation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.MOTION_SENSOR: {
			MotionSensor motionSensor = (MotionSensor) theEObject;
			T result = caseMotionSensor(motionSensor);
			if (result == null)
				result = caseSensor(motionSensor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.IR_SSENSOR: {
			IRSsensor irSsensor = (IRSsensor) theEObject;
			T result = caseIRSsensor(irSsensor);
			if (result == null)
				result = caseSensor(irSsensor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.PC: {
			PC pc = (PC) theEObject;
			T result = casePC(pc);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.SURVILANCE_AND_TRACKING_SYTEMS: {
			SurvilanceAndTrackingSytems survilanceAndTrackingSytems = (SurvilanceAndTrackingSytems) theEObject;
			T result = caseSurvilanceAndTrackingSytems(survilanceAndTrackingSytems);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.TOOL_COLLECTION_SYSTEM: {
			ToolCollectionSystem toolCollectionSystem = (ToolCollectionSystem) theEObject;
			T result = caseToolCollectionSystem(toolCollectionSystem);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.SECURITY_SYSTEMS: {
			SecuritySystems securitySystems = (SecuritySystems) theEObject;
			T result = caseSecuritySystems(securitySystems);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.PARKING_SYSTEMS: {
			ParkingSystems parkingSystems = (ParkingSystems) theEObject;
			T result = caseParkingSystems(parkingSystems);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.GEOGRAPHICAL_MAPS: {
			GeographicalMaps geographicalMaps = (GeographicalMaps) theEObject;
			T result = caseGeographicalMaps(geographicalMaps);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.PORT: {
			Port port = (Port) theEObject;
			T result = casePort(port);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.INPUT: {
			Input input = (Input) theEObject;
			T result = caseInput(input);
			if (result == null)
				result = casePort(input);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.OUTPUT: {
			Output output = (Output) theEObject;
			T result = caseOutput(output);
			if (result == null)
				result = casePort(output);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Ms21paperPackage.FILTERING: {
			Filtering filtering = (Filtering) theEObject;
			T result = caseFiltering(filtering);
			if (result == null)
				result = casePreprocessing(filtering);
			if (result == null)
				result = caseDIP(filtering);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Vehicle</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Vehicle</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseVehicle(Vehicle object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Sensor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSensor(Sensor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Motion Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Motion Sensor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMotionSensor(MotionSensor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>IR Ssensor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>IR Ssensor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIRSsensor(IRSsensor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>PC</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>PC</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePC(PC object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Survilance And Tracking Sytems</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Survilance And Tracking Sytems</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSurvilanceAndTrackingSytems(SurvilanceAndTrackingSytems object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tool Collection System</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tool Collection System</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseToolCollectionSystem(ToolCollectionSystem object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Security Systems</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Security Systems</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSecuritySystems(SecuritySystems object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Parking Systems</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Parking Systems</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseParkingSystems(ParkingSystems object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Geographical Maps</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Geographical Maps</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseGeographicalMaps(GeographicalMaps object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Port</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Port</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePort(Port object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Input</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Input</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInput(Input object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Output</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Output</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOutput(Output object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Filtering</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Filtering</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFiltering(Filtering object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Data Acquisition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Data Acquisition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDataAcquisition(DataAcquisition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>DIP</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>DIP</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDIP(DIP object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Records</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Records</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRecords(Records object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Control Gate</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Control Gate</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseControlGate(ControlGate object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Entrance System</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Entrance System</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEntranceSystem(EntranceSystem object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Vehicle Location</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Vehicle Location</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseVehicleLocation(VehicleLocation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Camera</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Camera</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCamera(Camera object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Image</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Image</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseImage(Image object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Image Acquisition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Image Acquisition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseImageAcquisition(ImageAcquisition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Preprocessing</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Preprocessing</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePreprocessing(Preprocessing object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Character Recognition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Character Recognition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCharacterRecognition(CharacterRecognition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Templates</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Templates</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTemplates(Templates object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Region Of Interest</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Region Of Interest</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRegionOfInterest(RegionOfInterest object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Smoothing Filter</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Smoothing Filter</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSmoothingFilter(SmoothingFilter object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Sharpening</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Sharpening</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSharpening(Sharpening object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Character Segmentation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Character Segmentation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCharacterSegmentation(CharacterSegmentation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //Ms21paperSwitch
