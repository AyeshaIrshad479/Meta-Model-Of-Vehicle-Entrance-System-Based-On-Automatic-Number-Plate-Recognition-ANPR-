/**
 */
package ms21paper.util;

import ms21paper.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see ms21paper.Ms21paperPackage
 * @generated
 */
public class Ms21paperAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static Ms21paperPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ms21paperAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = Ms21paperPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Ms21paperSwitch<Adapter> modelSwitch = new Ms21paperSwitch<Adapter>() {
		@Override
		public Adapter caseVehicle(Vehicle object) {
			return createVehicleAdapter();
		}

		@Override
		public Adapter caseSensor(Sensor object) {
			return createSensorAdapter();
		}

		@Override
		public Adapter caseDataAcquisition(DataAcquisition object) {
			return createDataAcquisitionAdapter();
		}

		@Override
		public Adapter caseDIP(DIP object) {
			return createDIPAdapter();
		}

		@Override
		public Adapter caseRecords(Records object) {
			return createRecordsAdapter();
		}

		@Override
		public Adapter caseControlGate(ControlGate object) {
			return createControlGateAdapter();
		}

		@Override
		public Adapter caseEntranceSystem(EntranceSystem object) {
			return createEntranceSystemAdapter();
		}

		@Override
		public Adapter caseVehicleLocation(VehicleLocation object) {
			return createVehicleLocationAdapter();
		}

		@Override
		public Adapter caseCamera(Camera object) {
			return createCameraAdapter();
		}

		@Override
		public Adapter caseImage(Image object) {
			return createImageAdapter();
		}

		@Override
		public Adapter caseImageAcquisition(ImageAcquisition object) {
			return createImageAcquisitionAdapter();
		}

		@Override
		public Adapter casePreprocessing(Preprocessing object) {
			return createPreprocessingAdapter();
		}

		@Override
		public Adapter caseCharacterRecognition(CharacterRecognition object) {
			return createCharacterRecognitionAdapter();
		}

		@Override
		public Adapter caseTemplates(Templates object) {
			return createTemplatesAdapter();
		}

		@Override
		public Adapter caseRegionOfInterest(RegionOfInterest object) {
			return createRegionOfInterestAdapter();
		}

		@Override
		public Adapter caseSmoothingFilter(SmoothingFilter object) {
			return createSmoothingFilterAdapter();
		}

		@Override
		public Adapter caseSharpening(Sharpening object) {
			return createSharpeningAdapter();
		}

		@Override
		public Adapter caseCharacterSegmentation(CharacterSegmentation object) {
			return createCharacterSegmentationAdapter();
		}

		@Override
		public Adapter caseMotionSensor(MotionSensor object) {
			return createMotionSensorAdapter();
		}

		@Override
		public Adapter caseIRSsensor(IRSsensor object) {
			return createIRSsensorAdapter();
		}

		@Override
		public Adapter casePC(PC object) {
			return createPCAdapter();
		}

		@Override
		public Adapter caseSurvilanceAndTrackingSytems(SurvilanceAndTrackingSytems object) {
			return createSurvilanceAndTrackingSytemsAdapter();
		}

		@Override
		public Adapter caseToolCollectionSystem(ToolCollectionSystem object) {
			return createToolCollectionSystemAdapter();
		}

		@Override
		public Adapter caseSecuritySystems(SecuritySystems object) {
			return createSecuritySystemsAdapter();
		}

		@Override
		public Adapter caseParkingSystems(ParkingSystems object) {
			return createParkingSystemsAdapter();
		}

		@Override
		public Adapter caseGeographicalMaps(GeographicalMaps object) {
			return createGeographicalMapsAdapter();
		}

		@Override
		public Adapter casePort(Port object) {
			return createPortAdapter();
		}

		@Override
		public Adapter caseInput(Input object) {
			return createInputAdapter();
		}

		@Override
		public Adapter caseOutput(Output object) {
			return createOutputAdapter();
		}

		@Override
		public Adapter caseFiltering(Filtering object) {
			return createFilteringAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.Vehicle <em>Vehicle</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.Vehicle
	 * @generated
	 */
	public Adapter createVehicleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.Sensor <em>Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.Sensor
	 * @generated
	 */
	public Adapter createSensorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.MotionSensor <em>Motion Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.MotionSensor
	 * @generated
	 */
	public Adapter createMotionSensorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.IRSsensor <em>IR Ssensor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.IRSsensor
	 * @generated
	 */
	public Adapter createIRSsensorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.PC <em>PC</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.PC
	 * @generated
	 */
	public Adapter createPCAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.SurvilanceAndTrackingSytems <em>Survilance And Tracking Sytems</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.SurvilanceAndTrackingSytems
	 * @generated
	 */
	public Adapter createSurvilanceAndTrackingSytemsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.ToolCollectionSystem <em>Tool Collection System</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.ToolCollectionSystem
	 * @generated
	 */
	public Adapter createToolCollectionSystemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.SecuritySystems <em>Security Systems</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.SecuritySystems
	 * @generated
	 */
	public Adapter createSecuritySystemsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.ParkingSystems <em>Parking Systems</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.ParkingSystems
	 * @generated
	 */
	public Adapter createParkingSystemsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.GeographicalMaps <em>Geographical Maps</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.GeographicalMaps
	 * @generated
	 */
	public Adapter createGeographicalMapsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.Port <em>Port</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.Port
	 * @generated
	 */
	public Adapter createPortAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.Input <em>Input</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.Input
	 * @generated
	 */
	public Adapter createInputAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.Output <em>Output</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.Output
	 * @generated
	 */
	public Adapter createOutputAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.Filtering <em>Filtering</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.Filtering
	 * @generated
	 */
	public Adapter createFilteringAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.DataAcquisition <em>Data Acquisition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.DataAcquisition
	 * @generated
	 */
	public Adapter createDataAcquisitionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.DIP <em>DIP</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.DIP
	 * @generated
	 */
	public Adapter createDIPAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.Records <em>Records</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.Records
	 * @generated
	 */
	public Adapter createRecordsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.ControlGate <em>Control Gate</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.ControlGate
	 * @generated
	 */
	public Adapter createControlGateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.EntranceSystem <em>Entrance System</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.EntranceSystem
	 * @generated
	 */
	public Adapter createEntranceSystemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.VehicleLocation <em>Vehicle Location</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.VehicleLocation
	 * @generated
	 */
	public Adapter createVehicleLocationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.Camera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.Camera
	 * @generated
	 */
	public Adapter createCameraAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.Image <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.Image
	 * @generated
	 */
	public Adapter createImageAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.ImageAcquisition <em>Image Acquisition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.ImageAcquisition
	 * @generated
	 */
	public Adapter createImageAcquisitionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.Preprocessing <em>Preprocessing</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.Preprocessing
	 * @generated
	 */
	public Adapter createPreprocessingAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.CharacterRecognition <em>Character Recognition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.CharacterRecognition
	 * @generated
	 */
	public Adapter createCharacterRecognitionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.Templates <em>Templates</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.Templates
	 * @generated
	 */
	public Adapter createTemplatesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.RegionOfInterest <em>Region Of Interest</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.RegionOfInterest
	 * @generated
	 */
	public Adapter createRegionOfInterestAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.SmoothingFilter <em>Smoothing Filter</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.SmoothingFilter
	 * @generated
	 */
	public Adapter createSmoothingFilterAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.Sharpening <em>Sharpening</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.Sharpening
	 * @generated
	 */
	public Adapter createSharpeningAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link ms21paper.CharacterSegmentation <em>Character Segmentation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see ms21paper.CharacterSegmentation
	 * @generated
	 */
	public Adapter createCharacterSegmentationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //Ms21paperAdapterFactory
