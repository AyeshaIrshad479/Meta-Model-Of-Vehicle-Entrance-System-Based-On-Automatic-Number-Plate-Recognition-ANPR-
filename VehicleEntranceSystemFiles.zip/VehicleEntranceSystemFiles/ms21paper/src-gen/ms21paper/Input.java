/**
 */
package ms21paper;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.Input#isSdata <em>Sdata</em>}</li>
 *   <li>{@link ms21paper.Input#getMotionsensor <em>Motionsensor</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getInput()
 * @model
 * @generated
 */
public interface Input extends Port {
	/**
	 * Returns the value of the '<em><b>Sdata</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sdata</em>' attribute.
	 * @see #setSdata(boolean)
	 * @see ms21paper.Ms21paperPackage#getInput_Sdata()
	 * @model
	 * @generated
	 */
	boolean isSdata();

	/**
	 * Sets the value of the '{@link ms21paper.Input#isSdata <em>Sdata</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sdata</em>' attribute.
	 * @see #isSdata()
	 * @generated
	 */
	void setSdata(boolean value);

	/**
	 * Returns the value of the '<em><b>Motionsensor</b></em>' reference list.
	 * The list contents are of type {@link ms21paper.Sensor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Motionsensor</em>' reference list.
	 * @see ms21paper.Ms21paperPackage#getInput_Motionsensor()
	 * @model upper="2"
	 * @generated
	 */
	EList<Sensor> getMotionsensor();

} // Input
