/**
 */
package ms21paper;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Geographical Maps</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.GeographicalMaps#getName <em>Name</em>}</li>
 *   <li>{@link ms21paper.GeographicalMaps#getVehiclelocation <em>Vehiclelocation</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getGeographicalMaps()
 * @model
 * @generated
 */
public interface GeographicalMaps extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see ms21paper.Ms21paperPackage#getGeographicalMaps_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link ms21paper.GeographicalMaps#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Vehiclelocation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vehiclelocation</em>' reference.
	 * @see #setVehiclelocation(VehicleLocation)
	 * @see ms21paper.Ms21paperPackage#getGeographicalMaps_Vehiclelocation()
	 * @model
	 * @generated
	 */
	VehicleLocation getVehiclelocation();

	/**
	 * Sets the value of the '{@link ms21paper.GeographicalMaps#getVehiclelocation <em>Vehiclelocation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vehiclelocation</em>' reference.
	 * @see #getVehiclelocation()
	 * @generated
	 */
	void setVehiclelocation(VehicleLocation value);

} // GeographicalMaps
