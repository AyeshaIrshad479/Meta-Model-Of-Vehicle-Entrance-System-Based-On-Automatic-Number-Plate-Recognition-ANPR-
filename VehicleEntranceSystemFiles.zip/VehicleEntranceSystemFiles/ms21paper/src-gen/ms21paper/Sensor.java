/**
 */
package ms21paper;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.Sensor#getDataacquisition <em>Dataacquisition</em>}</li>
 *   <li>{@link ms21paper.Sensor#getName <em>Name</em>}</li>
 *   <li>{@link ms21paper.Sensor#isSensorData <em>Sensor Data</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getSensor()
 * @model abstract="true"
 * @generated
 */
public interface Sensor extends EObject {
	/**
	 * Returns the value of the '<em><b>Dataacquisition</b></em>' reference list.
	 * The list contents are of type {@link ms21paper.DataAcquisition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dataacquisition</em>' reference list.
	 * @see ms21paper.Ms21paperPackage#getSensor_Dataacquisition()
	 * @model upper="3"
	 * @generated
	 */
	EList<DataAcquisition> getDataacquisition();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see ms21paper.Ms21paperPackage#getSensor_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link ms21paper.Sensor#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Sensor Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sensor Data</em>' attribute.
	 * @see #setSensorData(boolean)
	 * @see ms21paper.Ms21paperPackage#getSensor_SensorData()
	 * @model
	 * @generated
	 */
	boolean isSensorData();

	/**
	 * Sets the value of the '{@link ms21paper.Sensor#isSensorData <em>Sensor Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sensor Data</em>' attribute.
	 * @see #isSensorData()
	 * @generated
	 */
	void setSensorData(boolean value);

} // Sensor
