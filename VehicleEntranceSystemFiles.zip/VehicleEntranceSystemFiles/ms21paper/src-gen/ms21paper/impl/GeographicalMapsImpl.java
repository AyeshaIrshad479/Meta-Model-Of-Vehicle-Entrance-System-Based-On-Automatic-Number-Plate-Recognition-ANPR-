/**
 */
package ms21paper.impl;

import ms21paper.GeographicalMaps;
import ms21paper.Ms21paperPackage;
import ms21paper.VehicleLocation;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Geographical Maps</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.GeographicalMapsImpl#getName <em>Name</em>}</li>
 *   <li>{@link ms21paper.impl.GeographicalMapsImpl#getVehiclelocation <em>Vehiclelocation</em>}</li>
 * </ul>
 *
 * @generated
 */
public class GeographicalMapsImpl extends MinimalEObjectImpl.Container implements GeographicalMaps {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getVehiclelocation() <em>Vehiclelocation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVehiclelocation()
	 * @generated
	 * @ordered
	 */
	protected VehicleLocation vehiclelocation;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GeographicalMapsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.GEOGRAPHICAL_MAPS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.GEOGRAPHICAL_MAPS__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VehicleLocation getVehiclelocation() {
		if (vehiclelocation != null && vehiclelocation.eIsProxy()) {
			InternalEObject oldVehiclelocation = (InternalEObject) vehiclelocation;
			vehiclelocation = (VehicleLocation) eResolveProxy(oldVehiclelocation);
			if (vehiclelocation != oldVehiclelocation) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Ms21paperPackage.GEOGRAPHICAL_MAPS__VEHICLELOCATION, oldVehiclelocation, vehiclelocation));
			}
		}
		return vehiclelocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VehicleLocation basicGetVehiclelocation() {
		return vehiclelocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVehiclelocation(VehicleLocation newVehiclelocation) {
		VehicleLocation oldVehiclelocation = vehiclelocation;
		vehiclelocation = newVehiclelocation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.GEOGRAPHICAL_MAPS__VEHICLELOCATION,
					oldVehiclelocation, vehiclelocation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.GEOGRAPHICAL_MAPS__NAME:
			return getName();
		case Ms21paperPackage.GEOGRAPHICAL_MAPS__VEHICLELOCATION:
			if (resolve)
				return getVehiclelocation();
			return basicGetVehiclelocation();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.GEOGRAPHICAL_MAPS__NAME:
			setName((String) newValue);
			return;
		case Ms21paperPackage.GEOGRAPHICAL_MAPS__VEHICLELOCATION:
			setVehiclelocation((VehicleLocation) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.GEOGRAPHICAL_MAPS__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Ms21paperPackage.GEOGRAPHICAL_MAPS__VEHICLELOCATION:
			setVehiclelocation((VehicleLocation) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.GEOGRAPHICAL_MAPS__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Ms21paperPackage.GEOGRAPHICAL_MAPS__VEHICLELOCATION:
			return vehiclelocation != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //GeographicalMapsImpl
