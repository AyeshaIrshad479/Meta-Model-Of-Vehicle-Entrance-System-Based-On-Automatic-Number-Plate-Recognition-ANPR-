/**
 */
package ms21paper.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import ms21paper.CharacterRecognition;
import ms21paper.CharacterSegmentation;
import ms21paper.Ms21paperPackage;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Character Segmentation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.CharacterSegmentationImpl#getCharacterrecognition <em>Characterrecognition</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CharacterSegmentationImpl extends DIPImpl implements CharacterSegmentation {
	/**
	 * The cached value of the '{@link #getCharacterrecognition() <em>Characterrecognition</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCharacterrecognition()
	 * @generated
	 * @ordered
	 */
	protected EList<CharacterRecognition> characterrecognition;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CharacterSegmentationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.CHARACTER_SEGMENTATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<CharacterRecognition> getCharacterrecognition() {
		if (characterrecognition == null) {
			characterrecognition = new EObjectResolvingEList<CharacterRecognition>(CharacterRecognition.class, this,
					Ms21paperPackage.CHARACTER_SEGMENTATION__CHARACTERRECOGNITION);
		}
		return characterrecognition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void edgedetection() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void bwareaopen() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void imcrop() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void imresize() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.CHARACTER_SEGMENTATION__CHARACTERRECOGNITION:
			return getCharacterrecognition();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.CHARACTER_SEGMENTATION__CHARACTERRECOGNITION:
			getCharacterrecognition().clear();
			getCharacterrecognition().addAll((Collection<? extends CharacterRecognition>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.CHARACTER_SEGMENTATION__CHARACTERRECOGNITION:
			getCharacterrecognition().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.CHARACTER_SEGMENTATION__CHARACTERRECOGNITION:
			return characterrecognition != null && !characterrecognition.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case Ms21paperPackage.CHARACTER_SEGMENTATION___EDGEDETECTION:
			edgedetection();
			return null;
		case Ms21paperPackage.CHARACTER_SEGMENTATION___BWAREAOPEN:
			bwareaopen();
			return null;
		case Ms21paperPackage.CHARACTER_SEGMENTATION___IMCROP:
			imcrop();
			return null;
		case Ms21paperPackage.CHARACTER_SEGMENTATION___IMRESIZE:
			imresize();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

} //CharacterSegmentationImpl
