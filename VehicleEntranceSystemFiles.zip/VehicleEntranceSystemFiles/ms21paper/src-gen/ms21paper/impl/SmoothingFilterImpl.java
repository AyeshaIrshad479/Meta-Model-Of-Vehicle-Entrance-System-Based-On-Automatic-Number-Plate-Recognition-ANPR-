/**
 */
package ms21paper.impl;

import java.lang.reflect.InvocationTargetException;
import ms21paper.Ms21paperPackage;
import ms21paper.SmoothingFilter;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Smoothing Filter</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SmoothingFilterImpl extends FilteringImpl implements SmoothingFilter {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SmoothingFilterImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.SMOOTHING_FILTER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void Average() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case Ms21paperPackage.SMOOTHING_FILTER___AVERAGE:
			Average();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

} //SmoothingFilterImpl
