/**
 */
package ms21paper.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import ms21paper.Ms21paperPackage;
import ms21paper.Preprocessing;
import ms21paper.RegionOfInterest;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Preprocessing</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.PreprocessingImpl#getRegionofinterest <em>Regionofinterest</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PreprocessingImpl extends DIPImpl implements Preprocessing {
	/**
	 * The cached value of the '{@link #getRegionofinterest() <em>Regionofinterest</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRegionofinterest()
	 * @generated
	 * @ordered
	 */
	protected EList<RegionOfInterest> regionofinterest;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PreprocessingImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.PREPROCESSING;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<RegionOfInterest> getRegionofinterest() {
		if (regionofinterest == null) {
			regionofinterest = new EObjectResolvingEList<RegionOfInterest>(RegionOfInterest.class, this,
					Ms21paperPackage.PREPROCESSING__REGIONOFINTEREST);
		}
		return regionofinterest;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void Resize() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void rgb2gray() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void ImShow() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void ImBinrize() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void histeq() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.PREPROCESSING__REGIONOFINTEREST:
			return getRegionofinterest();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.PREPROCESSING__REGIONOFINTEREST:
			getRegionofinterest().clear();
			getRegionofinterest().addAll((Collection<? extends RegionOfInterest>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.PREPROCESSING__REGIONOFINTEREST:
			getRegionofinterest().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.PREPROCESSING__REGIONOFINTEREST:
			return regionofinterest != null && !regionofinterest.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case Ms21paperPackage.PREPROCESSING___RESIZE:
			Resize();
			return null;
		case Ms21paperPackage.PREPROCESSING___RGB2GRAY:
			rgb2gray();
			return null;
		case Ms21paperPackage.PREPROCESSING___IM_SHOW:
			ImShow();
			return null;
		case Ms21paperPackage.PREPROCESSING___IM_BINRIZE:
			ImBinrize();
			return null;
		case Ms21paperPackage.PREPROCESSING___HISTEQ:
			histeq();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

} //PreprocessingImpl
