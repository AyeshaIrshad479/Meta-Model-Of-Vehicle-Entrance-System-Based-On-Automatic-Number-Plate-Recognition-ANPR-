/**
 */
package ms21paper.impl;

import java.util.Collection;
import ms21paper.ControlGate;
import ms21paper.DataAcquisition;
import ms21paper.Ms21paperPackage;

import ms21paper.PC;
import ms21paper.Port;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Data Acquisition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.DataAcquisitionImpl#getControlgate <em>Controlgate</em>}</li>
 *   <li>{@link ms21paper.impl.DataAcquisitionImpl#getType <em>Type</em>}</li>
 *   <li>{@link ms21paper.impl.DataAcquisitionImpl#getPc <em>Pc</em>}</li>
 *   <li>{@link ms21paper.impl.DataAcquisitionImpl#getSensorData <em>Sensor Data</em>}</li>
 *   <li>{@link ms21paper.impl.DataAcquisitionImpl#isMotorStatus <em>Motor Status</em>}</li>
 *   <li>{@link ms21paper.impl.DataAcquisitionImpl#getPort <em>Port</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DataAcquisitionImpl extends MinimalEObjectImpl.Container implements DataAcquisition {
	/**
	 * The cached value of the '{@link #getControlgate() <em>Controlgate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getControlgate()
	 * @generated
	 * @ordered
	 */
	protected ControlGate controlgate;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = "ArduinoUNO";

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPc() <em>Pc</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPc()
	 * @generated
	 * @ordered
	 */
	protected PC pc;

	/**
	 * The default value of the '{@link #getSensorData() <em>Sensor Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSensorData()
	 * @generated
	 * @ordered
	 */
	protected static final Boolean SENSOR_DATA_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSensorData() <em>Sensor Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSensorData()
	 * @generated
	 * @ordered
	 */
	protected Boolean sensorData = SENSOR_DATA_EDEFAULT;

	/**
	 * The default value of the '{@link #isMotorStatus() <em>Motor Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isMotorStatus()
	 * @generated
	 * @ordered
	 */
	protected static final boolean MOTOR_STATUS_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isMotorStatus() <em>Motor Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isMotorStatus()
	 * @generated
	 * @ordered
	 */
	protected boolean motorStatus = MOTOR_STATUS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPort() <em>Port</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPort()
	 * @generated
	 * @ordered
	 */
	protected EList<Port> port;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DataAcquisitionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.DATA_ACQUISITION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ControlGate getControlgate() {
		if (controlgate != null && controlgate.eIsProxy()) {
			InternalEObject oldControlgate = (InternalEObject) controlgate;
			controlgate = (ControlGate) eResolveProxy(oldControlgate);
			if (controlgate != oldControlgate) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Ms21paperPackage.DATA_ACQUISITION__CONTROLGATE, oldControlgate, controlgate));
			}
		}
		return controlgate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ControlGate basicGetControlgate() {
		return controlgate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setControlgate(ControlGate newControlgate) {
		ControlGate oldControlgate = controlgate;
		controlgate = newControlgate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.DATA_ACQUISITION__CONTROLGATE,
					oldControlgate, controlgate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.DATA_ACQUISITION__TYPE, oldType,
					type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PC getPc() {
		if (pc != null && pc.eIsProxy()) {
			InternalEObject oldPc = (InternalEObject) pc;
			pc = (PC) eResolveProxy(oldPc);
			if (pc != oldPc) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Ms21paperPackage.DATA_ACQUISITION__PC,
							oldPc, pc));
			}
		}
		return pc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PC basicGetPc() {
		return pc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPc(PC newPc, NotificationChain msgs) {
		PC oldPc = pc;
		pc = newPc;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Ms21paperPackage.DATA_ACQUISITION__PC, oldPc, newPc);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPc(PC newPc) {
		if (newPc != pc) {
			NotificationChain msgs = null;
			if (pc != null)
				msgs = ((InternalEObject) pc).eInverseRemove(this, Ms21paperPackage.PC__DATAACQUISITION, PC.class,
						msgs);
			if (newPc != null)
				msgs = ((InternalEObject) newPc).eInverseAdd(this, Ms21paperPackage.PC__DATAACQUISITION, PC.class,
						msgs);
			msgs = basicSetPc(newPc, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.DATA_ACQUISITION__PC, newPc, newPc));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Boolean getSensorData() {
		return sensorData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSensorData(Boolean newSensorData) {
		Boolean oldSensorData = sensorData;
		sensorData = newSensorData;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.DATA_ACQUISITION__SENSOR_DATA,
					oldSensorData, sensorData));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isMotorStatus() {
		return motorStatus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setMotorStatus(boolean newMotorStatus) {
		boolean oldMotorStatus = motorStatus;
		motorStatus = newMotorStatus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.DATA_ACQUISITION__MOTOR_STATUS,
					oldMotorStatus, motorStatus));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Port> getPort() {
		if (port == null) {
			port = new EObjectContainmentEList<Port>(Port.class, this, Ms21paperPackage.DATA_ACQUISITION__PORT);
		}
		return port;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Ms21paperPackage.DATA_ACQUISITION__PC:
			if (pc != null)
				msgs = ((InternalEObject) pc).eInverseRemove(this, Ms21paperPackage.PC__DATAACQUISITION, PC.class,
						msgs);
			return basicSetPc((PC) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Ms21paperPackage.DATA_ACQUISITION__PC:
			return basicSetPc(null, msgs);
		case Ms21paperPackage.DATA_ACQUISITION__PORT:
			return ((InternalEList<?>) getPort()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.DATA_ACQUISITION__CONTROLGATE:
			if (resolve)
				return getControlgate();
			return basicGetControlgate();
		case Ms21paperPackage.DATA_ACQUISITION__TYPE:
			return getType();
		case Ms21paperPackage.DATA_ACQUISITION__PC:
			if (resolve)
				return getPc();
			return basicGetPc();
		case Ms21paperPackage.DATA_ACQUISITION__SENSOR_DATA:
			return getSensorData();
		case Ms21paperPackage.DATA_ACQUISITION__MOTOR_STATUS:
			return isMotorStatus();
		case Ms21paperPackage.DATA_ACQUISITION__PORT:
			return getPort();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.DATA_ACQUISITION__CONTROLGATE:
			setControlgate((ControlGate) newValue);
			return;
		case Ms21paperPackage.DATA_ACQUISITION__TYPE:
			setType((String) newValue);
			return;
		case Ms21paperPackage.DATA_ACQUISITION__PC:
			setPc((PC) newValue);
			return;
		case Ms21paperPackage.DATA_ACQUISITION__SENSOR_DATA:
			setSensorData((Boolean) newValue);
			return;
		case Ms21paperPackage.DATA_ACQUISITION__MOTOR_STATUS:
			setMotorStatus((Boolean) newValue);
			return;
		case Ms21paperPackage.DATA_ACQUISITION__PORT:
			getPort().clear();
			getPort().addAll((Collection<? extends Port>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.DATA_ACQUISITION__CONTROLGATE:
			setControlgate((ControlGate) null);
			return;
		case Ms21paperPackage.DATA_ACQUISITION__TYPE:
			setType(TYPE_EDEFAULT);
			return;
		case Ms21paperPackage.DATA_ACQUISITION__PC:
			setPc((PC) null);
			return;
		case Ms21paperPackage.DATA_ACQUISITION__SENSOR_DATA:
			setSensorData(SENSOR_DATA_EDEFAULT);
			return;
		case Ms21paperPackage.DATA_ACQUISITION__MOTOR_STATUS:
			setMotorStatus(MOTOR_STATUS_EDEFAULT);
			return;
		case Ms21paperPackage.DATA_ACQUISITION__PORT:
			getPort().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.DATA_ACQUISITION__CONTROLGATE:
			return controlgate != null;
		case Ms21paperPackage.DATA_ACQUISITION__TYPE:
			return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
		case Ms21paperPackage.DATA_ACQUISITION__PC:
			return pc != null;
		case Ms21paperPackage.DATA_ACQUISITION__SENSOR_DATA:
			return SENSOR_DATA_EDEFAULT == null ? sensorData != null : !SENSOR_DATA_EDEFAULT.equals(sensorData);
		case Ms21paperPackage.DATA_ACQUISITION__MOTOR_STATUS:
			return motorStatus != MOTOR_STATUS_EDEFAULT;
		case Ms21paperPackage.DATA_ACQUISITION__PORT:
			return port != null && !port.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Type: ");
		result.append(type);
		result.append(", SensorData: ");
		result.append(sensorData);
		result.append(", MotorStatus: ");
		result.append(motorStatus);
		result.append(')');
		return result.toString();
	}

} //DataAcquisitionImpl
