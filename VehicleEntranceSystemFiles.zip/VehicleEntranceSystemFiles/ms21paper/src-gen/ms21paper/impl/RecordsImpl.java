/**
 */
package ms21paper.impl;

import ms21paper.Ms21paperPackage;
import ms21paper.PC;
import ms21paper.Records;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Records</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.RecordsImpl#getName <em>Name</em>}</li>
 *   <li>{@link ms21paper.impl.RecordsImpl#getVnumber <em>Vnumber</em>}</li>
 *   <li>{@link ms21paper.impl.RecordsImpl#getPc <em>Pc</em>}</li>
 *   <li>{@link ms21paper.impl.RecordsImpl#getVOwnerID <em>VOwner ID</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RecordsImpl extends MinimalEObjectImpl.Container implements Records {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;
	/**
	 * The default value of the '{@link #getVnumber() <em>Vnumber</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVnumber()
	 * @generated
	 * @ordered
	 */
	protected static final String VNUMBER_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getVnumber() <em>Vnumber</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVnumber()
	 * @generated
	 * @ordered
	 */
	protected String vnumber = VNUMBER_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPc() <em>Pc</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPc()
	 * @generated
	 * @ordered
	 */
	protected PC pc;

	/**
	 * The default value of the '{@link #getVOwnerID() <em>VOwner ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVOwnerID()
	 * @generated
	 * @ordered
	 */
	protected static final short VOWNER_ID_EDEFAULT = 0;
	/**
	 * The cached value of the '{@link #getVOwnerID() <em>VOwner ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVOwnerID()
	 * @generated
	 * @ordered
	 */
	protected short vOwnerID = VOWNER_ID_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RecordsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.RECORDS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.RECORDS__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getVnumber() {
		return vnumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVnumber(String newVnumber) {
		String oldVnumber = vnumber;
		vnumber = newVnumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.RECORDS__VNUMBER, oldVnumber,
					vnumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PC getPc() {
		if (pc != null && pc.eIsProxy()) {
			InternalEObject oldPc = (InternalEObject) pc;
			pc = (PC) eResolveProxy(oldPc);
			if (pc != oldPc) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Ms21paperPackage.RECORDS__PC, oldPc, pc));
			}
		}
		return pc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PC basicGetPc() {
		return pc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPc(PC newPc, NotificationChain msgs) {
		PC oldPc = pc;
		pc = newPc;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Ms21paperPackage.RECORDS__PC,
					oldPc, newPc);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPc(PC newPc) {
		if (newPc != pc) {
			NotificationChain msgs = null;
			if (pc != null)
				msgs = ((InternalEObject) pc).eInverseRemove(this, Ms21paperPackage.PC__RECORDS, PC.class, msgs);
			if (newPc != null)
				msgs = ((InternalEObject) newPc).eInverseAdd(this, Ms21paperPackage.PC__RECORDS, PC.class, msgs);
			msgs = basicSetPc(newPc, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.RECORDS__PC, newPc, newPc));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public short getVOwnerID() {
		return vOwnerID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVOwnerID(short newVOwnerID) {
		short oldVOwnerID = vOwnerID;
		vOwnerID = newVOwnerID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.RECORDS__VOWNER_ID, oldVOwnerID,
					vOwnerID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Ms21paperPackage.RECORDS__PC:
			if (pc != null)
				msgs = ((InternalEObject) pc).eInverseRemove(this, Ms21paperPackage.PC__RECORDS, PC.class, msgs);
			return basicSetPc((PC) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Ms21paperPackage.RECORDS__PC:
			return basicSetPc(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.RECORDS__NAME:
			return getName();
		case Ms21paperPackage.RECORDS__VNUMBER:
			return getVnumber();
		case Ms21paperPackage.RECORDS__PC:
			if (resolve)
				return getPc();
			return basicGetPc();
		case Ms21paperPackage.RECORDS__VOWNER_ID:
			return getVOwnerID();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.RECORDS__NAME:
			setName((String) newValue);
			return;
		case Ms21paperPackage.RECORDS__VNUMBER:
			setVnumber((String) newValue);
			return;
		case Ms21paperPackage.RECORDS__PC:
			setPc((PC) newValue);
			return;
		case Ms21paperPackage.RECORDS__VOWNER_ID:
			setVOwnerID((Short) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.RECORDS__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Ms21paperPackage.RECORDS__VNUMBER:
			setVnumber(VNUMBER_EDEFAULT);
			return;
		case Ms21paperPackage.RECORDS__PC:
			setPc((PC) null);
			return;
		case Ms21paperPackage.RECORDS__VOWNER_ID:
			setVOwnerID(VOWNER_ID_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.RECORDS__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Ms21paperPackage.RECORDS__VNUMBER:
			return VNUMBER_EDEFAULT == null ? vnumber != null : !VNUMBER_EDEFAULT.equals(vnumber);
		case Ms21paperPackage.RECORDS__PC:
			return pc != null;
		case Ms21paperPackage.RECORDS__VOWNER_ID:
			return vOwnerID != VOWNER_ID_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", vnumber: ");
		result.append(vnumber);
		result.append(", VOwnerID: ");
		result.append(vOwnerID);
		result.append(')');
		return result.toString();
	}

} //RecordsImpl
