/**
 */
package ms21paper.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import ms21paper.CharacterSegmentation;
import ms21paper.Ms21paperPackage;
import ms21paper.RegionOfInterest;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Region Of Interest</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.RegionOfInterestImpl#getCharactersegmentation <em>Charactersegmentation</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RegionOfInterestImpl extends DIPImpl implements RegionOfInterest {
	/**
	 * The cached value of the '{@link #getCharactersegmentation() <em>Charactersegmentation</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCharactersegmentation()
	 * @generated
	 * @ordered
	 */
	protected EList<CharacterSegmentation> charactersegmentation;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RegionOfInterestImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.REGION_OF_INTEREST;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<CharacterSegmentation> getCharactersegmentation() {
		if (charactersegmentation == null) {
			charactersegmentation = new EObjectResolvingEList<CharacterSegmentation>(CharacterSegmentation.class, this,
					Ms21paperPackage.REGION_OF_INTEREST__CHARACTERSEGMENTATION);
		}
		return charactersegmentation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void edge() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void bwlabel() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void regionprops() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void imdialate() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void imerode() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.REGION_OF_INTEREST__CHARACTERSEGMENTATION:
			return getCharactersegmentation();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.REGION_OF_INTEREST__CHARACTERSEGMENTATION:
			getCharactersegmentation().clear();
			getCharactersegmentation().addAll((Collection<? extends CharacterSegmentation>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.REGION_OF_INTEREST__CHARACTERSEGMENTATION:
			getCharactersegmentation().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.REGION_OF_INTEREST__CHARACTERSEGMENTATION:
			return charactersegmentation != null && !charactersegmentation.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case Ms21paperPackage.REGION_OF_INTEREST___EDGE:
			edge();
			return null;
		case Ms21paperPackage.REGION_OF_INTEREST___BWLABEL:
			bwlabel();
			return null;
		case Ms21paperPackage.REGION_OF_INTEREST___REGIONPROPS:
			regionprops();
			return null;
		case Ms21paperPackage.REGION_OF_INTEREST___IMDIALATE:
			imdialate();
			return null;
		case Ms21paperPackage.REGION_OF_INTEREST___IMERODE:
			imerode();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

} //RegionOfInterestImpl
