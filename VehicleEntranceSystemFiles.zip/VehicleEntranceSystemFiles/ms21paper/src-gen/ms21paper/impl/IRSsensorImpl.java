/**
 */
package ms21paper.impl;

import ms21paper.IRSsensor;
import ms21paper.Ms21paperPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>IR Ssensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class IRSsensorImpl extends SensorImpl implements IRSsensor {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IRSsensorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.IR_SSENSOR;
	}

} //IRSsensorImpl
