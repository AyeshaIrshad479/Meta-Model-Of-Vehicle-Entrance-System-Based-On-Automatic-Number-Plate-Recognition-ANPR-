/**
 */
package ms21paper.impl;

import java.util.Collection;
import ms21paper.DIP;
import ms21paper.DataAcquisition;
import ms21paper.Ms21paperPackage;
import ms21paper.PC;
import ms21paper.Records;
import ms21paper.VehicleLocation;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>PC</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.PCImpl#getName <em>Name</em>}</li>
 *   <li>{@link ms21paper.impl.PCImpl#getVnumber <em>Vnumber</em>}</li>
 *   <li>{@link ms21paper.impl.PCImpl#getDataacquisition <em>Dataacquisition</em>}</li>
 *   <li>{@link ms21paper.impl.PCImpl#getRecords <em>Records</em>}</li>
 *   <li>{@link ms21paper.impl.PCImpl#getDip <em>Dip</em>}</li>
 *   <li>{@link ms21paper.impl.PCImpl#getVehiclelocation <em>Vehiclelocation</em>}</li>
 *   <li>{@link ms21paper.impl.PCImpl#getVehicleRecord <em>Vehicle Record</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PCImpl extends MinimalEObjectImpl.Container implements PC {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getVnumber() <em>Vnumber</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVnumber()
	 * @generated
	 * @ordered
	 */
	protected static final String VNUMBER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getVnumber() <em>Vnumber</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVnumber()
	 * @generated
	 * @ordered
	 */
	protected String vnumber = VNUMBER_EDEFAULT;

	/**
	 * The cached value of the '{@link #getDataacquisition() <em>Dataacquisition</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataacquisition()
	 * @generated
	 * @ordered
	 */
	protected EList<DataAcquisition> dataacquisition;

	/**
	 * The cached value of the '{@link #getRecords() <em>Records</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecords()
	 * @generated
	 * @ordered
	 */
	protected EList<Records> records;

	/**
	 * The cached value of the '{@link #getDip() <em>Dip</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDip()
	 * @generated
	 * @ordered
	 */
	protected EList<DIP> dip;

	/**
	 * The cached value of the '{@link #getVehiclelocation() <em>Vehiclelocation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVehiclelocation()
	 * @generated
	 * @ordered
	 */
	protected VehicleLocation vehiclelocation;

	/**
	 * The default value of the '{@link #getVehicleRecord() <em>Vehicle Record</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVehicleRecord()
	 * @generated
	 * @ordered
	 */
	protected static final String VEHICLE_RECORD_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getVehicleRecord() <em>Vehicle Record</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVehicleRecord()
	 * @generated
	 * @ordered
	 */
	protected String vehicleRecord = VEHICLE_RECORD_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PCImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.PC;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.PC__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getVnumber() {
		return vnumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVnumber(String newVnumber) {
		String oldVnumber = vnumber;
		vnumber = newVnumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.PC__VNUMBER, oldVnumber, vnumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<DataAcquisition> getDataacquisition() {
		if (dataacquisition == null) {
			dataacquisition = new EObjectWithInverseResolvingEList<DataAcquisition>(DataAcquisition.class, this,
					Ms21paperPackage.PC__DATAACQUISITION, Ms21paperPackage.DATA_ACQUISITION__PC);
		}
		return dataacquisition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Records> getRecords() {
		if (records == null) {
			records = new EObjectWithInverseResolvingEList<Records>(Records.class, this, Ms21paperPackage.PC__RECORDS,
					Ms21paperPackage.RECORDS__PC);
		}
		return records;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<DIP> getDip() {
		if (dip == null) {
			dip = new EObjectWithInverseResolvingEList<DIP>(DIP.class, this, Ms21paperPackage.PC__DIP,
					Ms21paperPackage.DIP__PC);
		}
		return dip;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VehicleLocation getVehiclelocation() {
		if (vehiclelocation != null && vehiclelocation.eIsProxy()) {
			InternalEObject oldVehiclelocation = (InternalEObject) vehiclelocation;
			vehiclelocation = (VehicleLocation) eResolveProxy(oldVehiclelocation);
			if (vehiclelocation != oldVehiclelocation) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Ms21paperPackage.PC__VEHICLELOCATION,
							oldVehiclelocation, vehiclelocation));
			}
		}
		return vehiclelocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VehicleLocation basicGetVehiclelocation() {
		return vehiclelocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVehiclelocation(VehicleLocation newVehiclelocation) {
		VehicleLocation oldVehiclelocation = vehiclelocation;
		vehiclelocation = newVehiclelocation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.PC__VEHICLELOCATION,
					oldVehiclelocation, vehiclelocation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getVehicleRecord() {
		return vehicleRecord;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVehicleRecord(String newVehicleRecord) {
		String oldVehicleRecord = vehicleRecord;
		vehicleRecord = newVehicleRecord;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.PC__VEHICLE_RECORD, oldVehicleRecord,
					vehicleRecord));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Ms21paperPackage.PC__DATAACQUISITION:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getDataacquisition()).basicAdd(otherEnd, msgs);
		case Ms21paperPackage.PC__RECORDS:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getRecords()).basicAdd(otherEnd, msgs);
		case Ms21paperPackage.PC__DIP:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getDip()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Ms21paperPackage.PC__DATAACQUISITION:
			return ((InternalEList<?>) getDataacquisition()).basicRemove(otherEnd, msgs);
		case Ms21paperPackage.PC__RECORDS:
			return ((InternalEList<?>) getRecords()).basicRemove(otherEnd, msgs);
		case Ms21paperPackage.PC__DIP:
			return ((InternalEList<?>) getDip()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.PC__NAME:
			return getName();
		case Ms21paperPackage.PC__VNUMBER:
			return getVnumber();
		case Ms21paperPackage.PC__DATAACQUISITION:
			return getDataacquisition();
		case Ms21paperPackage.PC__RECORDS:
			return getRecords();
		case Ms21paperPackage.PC__DIP:
			return getDip();
		case Ms21paperPackage.PC__VEHICLELOCATION:
			if (resolve)
				return getVehiclelocation();
			return basicGetVehiclelocation();
		case Ms21paperPackage.PC__VEHICLE_RECORD:
			return getVehicleRecord();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.PC__NAME:
			setName((String) newValue);
			return;
		case Ms21paperPackage.PC__VNUMBER:
			setVnumber((String) newValue);
			return;
		case Ms21paperPackage.PC__DATAACQUISITION:
			getDataacquisition().clear();
			getDataacquisition().addAll((Collection<? extends DataAcquisition>) newValue);
			return;
		case Ms21paperPackage.PC__RECORDS:
			getRecords().clear();
			getRecords().addAll((Collection<? extends Records>) newValue);
			return;
		case Ms21paperPackage.PC__DIP:
			getDip().clear();
			getDip().addAll((Collection<? extends DIP>) newValue);
			return;
		case Ms21paperPackage.PC__VEHICLELOCATION:
			setVehiclelocation((VehicleLocation) newValue);
			return;
		case Ms21paperPackage.PC__VEHICLE_RECORD:
			setVehicleRecord((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.PC__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Ms21paperPackage.PC__VNUMBER:
			setVnumber(VNUMBER_EDEFAULT);
			return;
		case Ms21paperPackage.PC__DATAACQUISITION:
			getDataacquisition().clear();
			return;
		case Ms21paperPackage.PC__RECORDS:
			getRecords().clear();
			return;
		case Ms21paperPackage.PC__DIP:
			getDip().clear();
			return;
		case Ms21paperPackage.PC__VEHICLELOCATION:
			setVehiclelocation((VehicleLocation) null);
			return;
		case Ms21paperPackage.PC__VEHICLE_RECORD:
			setVehicleRecord(VEHICLE_RECORD_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.PC__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Ms21paperPackage.PC__VNUMBER:
			return VNUMBER_EDEFAULT == null ? vnumber != null : !VNUMBER_EDEFAULT.equals(vnumber);
		case Ms21paperPackage.PC__DATAACQUISITION:
			return dataacquisition != null && !dataacquisition.isEmpty();
		case Ms21paperPackage.PC__RECORDS:
			return records != null && !records.isEmpty();
		case Ms21paperPackage.PC__DIP:
			return dip != null && !dip.isEmpty();
		case Ms21paperPackage.PC__VEHICLELOCATION:
			return vehiclelocation != null;
		case Ms21paperPackage.PC__VEHICLE_RECORD:
			return VEHICLE_RECORD_EDEFAULT == null ? vehicleRecord != null
					: !VEHICLE_RECORD_EDEFAULT.equals(vehicleRecord);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", vnumber: ");
		result.append(vnumber);
		result.append(", VehicleRecord: ");
		result.append(vehicleRecord);
		result.append(')');
		return result.toString();
	}

} //PCImpl
