/**
 */
package ms21paper.impl;

import java.util.Collection;

import ms21paper.Input;
import ms21paper.Ms21paperPackage;
import ms21paper.Sensor;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Input</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.InputImpl#isSdata <em>Sdata</em>}</li>
 *   <li>{@link ms21paper.impl.InputImpl#getMotionsensor <em>Motionsensor</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InputImpl extends PortImpl implements Input {
	/**
	 * The default value of the '{@link #isSdata() <em>Sdata</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSdata()
	 * @generated
	 * @ordered
	 */
	protected static final boolean SDATA_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isSdata() <em>Sdata</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSdata()
	 * @generated
	 * @ordered
	 */
	protected boolean sdata = SDATA_EDEFAULT;

	/**
	 * The cached value of the '{@link #getMotionsensor() <em>Motionsensor</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMotionsensor()
	 * @generated
	 * @ordered
	 */
	protected EList<Sensor> motionsensor;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InputImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.INPUT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isSdata() {
		return sdata;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSdata(boolean newSdata) {
		boolean oldSdata = sdata;
		sdata = newSdata;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.INPUT__SDATA, oldSdata, sdata));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Sensor> getMotionsensor() {
		if (motionsensor == null) {
			motionsensor = new EObjectResolvingEList<Sensor>(Sensor.class, this, Ms21paperPackage.INPUT__MOTIONSENSOR);
		}
		return motionsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.INPUT__SDATA:
			return isSdata();
		case Ms21paperPackage.INPUT__MOTIONSENSOR:
			return getMotionsensor();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.INPUT__SDATA:
			setSdata((Boolean) newValue);
			return;
		case Ms21paperPackage.INPUT__MOTIONSENSOR:
			getMotionsensor().clear();
			getMotionsensor().addAll((Collection<? extends Sensor>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.INPUT__SDATA:
			setSdata(SDATA_EDEFAULT);
			return;
		case Ms21paperPackage.INPUT__MOTIONSENSOR:
			getMotionsensor().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.INPUT__SDATA:
			return sdata != SDATA_EDEFAULT;
		case Ms21paperPackage.INPUT__MOTIONSENSOR:
			return motionsensor != null && !motionsensor.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Sdata: ");
		result.append(sdata);
		result.append(')');
		return result.toString();
	}

} //InputImpl
