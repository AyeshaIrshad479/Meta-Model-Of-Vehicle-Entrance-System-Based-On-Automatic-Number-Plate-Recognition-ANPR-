/**
 */
package ms21paper.impl;

import java.util.Collection;

import ms21paper.ControlGate;
import ms21paper.DIP;
import ms21paper.DataAcquisition;
import ms21paper.EntranceSystem;
import ms21paper.Ms21paperPackage;
import ms21paper.PC;
import ms21paper.Records;
import ms21paper.Sensor;
import ms21paper.Vehicle;

import ms21paper.VehicleLocation;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Entrance System</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.EntranceSystemImpl#getVehicle <em>Vehicle</em>}</li>
 *   <li>{@link ms21paper.impl.EntranceSystemImpl#getMotionsensor <em>Motionsensor</em>}</li>
 *   <li>{@link ms21paper.impl.EntranceSystemImpl#getDataacquisition <em>Dataacquisition</em>}</li>
 *   <li>{@link ms21paper.impl.EntranceSystemImpl#getDip <em>Dip</em>}</li>
 *   <li>{@link ms21paper.impl.EntranceSystemImpl#getRecords <em>Records</em>}</li>
 *   <li>{@link ms21paper.impl.EntranceSystemImpl#getVehiclelocation <em>Vehiclelocation</em>}</li>
 *   <li>{@link ms21paper.impl.EntranceSystemImpl#getControlgate <em>Controlgate</em>}</li>
 *   <li>{@link ms21paper.impl.EntranceSystemImpl#getPc <em>Pc</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EntranceSystemImpl extends MinimalEObjectImpl.Container implements EntranceSystem {
	/**
	 * The cached value of the '{@link #getVehicle() <em>Vehicle</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVehicle()
	 * @generated
	 * @ordered
	 */
	protected Vehicle vehicle;

	/**
	 * The cached value of the '{@link #getMotionsensor() <em>Motionsensor</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMotionsensor()
	 * @generated
	 * @ordered
	 */
	protected EList<Sensor> motionsensor;

	/**
	 * The cached value of the '{@link #getDataacquisition() <em>Dataacquisition</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataacquisition()
	 * @generated
	 * @ordered
	 */
	protected EList<DataAcquisition> dataacquisition;

	/**
	 * The cached value of the '{@link #getDip() <em>Dip</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDip()
	 * @generated
	 * @ordered
	 */
	protected EList<DIP> dip;

	/**
	 * The cached value of the '{@link #getRecords() <em>Records</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecords()
	 * @generated
	 * @ordered
	 */
	protected EList<Records> records;

	/**
	 * The cached value of the '{@link #getVehiclelocation() <em>Vehiclelocation</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVehiclelocation()
	 * @generated
	 * @ordered
	 */
	protected VehicleLocation vehiclelocation;

	/**
	 * The cached value of the '{@link #getControlgate() <em>Controlgate</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getControlgate()
	 * @generated
	 * @ordered
	 */
	protected ControlGate controlgate;

	/**
	 * The cached value of the '{@link #getPc() <em>Pc</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPc()
	 * @generated
	 * @ordered
	 */
	protected EList<PC> pc;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EntranceSystemImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.ENTRANCE_SYSTEM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Vehicle getVehicle() {
		return vehicle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetVehicle(Vehicle newVehicle, NotificationChain msgs) {
		Vehicle oldVehicle = vehicle;
		vehicle = newVehicle;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLE, oldVehicle, newVehicle);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVehicle(Vehicle newVehicle) {
		if (newVehicle != vehicle) {
			NotificationChain msgs = null;
			if (vehicle != null)
				msgs = ((InternalEObject) vehicle).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLE, null, msgs);
			if (newVehicle != null)
				msgs = ((InternalEObject) newVehicle).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLE, null, msgs);
			msgs = basicSetVehicle(newVehicle, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLE, newVehicle,
					newVehicle));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Sensor> getMotionsensor() {
		if (motionsensor == null) {
			motionsensor = new EObjectContainmentEList<Sensor>(Sensor.class, this,
					Ms21paperPackage.ENTRANCE_SYSTEM__MOTIONSENSOR);
		}
		return motionsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<DataAcquisition> getDataacquisition() {
		if (dataacquisition == null) {
			dataacquisition = new EObjectContainmentEList<DataAcquisition>(DataAcquisition.class, this,
					Ms21paperPackage.ENTRANCE_SYSTEM__DATAACQUISITION);
		}
		return dataacquisition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<DIP> getDip() {
		if (dip == null) {
			dip = new EObjectContainmentEList<DIP>(DIP.class, this, Ms21paperPackage.ENTRANCE_SYSTEM__DIP);
		}
		return dip;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Records> getRecords() {
		if (records == null) {
			records = new EObjectContainmentEList<Records>(Records.class, this,
					Ms21paperPackage.ENTRANCE_SYSTEM__RECORDS);
		}
		return records;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VehicleLocation getVehiclelocation() {
		return vehiclelocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetVehiclelocation(VehicleLocation newVehiclelocation, NotificationChain msgs) {
		VehicleLocation oldVehiclelocation = vehiclelocation;
		vehiclelocation = newVehiclelocation;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLELOCATION, oldVehiclelocation, newVehiclelocation);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVehiclelocation(VehicleLocation newVehiclelocation) {
		if (newVehiclelocation != vehiclelocation) {
			NotificationChain msgs = null;
			if (vehiclelocation != null)
				msgs = ((InternalEObject) vehiclelocation).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLELOCATION, null, msgs);
			if (newVehiclelocation != null)
				msgs = ((InternalEObject) newVehiclelocation).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLELOCATION, null, msgs);
			msgs = basicSetVehiclelocation(newVehiclelocation, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLELOCATION,
					newVehiclelocation, newVehiclelocation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ControlGate getControlgate() {
		return controlgate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetControlgate(ControlGate newControlgate, NotificationChain msgs) {
		ControlGate oldControlgate = controlgate;
		controlgate = newControlgate;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Ms21paperPackage.ENTRANCE_SYSTEM__CONTROLGATE, oldControlgate, newControlgate);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setControlgate(ControlGate newControlgate) {
		if (newControlgate != controlgate) {
			NotificationChain msgs = null;
			if (controlgate != null)
				msgs = ((InternalEObject) controlgate).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - Ms21paperPackage.ENTRANCE_SYSTEM__CONTROLGATE, null, msgs);
			if (newControlgate != null)
				msgs = ((InternalEObject) newControlgate).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - Ms21paperPackage.ENTRANCE_SYSTEM__CONTROLGATE, null, msgs);
			msgs = basicSetControlgate(newControlgate, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.ENTRANCE_SYSTEM__CONTROLGATE,
					newControlgate, newControlgate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<PC> getPc() {
		if (pc == null) {
			pc = new EObjectContainmentEList<PC>(PC.class, this, Ms21paperPackage.ENTRANCE_SYSTEM__PC);
		}
		return pc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLE:
			return basicSetVehicle(null, msgs);
		case Ms21paperPackage.ENTRANCE_SYSTEM__MOTIONSENSOR:
			return ((InternalEList<?>) getMotionsensor()).basicRemove(otherEnd, msgs);
		case Ms21paperPackage.ENTRANCE_SYSTEM__DATAACQUISITION:
			return ((InternalEList<?>) getDataacquisition()).basicRemove(otherEnd, msgs);
		case Ms21paperPackage.ENTRANCE_SYSTEM__DIP:
			return ((InternalEList<?>) getDip()).basicRemove(otherEnd, msgs);
		case Ms21paperPackage.ENTRANCE_SYSTEM__RECORDS:
			return ((InternalEList<?>) getRecords()).basicRemove(otherEnd, msgs);
		case Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLELOCATION:
			return basicSetVehiclelocation(null, msgs);
		case Ms21paperPackage.ENTRANCE_SYSTEM__CONTROLGATE:
			return basicSetControlgate(null, msgs);
		case Ms21paperPackage.ENTRANCE_SYSTEM__PC:
			return ((InternalEList<?>) getPc()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLE:
			return getVehicle();
		case Ms21paperPackage.ENTRANCE_SYSTEM__MOTIONSENSOR:
			return getMotionsensor();
		case Ms21paperPackage.ENTRANCE_SYSTEM__DATAACQUISITION:
			return getDataacquisition();
		case Ms21paperPackage.ENTRANCE_SYSTEM__DIP:
			return getDip();
		case Ms21paperPackage.ENTRANCE_SYSTEM__RECORDS:
			return getRecords();
		case Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLELOCATION:
			return getVehiclelocation();
		case Ms21paperPackage.ENTRANCE_SYSTEM__CONTROLGATE:
			return getControlgate();
		case Ms21paperPackage.ENTRANCE_SYSTEM__PC:
			return getPc();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLE:
			setVehicle((Vehicle) newValue);
			return;
		case Ms21paperPackage.ENTRANCE_SYSTEM__MOTIONSENSOR:
			getMotionsensor().clear();
			getMotionsensor().addAll((Collection<? extends Sensor>) newValue);
			return;
		case Ms21paperPackage.ENTRANCE_SYSTEM__DATAACQUISITION:
			getDataacquisition().clear();
			getDataacquisition().addAll((Collection<? extends DataAcquisition>) newValue);
			return;
		case Ms21paperPackage.ENTRANCE_SYSTEM__DIP:
			getDip().clear();
			getDip().addAll((Collection<? extends DIP>) newValue);
			return;
		case Ms21paperPackage.ENTRANCE_SYSTEM__RECORDS:
			getRecords().clear();
			getRecords().addAll((Collection<? extends Records>) newValue);
			return;
		case Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLELOCATION:
			setVehiclelocation((VehicleLocation) newValue);
			return;
		case Ms21paperPackage.ENTRANCE_SYSTEM__CONTROLGATE:
			setControlgate((ControlGate) newValue);
			return;
		case Ms21paperPackage.ENTRANCE_SYSTEM__PC:
			getPc().clear();
			getPc().addAll((Collection<? extends PC>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLE:
			setVehicle((Vehicle) null);
			return;
		case Ms21paperPackage.ENTRANCE_SYSTEM__MOTIONSENSOR:
			getMotionsensor().clear();
			return;
		case Ms21paperPackage.ENTRANCE_SYSTEM__DATAACQUISITION:
			getDataacquisition().clear();
			return;
		case Ms21paperPackage.ENTRANCE_SYSTEM__DIP:
			getDip().clear();
			return;
		case Ms21paperPackage.ENTRANCE_SYSTEM__RECORDS:
			getRecords().clear();
			return;
		case Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLELOCATION:
			setVehiclelocation((VehicleLocation) null);
			return;
		case Ms21paperPackage.ENTRANCE_SYSTEM__CONTROLGATE:
			setControlgate((ControlGate) null);
			return;
		case Ms21paperPackage.ENTRANCE_SYSTEM__PC:
			getPc().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLE:
			return vehicle != null;
		case Ms21paperPackage.ENTRANCE_SYSTEM__MOTIONSENSOR:
			return motionsensor != null && !motionsensor.isEmpty();
		case Ms21paperPackage.ENTRANCE_SYSTEM__DATAACQUISITION:
			return dataacquisition != null && !dataacquisition.isEmpty();
		case Ms21paperPackage.ENTRANCE_SYSTEM__DIP:
			return dip != null && !dip.isEmpty();
		case Ms21paperPackage.ENTRANCE_SYSTEM__RECORDS:
			return records != null && !records.isEmpty();
		case Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLELOCATION:
			return vehiclelocation != null;
		case Ms21paperPackage.ENTRANCE_SYSTEM__CONTROLGATE:
			return controlgate != null;
		case Ms21paperPackage.ENTRANCE_SYSTEM__PC:
			return pc != null && !pc.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //EntranceSystemImpl
