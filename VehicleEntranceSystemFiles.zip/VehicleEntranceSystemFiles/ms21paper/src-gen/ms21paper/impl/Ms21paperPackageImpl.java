/**
 */
package ms21paper.impl;

import ms21paper.Camera;
import ms21paper.CharacterRecognition;
import ms21paper.CharacterSegmentation;
import ms21paper.ControlGate;
import ms21paper.DataAcquisition;
import ms21paper.EntranceSystem;
import ms21paper.Filtering;
import ms21paper.GeographicalMaps;
import ms21paper.IRSsensor;
import ms21paper.Image;
import ms21paper.ImageAcquisition;
import ms21paper.Input;
import ms21paper.MotionSensor;
import ms21paper.Ms21paperFactory;
import ms21paper.Ms21paperPackage;
import ms21paper.Output;
import ms21paper.ParkingSystems;
import ms21paper.Port;
import ms21paper.Preprocessing;
import ms21paper.Records;
import ms21paper.RegionOfInterest;
import ms21paper.SecuritySystems;
import ms21paper.Sensor;
import ms21paper.Sharpening;
import ms21paper.SmoothingFilter;
import ms21paper.SurvilanceAndTrackingSytems;
import ms21paper.Templates;
import ms21paper.ToolCollectionSystem;
import ms21paper.TypeController;
import ms21paper.TypePort;
import ms21paper.Vehicle;

import ms21paper.VehicleLocation;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;
import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Ms21paperPackageImpl extends EPackageImpl implements Ms21paperPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass vehicleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sensorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass motionSensorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass irSsensorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass pcEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass survilanceAndTrackingSytemsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass toolCollectionSystemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass securitySystemsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass parkingSystemsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass geographicalMapsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass portEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass inputEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass outputEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass filteringEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum typeControllerEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum typePortEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dataAcquisitionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dipEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass recordsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass controlGateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass entranceSystemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass vehicleLocationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cameraEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass imageEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass imageAcquisitionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass preprocessingEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass characterRecognitionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass templatesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass regionOfInterestEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass smoothingFilterEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sharpeningEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass characterSegmentationEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see ms21paper.Ms21paperPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private Ms21paperPackageImpl() {
		super(eNS_URI, Ms21paperFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link Ms21paperPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static Ms21paperPackage init() {
		if (isInited)
			return (Ms21paperPackage) EPackage.Registry.INSTANCE.getEPackage(Ms21paperPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredMs21paperPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		Ms21paperPackageImpl theMs21paperPackage = registeredMs21paperPackage instanceof Ms21paperPackageImpl
				? (Ms21paperPackageImpl) registeredMs21paperPackage
				: new Ms21paperPackageImpl();

		isInited = true;

		// Initialize simple dependencies
		XMLTypePackage.eINSTANCE.eClass();

		// Create package meta-data objects
		theMs21paperPackage.createPackageContents();

		// Initialize created meta-data
		theMs21paperPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theMs21paperPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(Ms21paperPackage.eNS_URI, theMs21paperPackage);
		return theMs21paperPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getVehicle() {
		return vehicleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getVehicle_Motionsensor() {
		return (EReference) vehicleEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getVehicle_Name() {
		return (EAttribute) vehicleEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getVehicle_Vnumber() {
		return (EAttribute) vehicleEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getVehicle_OwnerID() {
		return (EAttribute) vehicleEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSensor() {
		return sensorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSensor_Dataacquisition() {
		return (EReference) sensorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSensor_Name() {
		return (EAttribute) sensorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSensor_SensorData() {
		return (EAttribute) sensorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMotionSensor() {
		return motionSensorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getIRSsensor() {
		return irSsensorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPC() {
		return pcEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPC_Name() {
		return (EAttribute) pcEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPC_Vnumber() {
		return (EAttribute) pcEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPC_Dataacquisition() {
		return (EReference) pcEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPC_Records() {
		return (EReference) pcEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPC_Dip() {
		return (EReference) pcEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPC_Vehiclelocation() {
		return (EReference) pcEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPC_VehicleRecord() {
		return (EAttribute) pcEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSurvilanceAndTrackingSytems() {
		return survilanceAndTrackingSytemsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSurvilanceAndTrackingSytems_Entrancesystem() {
		return (EReference) survilanceAndTrackingSytemsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getToolCollectionSystem() {
		return toolCollectionSystemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getToolCollectionSystem_Entrancesystem() {
		return (EReference) toolCollectionSystemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSecuritySystems() {
		return securitySystemsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSecuritySystems_Entrancesystem() {
		return (EReference) securitySystemsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getParkingSystems() {
		return parkingSystemsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getParkingSystems_Entrancesystem() {
		return (EReference) parkingSystemsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getGeographicalMaps() {
		return geographicalMapsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getGeographicalMaps_Name() {
		return (EAttribute) geographicalMapsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getGeographicalMaps_Vehiclelocation() {
		return (EReference) geographicalMapsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPort() {
		return portEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPort_Pin() {
		return (EAttribute) portEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPort_Type() {
		return (EAttribute) portEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPort_Name() {
		return (EAttribute) portEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInput() {
		return inputEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getInput_Sdata() {
		return (EAttribute) inputEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInput_Motionsensor() {
		return (EReference) inputEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getOutput() {
		return outputEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getOutput_MotorStatus() {
		return (EAttribute) outputEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getOutput_Controlgate() {
		return (EReference) outputEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFiltering() {
		return filteringEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getFiltering_Masksize() {
		return (EAttribute) filteringEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getTypeController() {
		return typeControllerEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getTypePort() {
		return typePortEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDataAcquisition() {
		return dataAcquisitionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDataAcquisition_Controlgate() {
		return (EReference) dataAcquisitionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getDataAcquisition_Type() {
		return (EAttribute) dataAcquisitionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDataAcquisition_Pc() {
		return (EReference) dataAcquisitionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getDataAcquisition_SensorData() {
		return (EAttribute) dataAcquisitionEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getDataAcquisition_MotorStatus() {
		return (EAttribute) dataAcquisitionEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDataAcquisition_Port() {
		return (EReference) dataAcquisitionEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDIP() {
		return dipEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getDIP_Name() {
		return (EAttribute) dipEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getDIP_VehicleNumber() {
		return (EAttribute) dipEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDIP_Pc() {
		return (EReference) dipEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getDIP_ComparisonResult() {
		return (EAttribute) dipEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRecords() {
		return recordsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getRecords_Name() {
		return (EAttribute) recordsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getRecords_Vnumber() {
		return (EAttribute) recordsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getRecords_Pc() {
		return (EReference) recordsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getRecords_VOwnerID() {
		return (EAttribute) recordsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getControlGate() {
		return controlGateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getControlGate_Name() {
		return (EAttribute) controlGateEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getControlGate_MotorStatus() {
		return (EAttribute) controlGateEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getEntranceSystem() {
		return entranceSystemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getEntranceSystem_Vehicle() {
		return (EReference) entranceSystemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getEntranceSystem_Motionsensor() {
		return (EReference) entranceSystemEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getEntranceSystem_Dataacquisition() {
		return (EReference) entranceSystemEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getEntranceSystem_Dip() {
		return (EReference) entranceSystemEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getEntranceSystem_Records() {
		return (EReference) entranceSystemEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getEntranceSystem_Vehiclelocation() {
		return (EReference) entranceSystemEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getEntranceSystem_Controlgate() {
		return (EReference) entranceSystemEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getEntranceSystem_Pc() {
		return (EReference) entranceSystemEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getVehicleLocation() {
		return vehicleLocationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getVehicleLocation_Name() {
		return (EAttribute) vehicleLocationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getVehicleLocation_Location() {
		return (EAttribute) vehicleLocationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCamera() {
		return cameraEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getCamera_Image() {
		return (EReference) cameraEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getImage() {
		return imageEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getImage_Imageacquisition() {
		return (EReference) imageEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getImage_Extn() {
		return (EAttribute) imageEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getImageAcquisition() {
		return imageAcquisitionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getImageAcquisition_Preprocessing() {
		return (EReference) imageAcquisitionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getImageAcquisition__ImRead() {
		return imageAcquisitionEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getImageAcquisition__Preview() {
		return imageAcquisitionEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getImageAcquisition__Snapshot() {
		return imageAcquisitionEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPreprocessing() {
		return preprocessingEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPreprocessing_Regionofinterest() {
		return (EReference) preprocessingEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getPreprocessing__Resize() {
		return preprocessingEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getPreprocessing__Rgb2gray() {
		return preprocessingEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getPreprocessing__ImShow() {
		return preprocessingEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getPreprocessing__ImBinrize() {
		return preprocessingEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getPreprocessing__Histeq() {
		return preprocessingEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCharacterRecognition() {
		return characterRecognitionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getCharacterRecognition_Templates() {
		return (EReference) characterRecognitionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCharacterRecognition__Imread() {
		return characterRecognitionEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCharacterRecognition__FindCorrelation() {
		return characterRecognitionEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTemplates() {
		return templatesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getTemplates_Characterrecognition() {
		return (EReference) templatesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTemplates_Binaryimage() {
		return (EAttribute) templatesEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTemplates_Imextn() {
		return (EAttribute) templatesEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRegionOfInterest() {
		return regionOfInterestEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getRegionOfInterest_Charactersegmentation() {
		return (EReference) regionOfInterestEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getRegionOfInterest__Edge() {
		return regionOfInterestEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getRegionOfInterest__Bwlabel() {
		return regionOfInterestEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getRegionOfInterest__Regionprops() {
		return regionOfInterestEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getRegionOfInterest__Imdialate() {
		return regionOfInterestEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getRegionOfInterest__Imerode() {
		return regionOfInterestEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSmoothingFilter() {
		return smoothingFilterEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getSmoothingFilter__Average() {
		return smoothingFilterEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSharpening() {
		return sharpeningEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCharacterSegmentation() {
		return characterSegmentationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getCharacterSegmentation_Characterrecognition() {
		return (EReference) characterSegmentationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCharacterSegmentation__Edgedetection() {
		return characterSegmentationEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCharacterSegmentation__Bwareaopen() {
		return characterSegmentationEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCharacterSegmentation__Imcrop() {
		return characterSegmentationEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCharacterSegmentation__Imresize() {
		return characterSegmentationEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Ms21paperFactory getMs21paperFactory() {
		return (Ms21paperFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		vehicleEClass = createEClass(VEHICLE);
		createEReference(vehicleEClass, VEHICLE__MOTIONSENSOR);
		createEAttribute(vehicleEClass, VEHICLE__NAME);
		createEAttribute(vehicleEClass, VEHICLE__VNUMBER);
		createEAttribute(vehicleEClass, VEHICLE__OWNER_ID);

		sensorEClass = createEClass(SENSOR);
		createEReference(sensorEClass, SENSOR__DATAACQUISITION);
		createEAttribute(sensorEClass, SENSOR__NAME);
		createEAttribute(sensorEClass, SENSOR__SENSOR_DATA);

		dataAcquisitionEClass = createEClass(DATA_ACQUISITION);
		createEReference(dataAcquisitionEClass, DATA_ACQUISITION__CONTROLGATE);
		createEAttribute(dataAcquisitionEClass, DATA_ACQUISITION__TYPE);
		createEReference(dataAcquisitionEClass, DATA_ACQUISITION__PC);
		createEAttribute(dataAcquisitionEClass, DATA_ACQUISITION__SENSOR_DATA);
		createEAttribute(dataAcquisitionEClass, DATA_ACQUISITION__MOTOR_STATUS);
		createEReference(dataAcquisitionEClass, DATA_ACQUISITION__PORT);

		dipEClass = createEClass(DIP);
		createEAttribute(dipEClass, DIP__NAME);
		createEAttribute(dipEClass, DIP__VEHICLE_NUMBER);
		createEReference(dipEClass, DIP__PC);
		createEAttribute(dipEClass, DIP__COMPARISON_RESULT);

		recordsEClass = createEClass(RECORDS);
		createEAttribute(recordsEClass, RECORDS__NAME);
		createEAttribute(recordsEClass, RECORDS__VNUMBER);
		createEReference(recordsEClass, RECORDS__PC);
		createEAttribute(recordsEClass, RECORDS__VOWNER_ID);

		controlGateEClass = createEClass(CONTROL_GATE);
		createEAttribute(controlGateEClass, CONTROL_GATE__NAME);
		createEAttribute(controlGateEClass, CONTROL_GATE__MOTOR_STATUS);

		entranceSystemEClass = createEClass(ENTRANCE_SYSTEM);
		createEReference(entranceSystemEClass, ENTRANCE_SYSTEM__VEHICLE);
		createEReference(entranceSystemEClass, ENTRANCE_SYSTEM__MOTIONSENSOR);
		createEReference(entranceSystemEClass, ENTRANCE_SYSTEM__DATAACQUISITION);
		createEReference(entranceSystemEClass, ENTRANCE_SYSTEM__DIP);
		createEReference(entranceSystemEClass, ENTRANCE_SYSTEM__RECORDS);
		createEReference(entranceSystemEClass, ENTRANCE_SYSTEM__VEHICLELOCATION);
		createEReference(entranceSystemEClass, ENTRANCE_SYSTEM__CONTROLGATE);
		createEReference(entranceSystemEClass, ENTRANCE_SYSTEM__PC);

		vehicleLocationEClass = createEClass(VEHICLE_LOCATION);
		createEAttribute(vehicleLocationEClass, VEHICLE_LOCATION__NAME);
		createEAttribute(vehicleLocationEClass, VEHICLE_LOCATION__LOCATION);

		cameraEClass = createEClass(CAMERA);
		createEReference(cameraEClass, CAMERA__IMAGE);

		imageEClass = createEClass(IMAGE);
		createEReference(imageEClass, IMAGE__IMAGEACQUISITION);
		createEAttribute(imageEClass, IMAGE__EXTN);

		imageAcquisitionEClass = createEClass(IMAGE_ACQUISITION);
		createEReference(imageAcquisitionEClass, IMAGE_ACQUISITION__PREPROCESSING);
		createEOperation(imageAcquisitionEClass, IMAGE_ACQUISITION___IM_READ);
		createEOperation(imageAcquisitionEClass, IMAGE_ACQUISITION___PREVIEW);
		createEOperation(imageAcquisitionEClass, IMAGE_ACQUISITION___SNAPSHOT);

		preprocessingEClass = createEClass(PREPROCESSING);
		createEReference(preprocessingEClass, PREPROCESSING__REGIONOFINTEREST);
		createEOperation(preprocessingEClass, PREPROCESSING___RESIZE);
		createEOperation(preprocessingEClass, PREPROCESSING___RGB2GRAY);
		createEOperation(preprocessingEClass, PREPROCESSING___IM_SHOW);
		createEOperation(preprocessingEClass, PREPROCESSING___IM_BINRIZE);
		createEOperation(preprocessingEClass, PREPROCESSING___HISTEQ);

		characterRecognitionEClass = createEClass(CHARACTER_RECOGNITION);
		createEReference(characterRecognitionEClass, CHARACTER_RECOGNITION__TEMPLATES);
		createEOperation(characterRecognitionEClass, CHARACTER_RECOGNITION___IMREAD);
		createEOperation(characterRecognitionEClass, CHARACTER_RECOGNITION___FIND_CORRELATION);

		templatesEClass = createEClass(TEMPLATES);
		createEReference(templatesEClass, TEMPLATES__CHARACTERRECOGNITION);
		createEAttribute(templatesEClass, TEMPLATES__BINARYIMAGE);
		createEAttribute(templatesEClass, TEMPLATES__IMEXTN);

		regionOfInterestEClass = createEClass(REGION_OF_INTEREST);
		createEReference(regionOfInterestEClass, REGION_OF_INTEREST__CHARACTERSEGMENTATION);
		createEOperation(regionOfInterestEClass, REGION_OF_INTEREST___EDGE);
		createEOperation(regionOfInterestEClass, REGION_OF_INTEREST___BWLABEL);
		createEOperation(regionOfInterestEClass, REGION_OF_INTEREST___REGIONPROPS);
		createEOperation(regionOfInterestEClass, REGION_OF_INTEREST___IMDIALATE);
		createEOperation(regionOfInterestEClass, REGION_OF_INTEREST___IMERODE);

		smoothingFilterEClass = createEClass(SMOOTHING_FILTER);
		createEOperation(smoothingFilterEClass, SMOOTHING_FILTER___AVERAGE);

		sharpeningEClass = createEClass(SHARPENING);

		characterSegmentationEClass = createEClass(CHARACTER_SEGMENTATION);
		createEReference(characterSegmentationEClass, CHARACTER_SEGMENTATION__CHARACTERRECOGNITION);
		createEOperation(characterSegmentationEClass, CHARACTER_SEGMENTATION___EDGEDETECTION);
		createEOperation(characterSegmentationEClass, CHARACTER_SEGMENTATION___BWAREAOPEN);
		createEOperation(characterSegmentationEClass, CHARACTER_SEGMENTATION___IMCROP);
		createEOperation(characterSegmentationEClass, CHARACTER_SEGMENTATION___IMRESIZE);

		motionSensorEClass = createEClass(MOTION_SENSOR);

		irSsensorEClass = createEClass(IR_SSENSOR);

		pcEClass = createEClass(PC);
		createEAttribute(pcEClass, PC__NAME);
		createEAttribute(pcEClass, PC__VNUMBER);
		createEReference(pcEClass, PC__DATAACQUISITION);
		createEReference(pcEClass, PC__RECORDS);
		createEReference(pcEClass, PC__DIP);
		createEReference(pcEClass, PC__VEHICLELOCATION);
		createEAttribute(pcEClass, PC__VEHICLE_RECORD);

		survilanceAndTrackingSytemsEClass = createEClass(SURVILANCE_AND_TRACKING_SYTEMS);
		createEReference(survilanceAndTrackingSytemsEClass, SURVILANCE_AND_TRACKING_SYTEMS__ENTRANCESYSTEM);

		toolCollectionSystemEClass = createEClass(TOOL_COLLECTION_SYSTEM);
		createEReference(toolCollectionSystemEClass, TOOL_COLLECTION_SYSTEM__ENTRANCESYSTEM);

		securitySystemsEClass = createEClass(SECURITY_SYSTEMS);
		createEReference(securitySystemsEClass, SECURITY_SYSTEMS__ENTRANCESYSTEM);

		parkingSystemsEClass = createEClass(PARKING_SYSTEMS);
		createEReference(parkingSystemsEClass, PARKING_SYSTEMS__ENTRANCESYSTEM);

		geographicalMapsEClass = createEClass(GEOGRAPHICAL_MAPS);
		createEAttribute(geographicalMapsEClass, GEOGRAPHICAL_MAPS__NAME);
		createEReference(geographicalMapsEClass, GEOGRAPHICAL_MAPS__VEHICLELOCATION);

		portEClass = createEClass(PORT);
		createEAttribute(portEClass, PORT__PIN);
		createEAttribute(portEClass, PORT__TYPE);
		createEAttribute(portEClass, PORT__NAME);

		inputEClass = createEClass(INPUT);
		createEAttribute(inputEClass, INPUT__SDATA);
		createEReference(inputEClass, INPUT__MOTIONSENSOR);

		outputEClass = createEClass(OUTPUT);
		createEAttribute(outputEClass, OUTPUT__MOTOR_STATUS);
		createEReference(outputEClass, OUTPUT__CONTROLGATE);

		filteringEClass = createEClass(FILTERING);
		createEAttribute(filteringEClass, FILTERING__MASKSIZE);

		// Create enums
		typeControllerEEnum = createEEnum(TYPE_CONTROLLER);
		typePortEEnum = createEEnum(TYPE_PORT);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		XMLTypePackage theXMLTypePackage = (XMLTypePackage) EPackage.Registry.INSTANCE
				.getEPackage(XMLTypePackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		cameraEClass.getESuperTypes().add(this.getDIP());
		imageEClass.getESuperTypes().add(this.getDIP());
		imageAcquisitionEClass.getESuperTypes().add(this.getDIP());
		preprocessingEClass.getESuperTypes().add(this.getDIP());
		characterRecognitionEClass.getESuperTypes().add(this.getDIP());
		templatesEClass.getESuperTypes().add(this.getDIP());
		regionOfInterestEClass.getESuperTypes().add(this.getDIP());
		smoothingFilterEClass.getESuperTypes().add(this.getFiltering());
		sharpeningEClass.getESuperTypes().add(this.getFiltering());
		characterSegmentationEClass.getESuperTypes().add(this.getDIP());
		motionSensorEClass.getESuperTypes().add(this.getSensor());
		irSsensorEClass.getESuperTypes().add(this.getSensor());
		inputEClass.getESuperTypes().add(this.getPort());
		outputEClass.getESuperTypes().add(this.getPort());
		filteringEClass.getESuperTypes().add(this.getPreprocessing());

		// Initialize classes, features, and operations; add parameters
		initEClass(vehicleEClass, Vehicle.class, "Vehicle", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getVehicle_Motionsensor(), this.getSensor(), null, "motionsensor", null, 0, 3, Vehicle.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVehicle_Name(), ecorePackage.getEString(), "name", null, 0, 1, Vehicle.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVehicle_Vnumber(), ecorePackage.getEString(), "vnumber", null, 0, 1, Vehicle.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVehicle_OwnerID(), ecorePackage.getEString(), "OwnerID", null, 0, 1, Vehicle.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(sensorEClass, Sensor.class, "Sensor", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSensor_Dataacquisition(), this.getDataAcquisition(), null, "dataacquisition", null, 0, 3,
				Sensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSensor_Name(), ecorePackage.getEString(), "name", null, 0, 1, Sensor.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSensor_SensorData(), ecorePackage.getEBoolean(), "SensorData", null, 0, 1, Sensor.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(dataAcquisitionEClass, DataAcquisition.class, "DataAcquisition", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDataAcquisition_Controlgate(), this.getControlGate(), null, "controlgate", null, 0, 1,
				DataAcquisition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDataAcquisition_Type(), ecorePackage.getEString(), "Type", "ArduinoUNO", 0, 1,
				DataAcquisition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getDataAcquisition_Pc(), this.getPC(), this.getPC_Dataacquisition(), "pc", null, 0, 1,
				DataAcquisition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDataAcquisition_SensorData(), ecorePackage.getEBooleanObject(), "SensorData", null, 0, 1,
				DataAcquisition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getDataAcquisition_MotorStatus(), ecorePackage.getEBoolean(), "MotorStatus", null, 0, 1,
				DataAcquisition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getDataAcquisition_Port(), this.getPort(), null, "port", null, 0, -1, DataAcquisition.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(dipEClass, ms21paper.DIP.class, "DIP", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDIP_Name(), ecorePackage.getEString(), "name", null, 0, 1, ms21paper.DIP.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDIP_VehicleNumber(), ecorePackage.getEString(), "VehicleNumber", null, 0, 1,
				ms21paper.DIP.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getDIP_Pc(), this.getPC(), this.getPC_Dip(), "pc", null, 0, 1, ms21paper.DIP.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDIP_ComparisonResult(), theXMLTypePackage.getBoolean(), "ComparisonResult", null, 0, 1,
				ms21paper.DIP.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(recordsEClass, Records.class, "Records", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRecords_Name(), ecorePackage.getEString(), "name", null, 0, 1, Records.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRecords_Vnumber(), ecorePackage.getEString(), "vnumber", null, 0, 1, Records.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRecords_Pc(), this.getPC(), this.getPC_Records(), "pc", null, 0, 1, Records.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRecords_VOwnerID(), ecorePackage.getEShort(), "VOwnerID", null, 0, 1, Records.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(controlGateEClass, ControlGate.class, "ControlGate", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getControlGate_Name(), ecorePackage.getEString(), "name", null, 0, 1, ControlGate.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getControlGate_MotorStatus(), ecorePackage.getEBoolean(), "MotorStatus", null, 0, 1,
				ControlGate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(entranceSystemEClass, EntranceSystem.class, "EntranceSystem", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getEntranceSystem_Vehicle(), this.getVehicle(), null, "vehicle", null, 0, 1,
				EntranceSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntranceSystem_Motionsensor(), this.getSensor(), null, "motionsensor", null, 0, -1,
				EntranceSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntranceSystem_Dataacquisition(), this.getDataAcquisition(), null, "dataacquisition", null, 0,
				-1, EntranceSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntranceSystem_Dip(), this.getDIP(), null, "dip", null, 0, -1, EntranceSystem.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntranceSystem_Records(), this.getRecords(), null, "records", null, 0, -1,
				EntranceSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntranceSystem_Vehiclelocation(), this.getVehicleLocation(), null, "vehiclelocation", null, 0,
				1, EntranceSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntranceSystem_Controlgate(), this.getControlGate(), null, "controlgate", null, 0, 1,
				EntranceSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntranceSystem_Pc(), this.getPC(), null, "pc", null, 0, -1, EntranceSystem.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(vehicleLocationEClass, VehicleLocation.class, "VehicleLocation", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getVehicleLocation_Name(), ecorePackage.getEString(), "name", null, 0, 1, VehicleLocation.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVehicleLocation_Location(), ecorePackage.getEString(), "Location", null, 0, 1,
				VehicleLocation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(cameraEClass, Camera.class, "Camera", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCamera_Image(), this.getImage(), null, "image", null, 0, -1, Camera.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(imageEClass, Image.class, "Image", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getImage_Imageacquisition(), this.getImageAcquisition(), null, "imageacquisition", null, 0, -1,
				Image.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getImage_Extn(), ecorePackage.getEString(), "extn", null, 0, 1, Image.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(imageAcquisitionEClass, ImageAcquisition.class, "ImageAcquisition", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getImageAcquisition_Preprocessing(), this.getPreprocessing(), null, "preprocessing", null, 0, -1,
				ImageAcquisition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getImageAcquisition__ImRead(), null, "ImRead", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getImageAcquisition__Preview(), null, "Preview", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getImageAcquisition__Snapshot(), null, "Snapshot", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(preprocessingEClass, Preprocessing.class, "Preprocessing", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPreprocessing_Regionofinterest(), this.getRegionOfInterest(), null, "regionofinterest", null,
				0, -1, Preprocessing.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getPreprocessing__Resize(), null, "Resize", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getPreprocessing__Rgb2gray(), null, "rgb2gray", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getPreprocessing__ImShow(), null, "ImShow", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getPreprocessing__ImBinrize(), null, "ImBinrize", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getPreprocessing__Histeq(), null, "histeq", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(characterRecognitionEClass, CharacterRecognition.class, "CharacterRecognition", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCharacterRecognition_Templates(), this.getTemplates(),
				this.getTemplates_Characterrecognition(), "templates", null, 0, -1, CharacterRecognition.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getCharacterRecognition__Imread(), null, "imread", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getCharacterRecognition__FindCorrelation(), null, "FindCorrelation", 0, 1, IS_UNIQUE,
				IS_ORDERED);

		initEClass(templatesEClass, Templates.class, "Templates", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTemplates_Characterrecognition(), this.getCharacterRecognition(),
				this.getCharacterRecognition_Templates(), "characterrecognition", null, 0, -1, Templates.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTemplates_Binaryimage(), ecorePackage.getEString(), "binaryimage", null, 0, 1,
				Templates.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getTemplates_Imextn(), ecorePackage.getEString(), "imextn", null, 0, 1, Templates.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(regionOfInterestEClass, RegionOfInterest.class, "RegionOfInterest", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRegionOfInterest_Charactersegmentation(), this.getCharacterSegmentation(), null,
				"charactersegmentation", null, 0, -1, RegionOfInterest.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getRegionOfInterest__Edge(), null, "edge", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getRegionOfInterest__Bwlabel(), null, "bwlabel", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getRegionOfInterest__Regionprops(), null, "regionprops", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getRegionOfInterest__Imdialate(), null, "imdialate", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getRegionOfInterest__Imerode(), null, "imerode", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(smoothingFilterEClass, SmoothingFilter.class, "SmoothingFilter", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEOperation(getSmoothingFilter__Average(), null, "Average", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(sharpeningEClass, Sharpening.class, "Sharpening", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(characterSegmentationEClass, CharacterSegmentation.class, "CharacterSegmentation", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCharacterSegmentation_Characterrecognition(), this.getCharacterRecognition(), null,
				"characterrecognition", null, 0, -1, CharacterSegmentation.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getCharacterSegmentation__Edgedetection(), null, "edgedetection", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getCharacterSegmentation__Bwareaopen(), null, "bwareaopen", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getCharacterSegmentation__Imcrop(), null, "imcrop", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getCharacterSegmentation__Imresize(), null, "imresize", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(motionSensorEClass, MotionSensor.class, "MotionSensor", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(irSsensorEClass, IRSsensor.class, "IRSsensor", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(pcEClass, ms21paper.PC.class, "PC", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPC_Name(), ecorePackage.getEString(), "name", null, 0, 1, ms21paper.PC.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPC_Vnumber(), ecorePackage.getEString(), "vnumber", null, 0, 1, ms21paper.PC.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPC_Dataacquisition(), this.getDataAcquisition(), this.getDataAcquisition_Pc(),
				"dataacquisition", null, 0, -1, ms21paper.PC.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPC_Records(), this.getRecords(), this.getRecords_Pc(), "records", null, 0, -1,
				ms21paper.PC.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPC_Dip(), this.getDIP(), this.getDIP_Pc(), "dip", null, 0, 2, ms21paper.PC.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPC_Vehiclelocation(), this.getVehicleLocation(), null, "vehiclelocation", null, 0, 1,
				ms21paper.PC.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPC_VehicleRecord(), ecorePackage.getEString(), "VehicleRecord", null, 0, 1,
				ms21paper.PC.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(survilanceAndTrackingSytemsEClass, SurvilanceAndTrackingSytems.class, "SurvilanceAndTrackingSytems",
				!IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSurvilanceAndTrackingSytems_Entrancesystem(), this.getEntranceSystem(), null,
				"entrancesystem", null, 0, 1, SurvilanceAndTrackingSytems.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(toolCollectionSystemEClass, ToolCollectionSystem.class, "ToolCollectionSystem", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getToolCollectionSystem_Entrancesystem(), this.getEntranceSystem(), null, "entrancesystem", null,
				0, 1, ToolCollectionSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(securitySystemsEClass, SecuritySystems.class, "SecuritySystems", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSecuritySystems_Entrancesystem(), this.getEntranceSystem(), null, "entrancesystem", null, 0,
				1, SecuritySystems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(parkingSystemsEClass, ParkingSystems.class, "ParkingSystems", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getParkingSystems_Entrancesystem(), this.getEntranceSystem(), null, "entrancesystem", null, 0, 1,
				ParkingSystems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(geographicalMapsEClass, GeographicalMaps.class, "GeographicalMaps", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getGeographicalMaps_Name(), ecorePackage.getEString(), "name", null, 0, 1,
				GeographicalMaps.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getGeographicalMaps_Vehiclelocation(), this.getVehicleLocation(), null, "vehiclelocation", null,
				0, 1, GeographicalMaps.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(portEClass, Port.class, "Port", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPort_Pin(), ecorePackage.getEString(), "pin", "", 0, 1, Port.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPort_Type(), this.getTypePort(), "Type", "Digital", 0, 1, Port.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPort_Name(), ecorePackage.getEString(), "name", null, 0, 1, Port.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(inputEClass, Input.class, "Input", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getInput_Sdata(), ecorePackage.getEBoolean(), "Sdata", null, 0, 1, Input.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInput_Motionsensor(), this.getSensor(), null, "motionsensor", null, 0, 2, Input.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(outputEClass, Output.class, "Output", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getOutput_MotorStatus(), ecorePackage.getEBoolean(), "MotorStatus", null, 0, 1, Output.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getOutput_Controlgate(), this.getControlGate(), null, "controlgate", null, 0, 1, Output.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(filteringEClass, Filtering.class, "Filtering", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFiltering_Masksize(), theXMLTypePackage.getFloat(), "masksize", null, 0, 1, Filtering.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(typeControllerEEnum, TypeController.class, "TypeController");
		addEEnumLiteral(typeControllerEEnum, TypeController.ARDUINO_UNO);
		addEEnumLiteral(typeControllerEEnum, TypeController.ARDUINO_MEGA);
		addEEnumLiteral(typeControllerEEnum, TypeController.RASPBERRI_PI);
		addEEnumLiteral(typeControllerEEnum, TypeController.OTHER);

		initEEnum(typePortEEnum, TypePort.class, "TypePort");
		addEEnumLiteral(typePortEEnum, TypePort.DIGITAL);
		addEEnumLiteral(typePortEEnum, TypePort.ANALOG);

		// Create resource
		createResource(eNS_URI);
	}

} //Ms21paperPackageImpl
