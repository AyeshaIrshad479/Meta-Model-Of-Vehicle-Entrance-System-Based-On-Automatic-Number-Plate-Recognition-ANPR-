/**
 */
package ms21paper.impl;

import ms21paper.ControlGate;
import ms21paper.Ms21paperPackage;
import ms21paper.Output;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Output</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.OutputImpl#isMotorStatus <em>Motor Status</em>}</li>
 *   <li>{@link ms21paper.impl.OutputImpl#getControlgate <em>Controlgate</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OutputImpl extends PortImpl implements Output {
	/**
	 * The default value of the '{@link #isMotorStatus() <em>Motor Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isMotorStatus()
	 * @generated
	 * @ordered
	 */
	protected static final boolean MOTOR_STATUS_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isMotorStatus() <em>Motor Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isMotorStatus()
	 * @generated
	 * @ordered
	 */
	protected boolean motorStatus = MOTOR_STATUS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getControlgate() <em>Controlgate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getControlgate()
	 * @generated
	 * @ordered
	 */
	protected ControlGate controlgate;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OutputImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.OUTPUT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isMotorStatus() {
		return motorStatus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setMotorStatus(boolean newMotorStatus) {
		boolean oldMotorStatus = motorStatus;
		motorStatus = newMotorStatus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.OUTPUT__MOTOR_STATUS, oldMotorStatus,
					motorStatus));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ControlGate getControlgate() {
		if (controlgate != null && controlgate.eIsProxy()) {
			InternalEObject oldControlgate = (InternalEObject) controlgate;
			controlgate = (ControlGate) eResolveProxy(oldControlgate);
			if (controlgate != oldControlgate) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Ms21paperPackage.OUTPUT__CONTROLGATE,
							oldControlgate, controlgate));
			}
		}
		return controlgate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ControlGate basicGetControlgate() {
		return controlgate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setControlgate(ControlGate newControlgate) {
		ControlGate oldControlgate = controlgate;
		controlgate = newControlgate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.OUTPUT__CONTROLGATE, oldControlgate,
					controlgate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.OUTPUT__MOTOR_STATUS:
			return isMotorStatus();
		case Ms21paperPackage.OUTPUT__CONTROLGATE:
			if (resolve)
				return getControlgate();
			return basicGetControlgate();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.OUTPUT__MOTOR_STATUS:
			setMotorStatus((Boolean) newValue);
			return;
		case Ms21paperPackage.OUTPUT__CONTROLGATE:
			setControlgate((ControlGate) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.OUTPUT__MOTOR_STATUS:
			setMotorStatus(MOTOR_STATUS_EDEFAULT);
			return;
		case Ms21paperPackage.OUTPUT__CONTROLGATE:
			setControlgate((ControlGate) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.OUTPUT__MOTOR_STATUS:
			return motorStatus != MOTOR_STATUS_EDEFAULT;
		case Ms21paperPackage.OUTPUT__CONTROLGATE:
			return controlgate != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (MotorStatus: ");
		result.append(motorStatus);
		result.append(')');
		return result.toString();
	}

} //OutputImpl
