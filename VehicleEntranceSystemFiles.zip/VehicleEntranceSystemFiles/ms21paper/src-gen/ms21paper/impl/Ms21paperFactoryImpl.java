/**
 */
package ms21paper.impl;

import ms21paper.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Ms21paperFactoryImpl extends EFactoryImpl implements Ms21paperFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Ms21paperFactory init() {
		try {
			Ms21paperFactory theMs21paperFactory = (Ms21paperFactory) EPackage.Registry.INSTANCE
					.getEFactory(Ms21paperPackage.eNS_URI);
			if (theMs21paperFactory != null) {
				return theMs21paperFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new Ms21paperFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ms21paperFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case Ms21paperPackage.VEHICLE:
			return createVehicle();
		case Ms21paperPackage.DATA_ACQUISITION:
			return createDataAcquisition();
		case Ms21paperPackage.RECORDS:
			return createRecords();
		case Ms21paperPackage.CONTROL_GATE:
			return createControlGate();
		case Ms21paperPackage.ENTRANCE_SYSTEM:
			return createEntranceSystem();
		case Ms21paperPackage.VEHICLE_LOCATION:
			return createVehicleLocation();
		case Ms21paperPackage.CAMERA:
			return createCamera();
		case Ms21paperPackage.IMAGE:
			return createImage();
		case Ms21paperPackage.IMAGE_ACQUISITION:
			return createImageAcquisition();
		case Ms21paperPackage.PREPROCESSING:
			return createPreprocessing();
		case Ms21paperPackage.CHARACTER_RECOGNITION:
			return createCharacterRecognition();
		case Ms21paperPackage.TEMPLATES:
			return createTemplates();
		case Ms21paperPackage.REGION_OF_INTEREST:
			return createRegionOfInterest();
		case Ms21paperPackage.SMOOTHING_FILTER:
			return createSmoothingFilter();
		case Ms21paperPackage.SHARPENING:
			return createSharpening();
		case Ms21paperPackage.CHARACTER_SEGMENTATION:
			return createCharacterSegmentation();
		case Ms21paperPackage.MOTION_SENSOR:
			return createMotionSensor();
		case Ms21paperPackage.IR_SSENSOR:
			return createIRSsensor();
		case Ms21paperPackage.PC:
			return createPC();
		case Ms21paperPackage.SURVILANCE_AND_TRACKING_SYTEMS:
			return createSurvilanceAndTrackingSytems();
		case Ms21paperPackage.TOOL_COLLECTION_SYSTEM:
			return createToolCollectionSystem();
		case Ms21paperPackage.SECURITY_SYSTEMS:
			return createSecuritySystems();
		case Ms21paperPackage.PARKING_SYSTEMS:
			return createParkingSystems();
		case Ms21paperPackage.GEOGRAPHICAL_MAPS:
			return createGeographicalMaps();
		case Ms21paperPackage.INPUT:
			return createInput();
		case Ms21paperPackage.OUTPUT:
			return createOutput();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case Ms21paperPackage.TYPE_CONTROLLER:
			return createTypeControllerFromString(eDataType, initialValue);
		case Ms21paperPackage.TYPE_PORT:
			return createTypePortFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case Ms21paperPackage.TYPE_CONTROLLER:
			return convertTypeControllerToString(eDataType, instanceValue);
		case Ms21paperPackage.TYPE_PORT:
			return convertTypePortToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Vehicle createVehicle() {
		VehicleImpl vehicle = new VehicleImpl();
		return vehicle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MotionSensor createMotionSensor() {
		MotionSensorImpl motionSensor = new MotionSensorImpl();
		return motionSensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public IRSsensor createIRSsensor() {
		IRSsensorImpl irSsensor = new IRSsensorImpl();
		return irSsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PC createPC() {
		PCImpl pc = new PCImpl();
		return pc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SurvilanceAndTrackingSytems createSurvilanceAndTrackingSytems() {
		SurvilanceAndTrackingSytemsImpl survilanceAndTrackingSytems = new SurvilanceAndTrackingSytemsImpl();
		return survilanceAndTrackingSytems;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ToolCollectionSystem createToolCollectionSystem() {
		ToolCollectionSystemImpl toolCollectionSystem = new ToolCollectionSystemImpl();
		return toolCollectionSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SecuritySystems createSecuritySystems() {
		SecuritySystemsImpl securitySystems = new SecuritySystemsImpl();
		return securitySystems;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ParkingSystems createParkingSystems() {
		ParkingSystemsImpl parkingSystems = new ParkingSystemsImpl();
		return parkingSystems;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public GeographicalMaps createGeographicalMaps() {
		GeographicalMapsImpl geographicalMaps = new GeographicalMapsImpl();
		return geographicalMaps;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Input createInput() {
		InputImpl input = new InputImpl();
		return input;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Output createOutput() {
		OutputImpl output = new OutputImpl();
		return output;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TypeController createTypeControllerFromString(EDataType eDataType, String initialValue) {
		TypeController result = TypeController.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTypeControllerToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TypePort createTypePortFromString(EDataType eDataType, String initialValue) {
		TypePort result = TypePort.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTypePortToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DataAcquisition createDataAcquisition() {
		DataAcquisitionImpl dataAcquisition = new DataAcquisitionImpl();
		return dataAcquisition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Records createRecords() {
		RecordsImpl records = new RecordsImpl();
		return records;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ControlGate createControlGate() {
		ControlGateImpl controlGate = new ControlGateImpl();
		return controlGate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EntranceSystem createEntranceSystem() {
		EntranceSystemImpl entranceSystem = new EntranceSystemImpl();
		return entranceSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VehicleLocation createVehicleLocation() {
		VehicleLocationImpl vehicleLocation = new VehicleLocationImpl();
		return vehicleLocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Camera createCamera() {
		CameraImpl camera = new CameraImpl();
		return camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Image createImage() {
		ImageImpl image = new ImageImpl();
		return image;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ImageAcquisition createImageAcquisition() {
		ImageAcquisitionImpl imageAcquisition = new ImageAcquisitionImpl();
		return imageAcquisition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Preprocessing createPreprocessing() {
		PreprocessingImpl preprocessing = new PreprocessingImpl();
		return preprocessing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CharacterRecognition createCharacterRecognition() {
		CharacterRecognitionImpl characterRecognition = new CharacterRecognitionImpl();
		return characterRecognition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Templates createTemplates() {
		TemplatesImpl templates = new TemplatesImpl();
		return templates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RegionOfInterest createRegionOfInterest() {
		RegionOfInterestImpl regionOfInterest = new RegionOfInterestImpl();
		return regionOfInterest;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SmoothingFilter createSmoothingFilter() {
		SmoothingFilterImpl smoothingFilter = new SmoothingFilterImpl();
		return smoothingFilter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Sharpening createSharpening() {
		SharpeningImpl sharpening = new SharpeningImpl();
		return sharpening;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CharacterSegmentation createCharacterSegmentation() {
		CharacterSegmentationImpl characterSegmentation = new CharacterSegmentationImpl();
		return characterSegmentation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Ms21paperPackage getMs21paperPackage() {
		return (Ms21paperPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static Ms21paperPackage getPackage() {
		return Ms21paperPackage.eINSTANCE;
	}

} //Ms21paperFactoryImpl
