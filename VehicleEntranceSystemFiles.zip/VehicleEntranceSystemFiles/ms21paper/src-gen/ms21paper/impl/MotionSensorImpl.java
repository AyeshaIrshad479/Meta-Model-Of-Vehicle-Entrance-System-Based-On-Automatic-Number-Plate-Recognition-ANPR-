/**
 */
package ms21paper.impl;

import ms21paper.MotionSensor;
import ms21paper.Ms21paperPackage;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Motion Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class MotionSensorImpl extends SensorImpl implements MotionSensor {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MotionSensorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.MOTION_SENSOR;
	}

} //MotionSensorImpl
