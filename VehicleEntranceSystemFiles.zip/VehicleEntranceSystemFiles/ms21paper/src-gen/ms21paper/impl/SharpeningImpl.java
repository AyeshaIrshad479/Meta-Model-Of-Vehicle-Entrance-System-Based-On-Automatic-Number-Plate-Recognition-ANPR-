/**
 */
package ms21paper.impl;

import ms21paper.Ms21paperPackage;
import ms21paper.Sharpening;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sharpening</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SharpeningImpl extends FilteringImpl implements Sharpening {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SharpeningImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.SHARPENING;
	}

} //SharpeningImpl
