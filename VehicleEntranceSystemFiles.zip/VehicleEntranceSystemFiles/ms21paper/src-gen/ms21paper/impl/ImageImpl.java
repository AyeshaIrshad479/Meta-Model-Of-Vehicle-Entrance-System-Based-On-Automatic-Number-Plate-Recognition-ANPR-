/**
 */
package ms21paper.impl;

import java.util.Collection;
import ms21paper.Image;
import ms21paper.ImageAcquisition;
import ms21paper.Ms21paperPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Image</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.ImageImpl#getImageacquisition <em>Imageacquisition</em>}</li>
 *   <li>{@link ms21paper.impl.ImageImpl#getExtn <em>Extn</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ImageImpl extends DIPImpl implements Image {
	/**
	 * The cached value of the '{@link #getImageacquisition() <em>Imageacquisition</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImageacquisition()
	 * @generated
	 * @ordered
	 */
	protected EList<ImageAcquisition> imageacquisition;

	/**
	 * The default value of the '{@link #getExtn() <em>Extn</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExtn()
	 * @generated
	 * @ordered
	 */
	protected static final String EXTN_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getExtn() <em>Extn</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExtn()
	 * @generated
	 * @ordered
	 */
	protected String extn = EXTN_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ImageImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.IMAGE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<ImageAcquisition> getImageacquisition() {
		if (imageacquisition == null) {
			imageacquisition = new EObjectResolvingEList<ImageAcquisition>(ImageAcquisition.class, this,
					Ms21paperPackage.IMAGE__IMAGEACQUISITION);
		}
		return imageacquisition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getExtn() {
		return extn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setExtn(String newExtn) {
		String oldExtn = extn;
		extn = newExtn;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.IMAGE__EXTN, oldExtn, extn));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.IMAGE__IMAGEACQUISITION:
			return getImageacquisition();
		case Ms21paperPackage.IMAGE__EXTN:
			return getExtn();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.IMAGE__IMAGEACQUISITION:
			getImageacquisition().clear();
			getImageacquisition().addAll((Collection<? extends ImageAcquisition>) newValue);
			return;
		case Ms21paperPackage.IMAGE__EXTN:
			setExtn((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.IMAGE__IMAGEACQUISITION:
			getImageacquisition().clear();
			return;
		case Ms21paperPackage.IMAGE__EXTN:
			setExtn(EXTN_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.IMAGE__IMAGEACQUISITION:
			return imageacquisition != null && !imageacquisition.isEmpty();
		case Ms21paperPackage.IMAGE__EXTN:
			return EXTN_EDEFAULT == null ? extn != null : !EXTN_EDEFAULT.equals(extn);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (extn: ");
		result.append(extn);
		result.append(')');
		return result.toString();
	}

} //ImageImpl
