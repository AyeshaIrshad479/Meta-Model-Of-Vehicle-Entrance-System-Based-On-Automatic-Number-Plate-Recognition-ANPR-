/**
 */
package ms21paper.impl;

import ms21paper.DIP;
import ms21paper.Ms21paperPackage;
import ms21paper.PC;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>DIP</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.DIPImpl#getName <em>Name</em>}</li>
 *   <li>{@link ms21paper.impl.DIPImpl#getVehicleNumber <em>Vehicle Number</em>}</li>
 *   <li>{@link ms21paper.impl.DIPImpl#getPc <em>Pc</em>}</li>
 *   <li>{@link ms21paper.impl.DIPImpl#isComparisonResult <em>Comparison Result</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class DIPImpl extends MinimalEObjectImpl.Container implements DIP {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getVehicleNumber() <em>Vehicle Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVehicleNumber()
	 * @generated
	 * @ordered
	 */
	protected static final String VEHICLE_NUMBER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getVehicleNumber() <em>Vehicle Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVehicleNumber()
	 * @generated
	 * @ordered
	 */
	protected String vehicleNumber = VEHICLE_NUMBER_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPc() <em>Pc</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPc()
	 * @generated
	 * @ordered
	 */
	protected PC pc;

	/**
	 * The default value of the '{@link #isComparisonResult() <em>Comparison Result</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isComparisonResult()
	 * @generated
	 * @ordered
	 */
	protected static final boolean COMPARISON_RESULT_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isComparisonResult() <em>Comparison Result</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isComparisonResult()
	 * @generated
	 * @ordered
	 */
	protected boolean comparisonResult = COMPARISON_RESULT_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DIPImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.DIP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.DIP__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getVehicleNumber() {
		return vehicleNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVehicleNumber(String newVehicleNumber) {
		String oldVehicleNumber = vehicleNumber;
		vehicleNumber = newVehicleNumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.DIP__VEHICLE_NUMBER,
					oldVehicleNumber, vehicleNumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PC getPc() {
		if (pc != null && pc.eIsProxy()) {
			InternalEObject oldPc = (InternalEObject) pc;
			pc = (PC) eResolveProxy(oldPc);
			if (pc != oldPc) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Ms21paperPackage.DIP__PC, oldPc, pc));
			}
		}
		return pc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PC basicGetPc() {
		return pc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPc(PC newPc, NotificationChain msgs) {
		PC oldPc = pc;
		pc = newPc;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Ms21paperPackage.DIP__PC,
					oldPc, newPc);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPc(PC newPc) {
		if (newPc != pc) {
			NotificationChain msgs = null;
			if (pc != null)
				msgs = ((InternalEObject) pc).eInverseRemove(this, Ms21paperPackage.PC__DIP, PC.class, msgs);
			if (newPc != null)
				msgs = ((InternalEObject) newPc).eInverseAdd(this, Ms21paperPackage.PC__DIP, PC.class, msgs);
			msgs = basicSetPc(newPc, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.DIP__PC, newPc, newPc));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isComparisonResult() {
		return comparisonResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setComparisonResult(boolean newComparisonResult) {
		boolean oldComparisonResult = comparisonResult;
		comparisonResult = newComparisonResult;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.DIP__COMPARISON_RESULT,
					oldComparisonResult, comparisonResult));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Ms21paperPackage.DIP__PC:
			if (pc != null)
				msgs = ((InternalEObject) pc).eInverseRemove(this, Ms21paperPackage.PC__DIP, PC.class, msgs);
			return basicSetPc((PC) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Ms21paperPackage.DIP__PC:
			return basicSetPc(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.DIP__NAME:
			return getName();
		case Ms21paperPackage.DIP__VEHICLE_NUMBER:
			return getVehicleNumber();
		case Ms21paperPackage.DIP__PC:
			if (resolve)
				return getPc();
			return basicGetPc();
		case Ms21paperPackage.DIP__COMPARISON_RESULT:
			return isComparisonResult();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.DIP__NAME:
			setName((String) newValue);
			return;
		case Ms21paperPackage.DIP__VEHICLE_NUMBER:
			setVehicleNumber((String) newValue);
			return;
		case Ms21paperPackage.DIP__PC:
			setPc((PC) newValue);
			return;
		case Ms21paperPackage.DIP__COMPARISON_RESULT:
			setComparisonResult((Boolean) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.DIP__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Ms21paperPackage.DIP__VEHICLE_NUMBER:
			setVehicleNumber(VEHICLE_NUMBER_EDEFAULT);
			return;
		case Ms21paperPackage.DIP__PC:
			setPc((PC) null);
			return;
		case Ms21paperPackage.DIP__COMPARISON_RESULT:
			setComparisonResult(COMPARISON_RESULT_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.DIP__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Ms21paperPackage.DIP__VEHICLE_NUMBER:
			return VEHICLE_NUMBER_EDEFAULT == null ? vehicleNumber != null
					: !VEHICLE_NUMBER_EDEFAULT.equals(vehicleNumber);
		case Ms21paperPackage.DIP__PC:
			return pc != null;
		case Ms21paperPackage.DIP__COMPARISON_RESULT:
			return comparisonResult != COMPARISON_RESULT_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", VehicleNumber: ");
		result.append(vehicleNumber);
		result.append(", ComparisonResult: ");
		result.append(comparisonResult);
		result.append(')');
		return result.toString();
	}

} //DIPImpl
