/**
 */
package ms21paper.impl;

import ms21paper.EntranceSystem;
import ms21paper.Ms21paperPackage;
import ms21paper.SurvilanceAndTrackingSytems;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Survilance And Tracking Sytems</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.SurvilanceAndTrackingSytemsImpl#getEntrancesystem <em>Entrancesystem</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SurvilanceAndTrackingSytemsImpl extends MinimalEObjectImpl.Container
		implements SurvilanceAndTrackingSytems {
	/**
	 * The cached value of the '{@link #getEntrancesystem() <em>Entrancesystem</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEntrancesystem()
	 * @generated
	 * @ordered
	 */
	protected EntranceSystem entrancesystem;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SurvilanceAndTrackingSytemsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.SURVILANCE_AND_TRACKING_SYTEMS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EntranceSystem getEntrancesystem() {
		return entrancesystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetEntrancesystem(EntranceSystem newEntrancesystem, NotificationChain msgs) {
		EntranceSystem oldEntrancesystem = entrancesystem;
		entrancesystem = newEntrancesystem;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Ms21paperPackage.SURVILANCE_AND_TRACKING_SYTEMS__ENTRANCESYSTEM, oldEntrancesystem,
					newEntrancesystem);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setEntrancesystem(EntranceSystem newEntrancesystem) {
		if (newEntrancesystem != entrancesystem) {
			NotificationChain msgs = null;
			if (entrancesystem != null)
				msgs = ((InternalEObject) entrancesystem).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - Ms21paperPackage.SURVILANCE_AND_TRACKING_SYTEMS__ENTRANCESYSTEM, null,
						msgs);
			if (newEntrancesystem != null)
				msgs = ((InternalEObject) newEntrancesystem).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - Ms21paperPackage.SURVILANCE_AND_TRACKING_SYTEMS__ENTRANCESYSTEM, null,
						msgs);
			msgs = basicSetEntrancesystem(newEntrancesystem, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Ms21paperPackage.SURVILANCE_AND_TRACKING_SYTEMS__ENTRANCESYSTEM, newEntrancesystem,
					newEntrancesystem));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Ms21paperPackage.SURVILANCE_AND_TRACKING_SYTEMS__ENTRANCESYSTEM:
			return basicSetEntrancesystem(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.SURVILANCE_AND_TRACKING_SYTEMS__ENTRANCESYSTEM:
			return getEntrancesystem();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.SURVILANCE_AND_TRACKING_SYTEMS__ENTRANCESYSTEM:
			setEntrancesystem((EntranceSystem) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.SURVILANCE_AND_TRACKING_SYTEMS__ENTRANCESYSTEM:
			setEntrancesystem((EntranceSystem) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.SURVILANCE_AND_TRACKING_SYTEMS__ENTRANCESYSTEM:
			return entrancesystem != null;
		}
		return super.eIsSet(featureID);
	}

} //SurvilanceAndTrackingSytemsImpl
