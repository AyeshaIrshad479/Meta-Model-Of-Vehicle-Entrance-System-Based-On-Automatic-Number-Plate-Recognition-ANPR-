/**
 */
package ms21paper.impl;

import java.util.Collection;
import ms21paper.Ms21paperPackage;
import ms21paper.Sensor;
import ms21paper.Vehicle;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Vehicle</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.VehicleImpl#getMotionsensor <em>Motionsensor</em>}</li>
 *   <li>{@link ms21paper.impl.VehicleImpl#getName <em>Name</em>}</li>
 *   <li>{@link ms21paper.impl.VehicleImpl#getVnumber <em>Vnumber</em>}</li>
 *   <li>{@link ms21paper.impl.VehicleImpl#getOwnerID <em>Owner ID</em>}</li>
 * </ul>
 *
 * @generated
 */
public class VehicleImpl extends MinimalEObjectImpl.Container implements Vehicle {
	/**
	 * The cached value of the '{@link #getMotionsensor() <em>Motionsensor</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMotionsensor()
	 * @generated
	 * @ordered
	 */
	protected EList<Sensor> motionsensor;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;
	/**
	 * The default value of the '{@link #getVnumber() <em>Vnumber</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVnumber()
	 * @generated
	 * @ordered
	 */
	protected static final String VNUMBER_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getVnumber() <em>Vnumber</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVnumber()
	 * @generated
	 * @ordered
	 */
	protected String vnumber = VNUMBER_EDEFAULT;

	/**
	 * The default value of the '{@link #getOwnerID() <em>Owner ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOwnerID()
	 * @generated
	 * @ordered
	 */
	protected static final String OWNER_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOwnerID() <em>Owner ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOwnerID()
	 * @generated
	 * @ordered
	 */
	protected String ownerID = OWNER_ID_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected VehicleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.VEHICLE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Sensor> getMotionsensor() {
		if (motionsensor == null) {
			motionsensor = new EObjectResolvingEList<Sensor>(Sensor.class, this,
					Ms21paperPackage.VEHICLE__MOTIONSENSOR);
		}
		return motionsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.VEHICLE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getVnumber() {
		return vnumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVnumber(String newVnumber) {
		String oldVnumber = vnumber;
		vnumber = newVnumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.VEHICLE__VNUMBER, oldVnumber,
					vnumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getOwnerID() {
		return ownerID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setOwnerID(String newOwnerID) {
		String oldOwnerID = ownerID;
		ownerID = newOwnerID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.VEHICLE__OWNER_ID, oldOwnerID,
					ownerID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.VEHICLE__MOTIONSENSOR:
			return getMotionsensor();
		case Ms21paperPackage.VEHICLE__NAME:
			return getName();
		case Ms21paperPackage.VEHICLE__VNUMBER:
			return getVnumber();
		case Ms21paperPackage.VEHICLE__OWNER_ID:
			return getOwnerID();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.VEHICLE__MOTIONSENSOR:
			getMotionsensor().clear();
			getMotionsensor().addAll((Collection<? extends Sensor>) newValue);
			return;
		case Ms21paperPackage.VEHICLE__NAME:
			setName((String) newValue);
			return;
		case Ms21paperPackage.VEHICLE__VNUMBER:
			setVnumber((String) newValue);
			return;
		case Ms21paperPackage.VEHICLE__OWNER_ID:
			setOwnerID((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.VEHICLE__MOTIONSENSOR:
			getMotionsensor().clear();
			return;
		case Ms21paperPackage.VEHICLE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Ms21paperPackage.VEHICLE__VNUMBER:
			setVnumber(VNUMBER_EDEFAULT);
			return;
		case Ms21paperPackage.VEHICLE__OWNER_ID:
			setOwnerID(OWNER_ID_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.VEHICLE__MOTIONSENSOR:
			return motionsensor != null && !motionsensor.isEmpty();
		case Ms21paperPackage.VEHICLE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Ms21paperPackage.VEHICLE__VNUMBER:
			return VNUMBER_EDEFAULT == null ? vnumber != null : !VNUMBER_EDEFAULT.equals(vnumber);
		case Ms21paperPackage.VEHICLE__OWNER_ID:
			return OWNER_ID_EDEFAULT == null ? ownerID != null : !OWNER_ID_EDEFAULT.equals(ownerID);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", vnumber: ");
		result.append(vnumber);
		result.append(", OwnerID: ");
		result.append(ownerID);
		result.append(')');
		return result.toString();
	}

} //VehicleImpl
