/**
 */
package ms21paper.impl;

import ms21paper.Filtering;
import ms21paper.Ms21paperPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Filtering</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.FilteringImpl#getMasksize <em>Masksize</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class FilteringImpl extends PreprocessingImpl implements Filtering {
	/**
	 * The default value of the '{@link #getMasksize() <em>Masksize</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMasksize()
	 * @generated
	 * @ordered
	 */
	protected static final float MASKSIZE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getMasksize() <em>Masksize</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMasksize()
	 * @generated
	 * @ordered
	 */
	protected float masksize = MASKSIZE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FilteringImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.FILTERING;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getMasksize() {
		return masksize;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setMasksize(float newMasksize) {
		float oldMasksize = masksize;
		masksize = newMasksize;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.FILTERING__MASKSIZE, oldMasksize,
					masksize));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.FILTERING__MASKSIZE:
			return getMasksize();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.FILTERING__MASKSIZE:
			setMasksize((Float) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.FILTERING__MASKSIZE:
			setMasksize(MASKSIZE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.FILTERING__MASKSIZE:
			return masksize != MASKSIZE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (masksize: ");
		result.append(masksize);
		result.append(')');
		return result.toString();
	}

} //FilteringImpl
