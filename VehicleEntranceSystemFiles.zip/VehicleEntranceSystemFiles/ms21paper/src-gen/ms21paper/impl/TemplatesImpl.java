/**
 */
package ms21paper.impl;

import java.util.Collection;
import ms21paper.CharacterRecognition;
import ms21paper.Ms21paperPackage;
import ms21paper.Templates;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Templates</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.impl.TemplatesImpl#getCharacterrecognition <em>Characterrecognition</em>}</li>
 *   <li>{@link ms21paper.impl.TemplatesImpl#getBinaryimage <em>Binaryimage</em>}</li>
 *   <li>{@link ms21paper.impl.TemplatesImpl#getImextn <em>Imextn</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TemplatesImpl extends DIPImpl implements Templates {
	/**
	 * The cached value of the '{@link #getCharacterrecognition() <em>Characterrecognition</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCharacterrecognition()
	 * @generated
	 * @ordered
	 */
	protected EList<CharacterRecognition> characterrecognition;

	/**
	 * The default value of the '{@link #getBinaryimage() <em>Binaryimage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBinaryimage()
	 * @generated
	 * @ordered
	 */
	protected static final String BINARYIMAGE_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getBinaryimage() <em>Binaryimage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBinaryimage()
	 * @generated
	 * @ordered
	 */
	protected String binaryimage = BINARYIMAGE_EDEFAULT;
	/**
	 * The default value of the '{@link #getImextn() <em>Imextn</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImextn()
	 * @generated
	 * @ordered
	 */
	protected static final String IMEXTN_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getImextn() <em>Imextn</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImextn()
	 * @generated
	 * @ordered
	 */
	protected String imextn = IMEXTN_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TemplatesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Ms21paperPackage.Literals.TEMPLATES;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<CharacterRecognition> getCharacterrecognition() {
		if (characterrecognition == null) {
			characterrecognition = new EObjectWithInverseResolvingEList.ManyInverse<CharacterRecognition>(
					CharacterRecognition.class, this, Ms21paperPackage.TEMPLATES__CHARACTERRECOGNITION,
					Ms21paperPackage.CHARACTER_RECOGNITION__TEMPLATES);
		}
		return characterrecognition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getBinaryimage() {
		return binaryimage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setBinaryimage(String newBinaryimage) {
		String oldBinaryimage = binaryimage;
		binaryimage = newBinaryimage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.TEMPLATES__BINARYIMAGE,
					oldBinaryimage, binaryimage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getImextn() {
		return imextn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setImextn(String newImextn) {
		String oldImextn = imextn;
		imextn = newImextn;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Ms21paperPackage.TEMPLATES__IMEXTN, oldImextn,
					imextn));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Ms21paperPackage.TEMPLATES__CHARACTERRECOGNITION:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getCharacterrecognition()).basicAdd(otherEnd,
					msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Ms21paperPackage.TEMPLATES__CHARACTERRECOGNITION:
			return ((InternalEList<?>) getCharacterrecognition()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Ms21paperPackage.TEMPLATES__CHARACTERRECOGNITION:
			return getCharacterrecognition();
		case Ms21paperPackage.TEMPLATES__BINARYIMAGE:
			return getBinaryimage();
		case Ms21paperPackage.TEMPLATES__IMEXTN:
			return getImextn();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Ms21paperPackage.TEMPLATES__CHARACTERRECOGNITION:
			getCharacterrecognition().clear();
			getCharacterrecognition().addAll((Collection<? extends CharacterRecognition>) newValue);
			return;
		case Ms21paperPackage.TEMPLATES__BINARYIMAGE:
			setBinaryimage((String) newValue);
			return;
		case Ms21paperPackage.TEMPLATES__IMEXTN:
			setImextn((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.TEMPLATES__CHARACTERRECOGNITION:
			getCharacterrecognition().clear();
			return;
		case Ms21paperPackage.TEMPLATES__BINARYIMAGE:
			setBinaryimage(BINARYIMAGE_EDEFAULT);
			return;
		case Ms21paperPackage.TEMPLATES__IMEXTN:
			setImextn(IMEXTN_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Ms21paperPackage.TEMPLATES__CHARACTERRECOGNITION:
			return characterrecognition != null && !characterrecognition.isEmpty();
		case Ms21paperPackage.TEMPLATES__BINARYIMAGE:
			return BINARYIMAGE_EDEFAULT == null ? binaryimage != null : !BINARYIMAGE_EDEFAULT.equals(binaryimage);
		case Ms21paperPackage.TEMPLATES__IMEXTN:
			return IMEXTN_EDEFAULT == null ? imextn != null : !IMEXTN_EDEFAULT.equals(imextn);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (binaryimage: ");
		result.append(binaryimage);
		result.append(", imextn: ");
		result.append(imextn);
		result.append(')');
		return result.toString();
	}

} //TemplatesImpl
