/**
 */
package ms21paper;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>IR Ssensor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ms21paper.Ms21paperPackage#getIRSsensor()
 * @model
 * @generated
 */
public interface IRSsensor extends Sensor {
} // IRSsensor
