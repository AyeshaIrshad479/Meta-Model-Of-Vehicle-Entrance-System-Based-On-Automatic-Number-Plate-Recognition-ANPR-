/**
 */
package ms21paper;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Parking Systems</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.ParkingSystems#getEntrancesystem <em>Entrancesystem</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getParkingSystems()
 * @model
 * @generated
 */
public interface ParkingSystems extends EObject {
	/**
	 * Returns the value of the '<em><b>Entrancesystem</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entrancesystem</em>' containment reference.
	 * @see #setEntrancesystem(EntranceSystem)
	 * @see ms21paper.Ms21paperPackage#getParkingSystems_Entrancesystem()
	 * @model containment="true"
	 * @generated
	 */
	EntranceSystem getEntrancesystem();

	/**
	 * Sets the value of the '{@link ms21paper.ParkingSystems#getEntrancesystem <em>Entrancesystem</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Entrancesystem</em>' containment reference.
	 * @see #getEntrancesystem()
	 * @generated
	 */
	void setEntrancesystem(EntranceSystem value);

} // ParkingSystems
