/**
 */
package ms21paper;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Data Acquisition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.DataAcquisition#getControlgate <em>Controlgate</em>}</li>
 *   <li>{@link ms21paper.DataAcquisition#getType <em>Type</em>}</li>
 *   <li>{@link ms21paper.DataAcquisition#getPc <em>Pc</em>}</li>
 *   <li>{@link ms21paper.DataAcquisition#getSensorData <em>Sensor Data</em>}</li>
 *   <li>{@link ms21paper.DataAcquisition#isMotorStatus <em>Motor Status</em>}</li>
 *   <li>{@link ms21paper.DataAcquisition#getPort <em>Port</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getDataAcquisition()
 * @model
 * @generated
 */
public interface DataAcquisition extends EObject {
	/**
	 * Returns the value of the '<em><b>Controlgate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Controlgate</em>' reference.
	 * @see #setControlgate(ControlGate)
	 * @see ms21paper.Ms21paperPackage#getDataAcquisition_Controlgate()
	 * @model
	 * @generated
	 */
	ControlGate getControlgate();

	/**
	 * Sets the value of the '{@link ms21paper.DataAcquisition#getControlgate <em>Controlgate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Controlgate</em>' reference.
	 * @see #getControlgate()
	 * @generated
	 */
	void setControlgate(ControlGate value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The default value is <code>"ArduinoUNO"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see ms21paper.Ms21paperPackage#getDataAcquisition_Type()
	 * @model default="ArduinoUNO"
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link ms21paper.DataAcquisition#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Pc</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link ms21paper.PC#getDataacquisition <em>Dataacquisition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pc</em>' reference.
	 * @see #setPc(PC)
	 * @see ms21paper.Ms21paperPackage#getDataAcquisition_Pc()
	 * @see ms21paper.PC#getDataacquisition
	 * @model opposite="dataacquisition"
	 * @generated
	 */
	PC getPc();

	/**
	 * Sets the value of the '{@link ms21paper.DataAcquisition#getPc <em>Pc</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pc</em>' reference.
	 * @see #getPc()
	 * @generated
	 */
	void setPc(PC value);

	/**
	 * Returns the value of the '<em><b>Sensor Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sensor Data</em>' attribute.
	 * @see #setSensorData(Boolean)
	 * @see ms21paper.Ms21paperPackage#getDataAcquisition_SensorData()
	 * @model
	 * @generated
	 */
	Boolean getSensorData();

	/**
	 * Sets the value of the '{@link ms21paper.DataAcquisition#getSensorData <em>Sensor Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sensor Data</em>' attribute.
	 * @see #getSensorData()
	 * @generated
	 */
	void setSensorData(Boolean value);

	/**
	 * Returns the value of the '<em><b>Motor Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Motor Status</em>' attribute.
	 * @see #setMotorStatus(boolean)
	 * @see ms21paper.Ms21paperPackage#getDataAcquisition_MotorStatus()
	 * @model
	 * @generated
	 */
	boolean isMotorStatus();

	/**
	 * Sets the value of the '{@link ms21paper.DataAcquisition#isMotorStatus <em>Motor Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Motor Status</em>' attribute.
	 * @see #isMotorStatus()
	 * @generated
	 */
	void setMotorStatus(boolean value);

	/**
	 * Returns the value of the '<em><b>Port</b></em>' containment reference list.
	 * The list contents are of type {@link ms21paper.Port}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Port</em>' containment reference list.
	 * @see ms21paper.Ms21paperPackage#getDataAcquisition_Port()
	 * @model containment="true"
	 * @generated
	 */
	EList<Port> getPort();

} // DataAcquisition
