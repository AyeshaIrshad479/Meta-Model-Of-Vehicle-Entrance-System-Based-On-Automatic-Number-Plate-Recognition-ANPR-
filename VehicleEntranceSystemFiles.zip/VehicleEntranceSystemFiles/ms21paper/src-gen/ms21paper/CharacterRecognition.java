/**
 */
package ms21paper;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Character Recognition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ms21paper.CharacterRecognition#getTemplates <em>Templates</em>}</li>
 * </ul>
 *
 * @see ms21paper.Ms21paperPackage#getCharacterRecognition()
 * @model
 * @generated
 */
public interface CharacterRecognition extends DIP {
	/**
	 * Returns the value of the '<em><b>Templates</b></em>' reference list.
	 * The list contents are of type {@link ms21paper.Templates}.
	 * It is bidirectional and its opposite is '{@link ms21paper.Templates#getCharacterrecognition <em>Characterrecognition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Templates</em>' reference list.
	 * @see ms21paper.Ms21paperPackage#getCharacterRecognition_Templates()
	 * @see ms21paper.Templates#getCharacterrecognition
	 * @model opposite="characterrecognition"
	 * @generated
	 */
	EList<Templates> getTemplates();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void imread();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void FindCorrelation();

} // CharacterRecognition
