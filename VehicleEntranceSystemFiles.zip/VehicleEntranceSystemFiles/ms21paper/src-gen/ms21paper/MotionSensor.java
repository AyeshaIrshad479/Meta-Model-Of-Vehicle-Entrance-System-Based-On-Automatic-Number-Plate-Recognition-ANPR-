/**
 */
package ms21paper;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Motion Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ms21paper.Ms21paperPackage#getMotionSensor()
 * @model
 * @generated
 */
public interface MotionSensor extends Sensor {

} // MotionSensor
