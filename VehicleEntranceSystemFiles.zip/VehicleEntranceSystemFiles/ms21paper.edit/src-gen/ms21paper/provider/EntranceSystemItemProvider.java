/**
 */
package ms21paper.provider;

import java.util.Collection;
import java.util.List;

import ms21paper.EntranceSystem;
import ms21paper.Ms21paperFactory;
import ms21paper.Ms21paperPackage;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link ms21paper.EntranceSystem} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class EntranceSystemItemProvider extends ItemProviderAdapter implements IEditingDomainItemProvider,
		IStructuredItemContentProvider, ITreeItemContentProvider, IItemLabelProvider, IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EntranceSystemItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

		}
		return itemPropertyDescriptors;
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__VEHICLE);
			childrenFeatures.add(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__MOTIONSENSOR);
			childrenFeatures.add(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__DATAACQUISITION);
			childrenFeatures.add(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__DIP);
			childrenFeatures.add(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__RECORDS);
			childrenFeatures.add(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__VEHICLELOCATION);
			childrenFeatures.add(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__CONTROLGATE);
			childrenFeatures.add(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__PC);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns EntranceSystem.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/EntranceSystem"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		return getString("_UI_EntranceSystem_type");
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(EntranceSystem.class)) {
		case Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLE:
		case Ms21paperPackage.ENTRANCE_SYSTEM__MOTIONSENSOR:
		case Ms21paperPackage.ENTRANCE_SYSTEM__DATAACQUISITION:
		case Ms21paperPackage.ENTRANCE_SYSTEM__DIP:
		case Ms21paperPackage.ENTRANCE_SYSTEM__RECORDS:
		case Ms21paperPackage.ENTRANCE_SYSTEM__VEHICLELOCATION:
		case Ms21paperPackage.ENTRANCE_SYSTEM__CONTROLGATE:
		case Ms21paperPackage.ENTRANCE_SYSTEM__PC:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__VEHICLE,
				Ms21paperFactory.eINSTANCE.createVehicle()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__MOTIONSENSOR,
				Ms21paperFactory.eINSTANCE.createMotionSensor()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__MOTIONSENSOR,
				Ms21paperFactory.eINSTANCE.createIRSsensor()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__DATAACQUISITION,
				Ms21paperFactory.eINSTANCE.createDataAcquisition()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__DIP,
				Ms21paperFactory.eINSTANCE.createCamera()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__DIP,
				Ms21paperFactory.eINSTANCE.createImage()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__DIP,
				Ms21paperFactory.eINSTANCE.createImageAcquisition()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__DIP,
				Ms21paperFactory.eINSTANCE.createPreprocessing()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__DIP,
				Ms21paperFactory.eINSTANCE.createCharacterRecognition()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__DIP,
				Ms21paperFactory.eINSTANCE.createTemplates()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__DIP,
				Ms21paperFactory.eINSTANCE.createRegionOfInterest()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__DIP,
				Ms21paperFactory.eINSTANCE.createSmoothingFilter()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__DIP,
				Ms21paperFactory.eINSTANCE.createSharpening()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__DIP,
				Ms21paperFactory.eINSTANCE.createCharacterSegmentation()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__RECORDS,
				Ms21paperFactory.eINSTANCE.createRecords()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__VEHICLELOCATION,
				Ms21paperFactory.eINSTANCE.createVehicleLocation()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__CONTROLGATE,
				Ms21paperFactory.eINSTANCE.createControlGate()));

		newChildDescriptors.add(createChildParameter(Ms21paperPackage.Literals.ENTRANCE_SYSTEM__PC,
				Ms21paperFactory.eINSTANCE.createPC()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return Ms21paperEditPlugin.INSTANCE;
	}

}
